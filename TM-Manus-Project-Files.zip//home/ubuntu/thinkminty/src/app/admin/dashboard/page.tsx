'use client';

import { useState } from 'react';
import ContentCategoryManager from '@/components/admin/ContentCategoryManager';
import ContentSetManager from '@/components/admin/ContentSetManager';
import ContentSetBulkUpload from '@/components/admin/ContentSetBulkUpload';
import AIMatchingAlgorithm from '@/components/admin/AIMatchingAlgorithm';
import PersonalizedNewsletter from '@/components/admin/PersonalizedNewsletter';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('categories');

  return (
    <div className="max-w-7xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-8">ThinkMinty Admin Dashboard</h1>
      
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('categories')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'categories'
                  ? 'border-emerald-500 text-emerald-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Content Categories
            </button>
            <button
              onClick={() => setActiveTab('content-sets')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'content-sets'
                  ? 'border-emerald-500 text-emerald-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Content Sets
            </button>
            <button
              onClick={() => setActiveTab('bulk-upload')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'bulk-upload'
                  ? 'border-emerald-500 text-emerald-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Bulk Upload
            </button>
            <button
              onClick={() => setActiveTab('ai-matching')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'ai-matching'
                  ? 'border-emerald-500 text-emerald-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              AI Matching
            </button>
            <button
              onClick={() => setActiveTab('newsletter')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'newsletter'
                  ? 'border-emerald-500 text-emerald-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Newsletter
            </button>
          </nav>
        </div>
      </div>
      
      <div className="mt-6">
        {activeTab === 'categories' && <ContentCategoryManager />}
        {activeTab === 'content-sets' && <ContentSetManager />}
        {activeTab === 'bulk-upload' && <ContentSetBulkUpload />}
        {activeTab === 'ai-matching' && <AIMatchingAlgorithm />}
        {activeTab === 'newsletter' && <PersonalizedNewsletter />}
      </div>
    </div>
  );
}
