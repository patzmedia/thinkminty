import { NextRequest, NextResponse } from 'next/server';
import { sendEmail } from '@/lib/sendgrid';

export async function POST(req: NextRequest) {
  try {
    const { email, firstName } = await req.json();

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }

    // Send welcome email
    const result = await sendEmail({
      to: email,
      from: process.env.SENDGRID_FROM_EMAIL || 'newsletter@thinkminty.com',
      subject: 'Welcome to ThinkMinty!',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #10b981; padding: 20px; text-align: center;">
            <h1 style="color: white; margin: 0;">Welcome to ThinkMinty</h1>
          </div>
          <div style="padding: 20px; border: 1px solid #e5e7eb; border-top: none;">
            <p>Hello ${firstName ? firstName : 'there'},</p>
            <p>Thank you for subscribing to our newsletter! We're excited to share positive content with you.</p>
            <p>Here's what you can expect:</p>
            <ul>
              <li>Weekly newsletters with uplifting stories</li>
              <li>Tips for maintaining a positive mindset</li>
              <li>Exclusive content for our subscribers</li>
            </ul>
            <p>Stay tuned for our next newsletter!</p>
            <div style="margin-top: 30px; text-align: center;">
              <a href="${process.env.NEXT_PUBLIC_SITE_URL}" style="background-color: #10b981; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Visit ThinkMinty</a>
            </div>
            <p style="margin-top: 30px; font-size: 12px; color: #6b7280; text-align: center;">
              If you didn't sign up for this newsletter, you can 
              <a href="${process.env.NEXT_PUBLIC_SITE_URL}/newsletter/unsubscribe?email=${encodeURIComponent(email)}" style="color: #10b981;">unsubscribe here</a>.
            </p>
          </div>
        </div>
      `,
    });

    if (!result.success) {
      throw new Error('Failed to send welcome email');
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Error sending welcome email:', error);
    return NextResponse.json(
      { error: error.message || 'An error occurred' },
      { status: 500 }
    );
  }
}
