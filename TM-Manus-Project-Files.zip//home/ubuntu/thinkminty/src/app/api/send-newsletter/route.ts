import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { sendNewsletterEmail } from '@/lib/sendgrid';

export async function POST(req: NextRequest) {
  try {
    const { issueId, subject, content } = await req.json();

    if (!issueId) {
      return NextResponse.json(
        { error: 'Newsletter issue ID is required' },
        { status: 400 }
      );
    }

    // Get all active subscribers
    const { data: subscribers, error: subscribersError } = await supabase
      .from('newsletter_subscribers')
      .select('email')
      .eq('is_active', true);

    if (subscribersError) {
      throw new Error(`Error fetching subscribers: ${subscribersError.message}`);
    }

    if (!subscribers || subscribers.length === 0) {
      return NextResponse.json(
        { error: 'No active subscribers found' },
        { status: 404 }
      );
    }

    // Extract email addresses
    const subscriberEmails = subscribers.map(sub => sub.email);

    // Send newsletter to all subscribers
    const results = await sendNewsletterEmail(
      subscriberEmails,
      subject,
      content
    );

    // Update newsletter issue status
    const { error: updateError } = await supabase
      .from('newsletter_issues')
      .update({
        status: 'sent',
        sent_at: new Date().toISOString(),
      })
      .eq('id', issueId);

    if (updateError) {
      console.error('Error updating newsletter status:', updateError);
    }

    return NextResponse.json({
      success: true,
      sentTo: subscriberEmails.length,
      results
    });
  } catch (error: any) {
    console.error('Error sending newsletter:', error);
    return NextResponse.json(
      { error: error.message || 'An error occurred' },
      { status: 500 }
    );
  }
}
