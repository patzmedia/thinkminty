# ThinkMinty Expanded Content Creation Template

## Overview
This document provides comprehensive guidelines and templates for creating content sets for ThinkMinty. Each content set consists of a paragraph and a quote that work together to deliver a positive, impactful message to subscribers based on their preferences.

## Content Development Plan

### Scale
- **Total Content Sets**: 90 sets per category × 6 categories = 540 total content sets
- **Content Lifespan**: Provides 3 months of daily content per category

### Content Diversity Ratio
- **Stories/Parables**: 45 sets (50%)
- **Practical Tips**: 23 sets (25%)
- **Reflections**: 14 sets (15%)
- **Affirmations**: 9 sets (10%)

## Content Categories

### 1. Mindful Moments (Peace, Gratitude)
- **Focus**: Present-moment awareness and inner peace
- **Themes**: Meditation, breathing exercises, gratitude practices, mindfulness
- **Tone**: Calm, serene, reflective
- **Negative Emotion Connection**: Helps alleviate anxiety and stress

### 2. Resilience Recharge (Resilience, Hope, Inspiration)
- **Focus**: Building inner strength and bouncing back from adversity
- **Themes**: Overcoming challenges, coping with stress, building self-confidence
- **Tone**: Encouraging, strengthening, empowering
- **Negative Emotion Connection**: Builds strength to face fear and sadness

### 3. Joyful Living (Joy, Happiness)
- **Focus**: All sources of joy and happiness
- **Themes**: Humor, finding joy in everyday moments, celebrating small victories
- **Tone**: Lighthearted, playful, uplifting
- **Negative Emotion Connection**: Counteracts sadness and negativity

### 4. Purposeful Path (Inspiration, Hope)
- **Focus**: Finding meaning and direction in life
- **Themes**: Living with purpose, setting and achieving goals, values and priorities
- **Tone**: Inspiring, motivational, thought-provoking
- **Negative Emotion Connection**: Provides direction and meaning, combating feelings of aimlessness

### 5. Connection & Kindness (Love, Gratitude)
- **Focus**: The power of human connection and acts of kindness
- **Themes**: Building relationships, empathy, compassion, community
- **Tone**: Warm, inclusive, compassionate
- **Negative Emotion Connection**: Fosters a sense of belonging, reducing feelings of isolation

### 6. Calm & Comfort (Peace, Hope)
- **Focus**: Finding inner peace through encouragement
- **Themes**: Self-compassion, gentle encouragement, overcoming difficult situations
- **Tone**: Soothing, gentle, reassuring
- **Negative Emotion Connection**: Directly addresses sadness and fear with positive antidotes

## Content Creation Guidelines by Type

### Stories/Parables (50%)
- **Purpose**: Illustrate positive principles through relatable narratives
- **Length**: 150-250 words (1-2 minute read)
- **Structure**: 
  - Brief setup that introduces the context
  - Clear narrative arc with a challenge or situation
  - Resolution that illustrates a positive principle
- **Technique**: Use vivid language and engaging storytelling
- **Tone**: Authentic, relatable, and engaging

### Practical Tips (25%)
- **Purpose**: Provide actionable advice that subscribers can easily implement
- **Length**: 100-200 words (under 1 minute read)
- **Structure**:
  - Clear problem or need statement
  - Specific, actionable solution or technique
  - Brief explanation of benefits or expected outcomes
- **Technique**: Be concise, specific, and practical
- **Tone**: Helpful, clear, and encouraging

### Reflections (15%)
- **Purpose**: Offer thoughtful insights on positive themes
- **Length**: 150-250 words (1-2 minute read)
- **Structure**:
  - Introduction of a concept or principle
  - Exploration of meaning and significance
  - Connection to personal growth or daily life
- **Technique**: Use thoughtful questions and contemplative language
- **Tone**: Thoughtful, insightful, and contemplative

### Affirmations (10%)
- **Purpose**: Build self-confidence and inner strength
- **Length**: 100-150 words (under 1 minute read)
- **Structure**:
  - Positive statement of truth or potential
  - Supporting evidence or reasoning
  - Encouragement for internalization
- **Technique**: Use positive, empowering language in present tense
- **Tone**: Confident, empowering, and uplifting

## Tagging Strategy

### Core Tags
- **Category Tags**: 
  - Mindful Moments
  - Resilience Recharge
  - Joyful Living
  - Purposeful Path
  - Connection & Kindness
  - Calm & Comfort
  
- **Content Type Tags**:
  - Story
  - Practical Tip
  - Reflection
  - Affirmation

### Keyword Tags
- **Emotional Tags**: 
  - Peace
  - Gratitude
  - Hope
  - Joy
  - Love
  - Resilience
  - Inspiration
  - Happiness
  - Comfort
  - Courage
  
- **Action Tags**:
  - Breathing
  - Meditation
  - Goal Setting
  - Kindness
  - Giving
  - Journaling
  - Exercise
  - Rest
  - Prayer
  - Reflection
  
- **Theme Tags**:
  - Overcoming Challenges
  - Finding Purpose
  - Building Relationships
  - Self-Care
  - Mindfulness
  - Personal Growth
  - Spiritual Growth
  - Community
  - Nature Connection
  - Inner Peace
  
- **Source Tags**:
  - Scripture
  - Philosopher
  - Poet
  - Historical Figure
  - Contemporary Author
  - Spiritual Leader
  - Anonymous

## Content Template Format

```
Title: [Descriptive title for internal reference]
Content Type: [Story/Practical Tip/Reflection/Affirmation]
Paragraph: [Your paragraph content following the guidelines above]
Quote: [Selected quote that complements the paragraph]
Author: [Quote attribution]
Primary Category: [Primary category this content belongs to]
Tags: [Comma-separated list of relevant tags from the tagging strategy]
```

## Example Content Sets

### Story Example (Mindful Moments)
```
Title: The Rushing River
Content Type: Story
Paragraph: A traveler came upon a rushing river that blocked her path. She sat on the bank, frustrated by the obstacle. As she watched the water flow, she noticed how it moved around rocks without resistance. "The water doesn't fight the rocks," she thought, "it simply finds another way." In that moment, she realized she had been resisting her own challenges rather than flowing with them. She stood up, found a safe crossing upstream, and continued her journey with a new perspective on facing life's obstacles.
Quote: Life is a series of natural and spontaneous changes. Don't resist them; that only creates sorrow. Let reality be reality. Let things flow naturally forward in whatever way they like.
Author: Lao Tzu
Primary Category: Mindful Moments
Tags: Peace, Overcoming Challenges, Flow, Acceptance, Philosopher
```

### Practical Tip Example (Resilience Recharge)
```
Title: Five-Minute Resilience Reset
Content Type: Practical Tip
Paragraph: When feeling overwhelmed, try this five-minute resilience reset: Find a quiet space and take three deep breaths. Name three challenges you're facing right now. For each challenge, identify one small action you can take today. Next, recall three past difficulties you've successfully navigated. Finally, take three more deep breaths while silently affirming: "I have overcome challenges before, and I can do it again." This quick practice acknowledges difficulties while activating your innate problem-solving abilities and reconnecting you with your proven resilience.
Quote: The oak fought the wind and was broken, the willow bent when it must and survived.
Author: Robert Jordan
Primary Category: Resilience Recharge
Tags: Resilience, Practical Tip, Breathing, Overcoming Challenges, Contemporary Author
```

### Reflection Example (Purposeful Path)
```
Title: The Seeds We Plant
Content Type: Reflection
Paragraph: Consider the seeds you're planting in your life garden. Every action, like a seed, contains future potential. The habits you nurture today grow into the life you'll live tomorrow. The kindness you show ripples outward in ways you may never fully witness. The skills you develop become the fruits you'll harvest in seasons to come. What seeds are you intentionally planting? Which ones might you be planting unconsciously? Remember that you always have the choice to plant new seeds aligned with your deepest values and highest aspirations.
Quote: The best time to plant a tree was 20 years ago. The second best time is now.
Author: Chinese Proverb
Primary Category: Purposeful Path
Tags: Hope, Personal Growth, Finding Purpose, Reflection, Anonymous
```

### Affirmation Example (Calm & Comfort)
```
Title: Worthy of Rest
Content Type: Affirmation
Paragraph: I am worthy of rest and renewal. My value does not come from constant productivity or achievement. I honor my needs by creating space for restoration. When I rest, I am not avoiding responsibility—I am practicing essential self-care. My mind, body, and spirit deserve this time to replenish. In rest, I find new strength, clarity, and creativity. I give myself full permission to pause, breathe, and simply be.
Quote: Rest is not idleness, and to lie sometimes on the grass under trees on a summer's day, listening to the murmur of the water, or watching the clouds float across the sky, is by no means a waste of time.
Author: John Lubbock
Primary Category: Calm & Comfort
Tags: Peace, Self-Care, Rest, Affirmation, Historical Figure
```

## Content Development Goals
- Initial goal: Create 90 content sets for each category (540 total)
- Maintain the specified content type ratios within each category
- Ensure diversity of tags within each category
- Review content regularly to ensure freshness and relevance
- Gather user feedback to refine and improve content over time
