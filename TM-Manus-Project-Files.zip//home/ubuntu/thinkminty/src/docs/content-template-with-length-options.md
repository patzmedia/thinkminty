# ThinkMinty Content Template with Length Options

## Overview
This document provides comprehensive guidelines and templates for creating content sets for ThinkMinty. Each content set consists of both short-form and long-form versions of the same content, along with a quote that complements the message.

## Content Development Plan

### Scale
- **Total Content Sets**: 90 sets per category × 6 categories = 540 total content sets
- **Content Lifespan**: Provides 3 months of daily content per category

### Content Formats
- **Short-form**: 1-2 paragraphs (1-2 minute read)
- **Long-form**: 3-5 paragraphs (5-10 minute read)

### Content Diversity Ratio
- **Stories/Parables**: 45 sets (50%)
- **Practical Tips**: 23 sets (25%)
- **Reflections**: 14 sets (15%)
- **Affirmations**: 9 sets (10%)

## Content Categories

### 1. Mindful Moments (Peace, Gratitude)
- **Focus**: Present-moment awareness and inner peace
- **Themes**: Meditation, breathing exercises, gratitude practices, mindfulness
- **Tone**: Calm, serene, reflective
- **Negative Emotion Connection**: Helps alleviate anxiety and stress

### 2. Resilience Recharge (Resilience, Hope, Inspiration)
- **Focus**: Building inner strength and bouncing back from adversity
- **Themes**: Overcoming challenges, coping with stress, building self-confidence
- **Tone**: Encouraging, strengthening, empowering
- **Negative Emotion Connection**: Builds strength to face fear and sadness

### 3. Joyful Living (Joy, Happiness)
- **Focus**: All sources of joy and happiness
- **Themes**: Humor, finding joy in everyday moments, celebrating small victories
- **Tone**: Lighthearted, playful, uplifting
- **Negative Emotion Connection**: Counteracts sadness and negativity

### 4. Purposeful Path (Inspiration, Hope)
- **Focus**: Finding meaning and direction in life
- **Themes**: Living with purpose, setting and achieving goals, values and priorities
- **Tone**: Inspiring, motivational, thought-provoking
- **Negative Emotion Connection**: Provides direction and meaning, combating feelings of aimlessness

### 5. Connection & Kindness (Love, Gratitude)
- **Focus**: The power of human connection and acts of kindness
- **Themes**: Building relationships, empathy, compassion, community
- **Tone**: Warm, inclusive, compassionate
- **Negative Emotion Connection**: Fosters a sense of belonging, reducing feelings of isolation

### 6. Calm & Comfort (Peace, Hope)
- **Focus**: Finding inner peace through encouragement
- **Themes**: Self-compassion, gentle encouragement, overcoming difficult situations
- **Tone**: Soothing, gentle, reassuring
- **Negative Emotion Connection**: Directly addresses sadness and fear with positive antidotes

## Content Creation Guidelines by Type and Length

### Stories/Parables (50%)

#### Short-form (1-2 minute read)
- **Length**: 150-250 words
- **Structure**: 
  - Brief setup that introduces the context
  - Clear narrative arc with a challenge or situation
  - Resolution that illustrates a positive principle
- **Technique**: Use vivid language and engaging storytelling
- **Tone**: Authentic, relatable, and engaging

#### Long-form (5-10 minute read)
- **Length**: 500-1000 words
- **Structure**:
  - Detailed setup with character development and context
  - Expanded narrative with nuanced challenges and obstacles
  - Thoughtful resolution with deeper exploration of the positive principle
  - Additional reflective elements or application points
- **Technique**: Develop characters more fully, include sensory details, and explore emotional elements
- **Tone**: Immersive, reflective, and thought-provoking

### Practical Tips (25%)

#### Short-form (1-2 minute read)
- **Length**: 100-200 words
- **Structure**:
  - Clear problem or need statement
  - Specific, actionable solution or technique
  - Brief explanation of benefits or expected outcomes
- **Technique**: Be concise, specific, and practical
- **Tone**: Helpful, clear, and encouraging

#### Long-form (5-10 minute read)
- **Length**: 400-800 words
- **Structure**:
  - Comprehensive problem statement with context
  - Multiple actionable solutions or techniques
  - Step-by-step implementation guidance
  - Evidence or examples of effectiveness
  - Troubleshooting common challenges
- **Technique**: Provide detailed instructions, address potential obstacles, include examples
- **Tone**: Instructive, thorough, and supportive

### Reflections (15%)

#### Short-form (1-2 minute read)
- **Length**: 150-250 words
- **Structure**:
  - Introduction of a concept or principle
  - Exploration of meaning and significance
  - Connection to personal growth or daily life
- **Technique**: Use thoughtful questions and contemplative language
- **Tone**: Thoughtful, insightful, and contemplative

#### Long-form (5-10 minute read)
- **Length**: 500-900 words
- **Structure**:
  - In-depth exploration of a concept or principle
  - Multiple perspectives or dimensions of the topic
  - Historical, cultural, or spiritual context when relevant
  - Personal application questions or exercises
  - Concluding insights that invite further reflection
- **Technique**: Incorporate relevant wisdom traditions, use metaphors, pose thoughtful questions
- **Tone**: Philosophical, nuanced, and wisdom-oriented

### Affirmations (10%)

#### Short-form (1-2 minute read)
- **Length**: 100-150 words
- **Structure**:
  - Positive statement of truth or potential
  - Supporting evidence or reasoning
  - Encouragement for internalization
- **Technique**: Use positive, empowering language in present tense
- **Tone**: Confident, empowering, and uplifting

#### Long-form (5-10 minute read)
- **Length**: 300-600 words
- **Structure**:
  - Series of related affirmations around a central theme
  - Psychological or spiritual basis for the affirmations
  - Guidance for integrating affirmations into daily practice
  - Personal reflection prompts
  - Visualization or meditation exercise
- **Technique**: Combine affirmations with mindfulness practices, provide context for effectiveness
- **Tone**: Nurturing, transformative, and deeply affirming

## Tagging Strategy

### Core Tags
- **Category Tags**: 
  - Mindful Moments
  - Resilience Recharge
  - Joyful Living
  - Purposeful Path
  - Connection & Kindness
  - Calm & Comfort
  
- **Content Type Tags**:
  - Story
  - Practical Tip
  - Reflection
  - Affirmation

- **Content Length Tags**:
  - Short-form
  - Long-form

### Keyword Tags
- **Emotional Tags**: 
  - Peace
  - Gratitude
  - Hope
  - Joy
  - Love
  - Resilience
  - Inspiration
  - Happiness
  - Comfort
  - Courage
  
- **Action Tags**:
  - Breathing
  - Meditation
  - Goal Setting
  - Kindness
  - Giving
  - Journaling
  - Exercise
  - Rest
  - Prayer
  - Reflection
  
- **Theme Tags**:
  - Overcoming Challenges
  - Finding Purpose
  - Building Relationships
  - Self-Care
  - Mindfulness
  - Personal Growth
  - Spiritual Growth
  - Community
  - Nature Connection
  - Inner Peace
  
- **Source Tags**:
  - Scripture
  - Philosopher
  - Poet
  - Historical Figure
  - Contemporary Author
  - Spiritual Leader
  - Anonymous

## Content Template Format

```
Title: [Descriptive title for internal reference]
Content Type: [Story/Practical Tip/Reflection/Affirmation]
Short-form Content: [Your short-form content following the guidelines above]
Long-form Content: [Your long-form content following the guidelines above]
Quote: [Selected quote that complements the content]
Author: [Quote attribution]
Primary Category: [Primary category this content belongs to]
Tags: [Comma-separated list of relevant tags from the tagging strategy]
```

## Example Content Sets

### Story Example (Mindful Moments)
```
Title: The Rushing River
Content Type: Story

Short-form Content:
A traveler came upon a rushing river that blocked her path. She sat on the bank, frustrated by the obstacle. As she watched the water flow, she noticed how it moved around rocks without resistance. "The water doesn't fight the rocks," she thought, "it simply finds another way." In that moment, she realized she had been resisting her own challenges rather than flowing with them. She stood up, found a safe crossing upstream, and continued her journey with a new perspective on facing life's obstacles.

Long-form Content:
The sun was setting as Maya reached the edge of a rushing river that cut across her path. She had been hiking for days, seeking both adventure and clarity after leaving behind a career that no longer fulfilled her. Now, faced with this unexpected obstacle, she dropped her backpack and sat heavily on the riverbank, frustration welling up inside her.

"Just my luck," she muttered, tossing a small stone into the churning water. She had planned to reach the next village by nightfall, but the river seemed impassable—too deep to wade through and too rapid to swim safely. As daylight faded, Maya resigned herself to making camp for the night.

As she prepared a small fire, her gaze kept returning to the river. In the golden light of dusk, she noticed something she hadn't seen before: the water's elegant movement around the rocks. Where boulders stood firm in the current, the water didn't crash against them in futile resistance—it simply flowed around, finding new pathways, continuing its journey without struggle or complaint.

Maya moved closer to the water's edge, mesmerized by this dance of adaptation. "The water doesn't fight the rocks," she whispered to herself, "it simply finds another way." The realization struck her with unexpected force. How much energy had she wasted resisting the obstacles in her own life? Her difficult boss, the career setbacks, the relationships that hadn't worked out—she had spent years pushing against these rocks, growing increasingly exhausted and bitter.

What if, like the river, she could acknowledge the obstacles but not be defined by them? What if she could flow around them, finding new pathways without losing her essential nature or purpose?

The next morning, Maya woke with renewed clarity. Instead of attempting to cross at the treacherous point before her, she hiked upstream, eventually finding a narrower, calmer crossing. As she continued her journey, she carried the river's wisdom with her: life's obstacles don't disappear by fighting them, but they lose their power when we learn to flow.

Quote: Life is a series of natural and spontaneous changes. Don't resist them; that only creates sorrow. Let reality be reality. Let things flow naturally forward in whatever way they like.
Author: Lao Tzu
Primary Category: Mindful Moments
Tags: Peace, Overcoming Challenges, Flow, Acceptance, Philosopher, Short-form, Long-form
```

### Practical Tip Example (Resilience Recharge)
```
Title: Five-Minute Resilience Reset
Content Type: Practical Tip

Short-form Content:
When feeling overwhelmed, try this five-minute resilience reset: Find a quiet space and take three deep breaths. Name three challenges you're facing right now. For each challenge, identify one small action you can take today. Next, recall three past difficulties you've successfully navigated. Finally, take three more deep breaths while silently affirming: "I have overcome challenges before, and I can do it again." This quick practice acknowledges difficulties while activating your innate problem-solving abilities and reconnecting you with your proven resilience.

Long-form Content:
In our fast-paced world, moments of overwhelm can strike unexpectedly—during a hectic workday, amid family responsibilities, or when facing multiple challenges simultaneously. The Five-Minute Resilience Reset is a practical tool designed to quickly shift your mindset from feeling overwhelmed to feeling capable, all within the time it takes to enjoy a cup of tea.

Step 1: Create a Mindful Foundation (1 minute)
Find a quiet space where you won't be interrupted. This could be a corner of your office, your car, a bathroom stall, or even a quiet spot outdoors. Sit comfortably and take three deep, intentional breaths. Inhale slowly through your nose for a count of four, hold briefly, then exhale through your mouth for a count of six. This breathing pattern activates your parasympathetic nervous system, reducing the stress hormones that cloud clear thinking.

Step 2: Acknowledge Current Challenges (1 minute)
On paper or mentally, name three specific challenges you're facing right now. Be concrete rather than abstract. Instead of "I'm stressed about work," identify "I'm behind on the quarterly report" or "I'm nervous about tomorrow's presentation." Naming challenges precisely helps transform vague anxiety into defined problems that can be addressed.

Step 3: Identify Actionable Steps (1 minute)
For each challenge you've named, identify one small, specific action you could take today to move forward. The key word is "small"—these should be actions you can complete in 30 minutes or less. For example, "I'll outline the first section of the report" or "I'll practice the opening of my presentation for five minutes." These micro-actions build momentum and restore a sense of agency.

Step 4: Recall Past Resilience (1 minute)
Reflect on three previous difficulties you've successfully navigated. These could be professional challenges, personal hardships, or any situation where you demonstrated resilience. Briefly recall how you felt during those challenges and what strategies helped you overcome them. This step reminds you that resilience is not something you need to create—it's a capacity you already possess and have demonstrated.

Step 5: Reaffirm Your Resilience (1 minute)
Return to your breathing practice with three more deep breaths. As you breathe, silently repeat this affirmation: "I have overcome challenges before, and I can do it again." Feel the truth of these words in your body. If helpful, place a hand on your heart as you affirm your resilience.

The power of this five-minute practice lies in its ability to interrupt the spiral of overwhelm by acknowledging difficulties while simultaneously activating your problem-solving abilities and reconnecting you with your proven resilience. With regular practice, you may find that you can reset your resilience in even less time, eventually developing the ability to bounce back from setbacks with increasing speed and grace.

Quote: The oak fought the wind and was broken, the willow bent when it must and survived.
Author: Robert Jordan
Primary Category: Resilience Recharge
Tags: Resilience, Practical Tip, Breathing, Overcoming Challenges, Contemporary Author, Short-form, Long-form
```

## Content Development Goals
- Initial goal: Create 90 content sets for each category (540 total)
- Each content set must include both short-form and long-form versions
- Maintain the specified content type ratios within each category
- Ensure diversity of tags within each category
- Review content regularly to ensure freshness and relevance
- Gather user feedback to refine and improve content over time
