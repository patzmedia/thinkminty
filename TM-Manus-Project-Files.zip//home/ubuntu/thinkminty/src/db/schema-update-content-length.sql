-- Schema updates to support short-form and long-form content for ThinkMinty

-- Modify content_sets table to support both short-form and long-form content
ALTER TABLE content_sets 
  RENAME COLUMN paragraph_content TO short_form_content;

-- Add long_form_content column to content_sets table
ALTER TABLE content_sets 
  ADD COLUMN long_form_content TEXT;

-- Add content_length_preference to users table
ALTER TABLE users
  ADD COLUMN content_length_preference VARCHAR(20) DEFAULT 'short-form' CHECK (content_length_preference IN ('short-form', 'long-form'));

-- Create content_length tags
INSERT INTO tags (name, slug, tag_type, description)
VALUES 
  ('Short-form', 'short-form', 'content_length', 'Content designed for a 1-2 minute read (1-2 paragraphs)'),
  ('Long-form', 'long-form', 'content_length', 'Content designed for a 5-10 minute read (3-5 paragraphs)');

-- Update the get_content_by_tags function to consider content length preference
CREATE OR REPLACE FUNCTION get_content_by_tags(
  p_user_id UUID,
  p_preferred_tags UUID[] DEFAULT NULL,
  p_avoided_tags UUID[] DEFAULT NULL,
  p_content_length VARCHAR(20) DEFAULT NULL
)
RETURNS TABLE (
  content_set_id UUID,
  title TEXT,
  content TEXT, -- This will contain either short_form_content or long_form_content based on preference
  quote_content TEXT,
  quote_author TEXT,
  tags JSONB
) AS $$
DECLARE
  v_content_length VARCHAR(20);
BEGIN
  -- Get user's content length preference if not specified
  IF p_content_length IS NULL THEN
    SELECT content_length_preference INTO v_content_length
    FROM users
    WHERE id = p_user_id;
  ELSE
    v_content_length := p_content_length;
  END IF;
  
  -- Default to short-form if no preference is found
  IF v_content_length IS NULL THEN
    v_content_length := 'short-form';
  END IF;

  RETURN QUERY
  WITH user_history AS (
    -- Get content already delivered to the user
    SELECT content_set_id
    FROM content_delivery_history
    WHERE user_id = p_user_id
  ),
  content_with_tags AS (
    -- Get all content sets with their tags
    SELECT 
      cs.id,
      cs.title,
      CASE 
        WHEN v_content_length = 'long-form' AND cs.long_form_content IS NOT NULL THEN cs.long_form_content
        ELSE cs.short_form_content
      END AS content,
      cs.quote_content,
      cs.quote_author,
      jsonb_agg(
        jsonb_build_object(
          'id', t.id,
          'name', t.name,
          'type', t.tag_type
        )
      ) AS tags,
      COUNT(CASE WHEN p_preferred_tags IS NOT NULL AND t.id = ANY(p_preferred_tags) THEN 1 END) AS preferred_tag_count,
      COUNT(CASE WHEN p_avoided_tags IS NOT NULL AND t.id = ANY(p_avoided_tags) THEN 1 END) AS avoided_tag_count
    FROM content_sets cs
    JOIN content_set_tags cst ON cs.id = cst.content_set_id
    JOIN tags t ON cst.tag_id = t.id
    WHERE cs.is_active = true
    GROUP BY cs.id
  )
  SELECT 
    cwt.id AS content_set_id,
    cwt.title,
    cwt.content,
    cwt.quote_content,
    cwt.quote_author,
    cwt.tags
  FROM content_with_tags cwt
  WHERE 
    -- Exclude content already delivered to the user
    cwt.id NOT IN (SELECT content_set_id FROM user_history)
    -- Exclude content with avoided tags (if specified)
    AND (p_avoided_tags IS NULL OR cwt.avoided_tag_count = 0)
  ORDER BY 
    -- Prioritize content with preferred tags (if specified)
    CASE WHEN p_preferred_tags IS NOT NULL THEN cwt.preferred_tag_count ELSE 0 END DESC,
    -- Add some randomness for variety
    RANDOM()
  LIMIT 10;
END;
$$ LANGUAGE plpgsql;

-- Create a function to update existing content sets with long-form content
CREATE OR REPLACE FUNCTION update_content_set_with_long_form(
  p_content_set_id UUID,
  p_long_form_content TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
  v_success BOOLEAN;
BEGIN
  UPDATE content_sets
  SET long_form_content = p_long_form_content
  WHERE id = p_content_set_id;
  
  GET DIAGNOSTICS v_success = ROW_COUNT;
  
  RETURN v_success > 0;
END;
$$ LANGUAGE plpgsql;

-- Create a view to show content completion status including length options
CREATE OR REPLACE VIEW content_completion_status AS
SELECT 
  cc.name AS category_name,
  COUNT(cs.id) AS total_content_sets,
  SUM(CASE WHEN cs.short_form_content IS NOT NULL THEN 1 ELSE 0 END) AS short_form_complete,
  SUM(CASE WHEN cs.long_form_content IS NOT NULL THEN 1 ELSE 0 END) AS long_form_complete,
  SUM(CASE WHEN cs.short_form_content IS NOT NULL AND cs.long_form_content IS NOT NULL THEN 1 ELSE 0 END) AS both_complete,
  ROUND(SUM(CASE WHEN cs.short_form_content IS NOT NULL THEN 1 ELSE 0 END)::NUMERIC / COUNT(cs.id) * 100, 2) AS short_form_percentage,
  ROUND(SUM(CASE WHEN cs.long_form_content IS NOT NULL THEN 1 ELSE 0 END)::NUMERIC / COUNT(cs.id) * 100, 2) AS long_form_percentage
FROM 
  content_categories cc
LEFT JOIN 
  content_set_categories csc ON cc.id = csc.category_id
LEFT JOIN 
  content_sets cs ON csc.content_set_id = cs.id
WHERE 
  cc.parent_id IS NULL
GROUP BY 
  cc.name
ORDER BY 
  cc.name;

-- Add a trigger to automatically tag content sets with the appropriate content length tags
CREATE OR REPLACE FUNCTION update_content_length_tags()
RETURNS TRIGGER AS $$
DECLARE
  v_short_form_tag_id UUID;
  v_long_form_tag_id UUID;
BEGIN
  -- Get tag IDs
  SELECT id INTO v_short_form_tag_id FROM tags WHERE slug = 'short-form';
  SELECT id INTO v_long_form_tag_id FROM tags WHERE slug = 'long-form';
  
  -- Add short-form tag if short_form_content is not null
  IF NEW.short_form_content IS NOT NULL THEN
    INSERT INTO content_set_tags (content_set_id, tag_id)
    VALUES (NEW.id, v_short_form_tag_id)
    ON CONFLICT DO NOTHING;
  END IF;
  
  -- Add long-form tag if long_form_content is not null
  IF NEW.long_form_content IS NOT NULL THEN
    INSERT INTO content_set_tags (content_set_id, tag_id)
    VALUES (NEW.id, v_long_form_tag_id)
    ON CONFLICT DO NOTHING;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_content_length_tags_trigger
AFTER INSERT OR UPDATE ON content_sets
FOR EACH ROW
EXECUTE FUNCTION update_content_length_tags();

-- Update existing content sets to add content length tags
DO $$
DECLARE
  v_short_form_tag_id UUID;
  v_long_form_tag_id UUID;
  v_content_set RECORD;
BEGIN
  -- Get tag IDs
  SELECT id INTO v_short_form_tag_id FROM tags WHERE slug = 'short-form';
  SELECT id INTO v_long_form_tag_id FROM tags WHERE slug = 'long-form';
  
  -- For existing content, add short-form tag since all existing content is short-form
  FOR v_content_set IN SELECT id FROM content_sets WHERE short_form_content IS NOT NULL LOOP
    INSERT INTO content_set_tags (content_set_id, tag_id)
    VALUES (v_content_set.id, v_short_form_tag_id)
    ON CONFLICT DO NOTHING;
  END LOOP;
END $$;
