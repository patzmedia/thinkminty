-- Create content_sets table with initial examples

-- Mindful Moments Example
INSERT INTO content_sets (title, paragraph_content, quote_content, quote_author, is_active)
VALUES (
  'Present Moment Breathing',
  'Take a moment to simply observe your breath. Inhale deeply, feeling the air fill your lungs. Exhale slowly, releasing any tension. By focusing on your breath, you bring yourself into the present moment, finding peace in the here and now.',
  'The quieter you become, the more you are able to hear.',
  'Rumi',
  true
);

-- Get the ID of the inserted content set
DO $$
DECLARE
  content_set_id UUID;
  category_id UUID;
BEGIN
  -- Get the most recently inserted content set
  SELECT id INTO content_set_id FROM content_sets ORDER BY created_at DESC LIMIT 1;
  
  -- Get the Mindful Moments category ID
  SELECT id INTO category_id FROM content_categories WHERE slug = 'mindful-moments';
  
  -- Associate the content set with the category
  INSERT INTO content_set_categories (content_set_id, category_id)
  VALUES (content_set_id, category_id);
END $$;

-- Resilience Recharge Example
INSERT INTO content_sets (title, paragraph_content, quote_content, quote_author, is_active)
VALUES (
  'Obstacles as Stepping Stones',
  'Life''s challenges are not roadblocks, but stepping stones. Each obstacle you overcome strengthens your resilience. Remember the times you''ve faced adversity and emerged stronger. You have the inner strength to persevere.',
  'That which does not kill us makes us stronger.',
  'Friedrich Nietzsche',
  true
);

-- Get the ID of the inserted content set
DO $$
DECLARE
  content_set_id UUID;
  category_id UUID;
BEGIN
  -- Get the most recently inserted content set
  SELECT id INTO content_set_id FROM content_sets ORDER BY created_at DESC LIMIT 1;
  
  -- Get the Resilience Recharge category ID
  SELECT id INTO category_id FROM content_categories WHERE slug = 'resilience-recharge';
  
  -- Associate the content set with the category
  INSERT INTO content_set_categories (content_set_id, category_id)
  VALUES (content_set_id, category_id);
END $$;

-- Joyful Living Example
INSERT INTO content_sets (title, paragraph_content, quote_content, quote_author, is_active)
VALUES (
  'Simple Pleasures',
  'Find joy in the simple pleasures of life. A warm cup of coffee, a beautiful sunset, a heartfelt conversation with a friend. These moments, when savored, can fill your day with happiness. Look for the small joys, and you''ll find a world of delight.',
  'The most wasted of all days is one without laughter.',
  'E.E. Cummings',
  true
);

-- Get the ID of the inserted content set
DO $$
DECLARE
  content_set_id UUID;
  category_id UUID;
BEGIN
  -- Get the most recently inserted content set
  SELECT id INTO content_set_id FROM content_sets ORDER BY created_at DESC LIMIT 1;
  
  -- Get the Joyful Living category ID
  SELECT id INTO category_id FROM content_categories WHERE slug = 'joyful-living';
  
  -- Associate the content set with the category
  INSERT INTO content_set_categories (content_set_id, category_id)
  VALUES (content_set_id, category_id);
END $$;

-- Purposeful Path Example
INSERT INTO content_sets (title, paragraph_content, quote_content, quote_author, is_active)
VALUES (
  'Discovering Your Purpose',
  'Discovering your purpose is a journey of self-discovery. Reflect on your passions, values, and talents. What brings you joy and fulfillment? Align your actions with your purpose, and you''ll find a life of meaning and direction.',
  'The purpose of life is to live it, to taste experience to the utmost, to reach out eagerly and without fear for newer and richer experience.',
  'Eleanor Roosevelt',
  true
);

-- Get the ID of the inserted content set
DO $$
DECLARE
  content_set_id UUID;
  category_id UUID;
BEGIN
  -- Get the most recently inserted content set
  SELECT id INTO content_set_id FROM content_sets ORDER BY created_at DESC LIMIT 1;
  
  -- Get the Purposeful Path category ID
  SELECT id INTO category_id FROM content_categories WHERE slug = 'purposeful-path';
  
  -- Associate the content set with the category
  INSERT INTO content_set_categories (content_set_id, category_id)
  VALUES (content_set_id, category_id);
END $$;

-- Connection & Kindness Example
INSERT INTO content_sets (title, paragraph_content, quote_content, quote_author, is_active)
VALUES (
  'Ripple Effect of Kindness',
  'A simple act of kindness can create a ripple effect of positivity. Offer a helping hand, share a kind word, or show genuine empathy. By connecting with others, you not only uplift them but also enrich your own life.',
  'Kindness is a language which the deaf can hear and the blind can see.',
  'Mark Twain',
  true
);

-- Get the ID of the inserted content set
DO $$
DECLARE
  content_set_id UUID;
  category_id UUID;
BEGIN
  -- Get the most recently inserted content set
  SELECT id INTO content_set_id FROM content_sets ORDER BY created_at DESC LIMIT 1;
  
  -- Get the Connection & Kindness category ID
  SELECT id INTO category_id FROM content_categories WHERE slug = 'connection-kindness';
  
  -- Associate the content set with the category
  INSERT INTO content_set_categories (content_set_id, category_id)
  VALUES (content_set_id, category_id);
END $$;

-- Calm & Comfort Example
INSERT INTO content_sets (title, paragraph_content, quote_content, quote_author, is_active)
VALUES (
  'Permission to Rest',
  'When feeling overwhelmed, remember that it''s okay to seek comfort. Allow yourself to rest, recharge, and practice self-compassion. You are worthy of peace and tranquility. Take gentle care of yourself.',
  'Peace begins with a smile.',
  'Mother Teresa',
  true
);

-- Get the ID of the inserted content set
DO $$
DECLARE
  content_set_id UUID;
  category_id UUID;
BEGIN
  -- Get the most recently inserted content set
  SELECT id INTO content_set_id FROM content_sets ORDER BY created_at DESC LIMIT 1;
  
  -- Get the Calm & Comfort category ID
  SELECT id INTO category_id FROM content_categories WHERE slug = 'calm-comfort';
  
  -- Associate the content set with the category
  INSERT INTO content_set_categories (content_set_id, category_id)
  VALUES (content_set_id, category_id);
END $$;
