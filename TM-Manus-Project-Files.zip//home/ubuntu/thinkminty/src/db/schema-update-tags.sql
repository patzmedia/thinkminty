-- Schema updates to support the expanded tagging system for ThinkMinty

-- Create tags table to store all available tags
CREATE TABLE IF NOT EXISTS tags (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100) NOT NULL,
  tag_type VARCHAR(50) NOT NULL, -- 'category', 'content_type', 'emotional', 'action', 'theme', 'source'
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create unique index on tag slug
CREATE UNIQUE INDEX IF NOT EXISTS tags_slug_idx ON tags(slug);

-- Create content_set_tags table to associate content sets with tags
CREATE TABLE IF NOT EXISTS content_set_tags (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  content_set_id UUID NOT NULL REFERENCES content_sets(id) ON DELETE CASCADE,
  tag_id UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(content_set_id, tag_id)
);

-- Create user_tag_preferences table to store user tag preferences
CREATE TABLE IF NOT EXISTS user_tag_preferences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  tag_id UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  preference_type VARCHAR(20) NOT NULL, -- 'prefer', 'neutral', 'avoid'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, tag_id)
);

-- Insert core category tags
INSERT INTO tags (name, slug, tag_type, description)
VALUES 
  ('Mindful Moments', 'mindful-moments', 'category', 'Content focused on present-moment awareness and inner peace'),
  ('Resilience Recharge', 'resilience-recharge', 'category', 'Content focused on building inner strength and bouncing back from adversity'),
  ('Joyful Living', 'joyful-living', 'category', 'Content focused on all sources of joy and happiness'),
  ('Purposeful Path', 'purposeful-path', 'category', 'Content focused on finding meaning and direction in life'),
  ('Connection & Kindness', 'connection-kindness', 'category', 'Content focused on the power of human connection and acts of kindness'),
  ('Calm & Comfort', 'calm-comfort', 'category', 'Content focused on finding inner peace through encouragement');

-- Insert content type tags
INSERT INTO tags (name, slug, tag_type, description)
VALUES 
  ('Story', 'story', 'content_type', 'Illustrative narratives that demonstrate positive principles'),
  ('Practical Tip', 'practical-tip', 'content_type', 'Actionable advice that can be easily implemented'),
  ('Reflection', 'reflection', 'content_type', 'Thoughtful insights on positive themes'),
  ('Affirmation', 'affirmation', 'content_type', 'Positive statements to build self-confidence and inner strength');

-- Insert emotional tags
INSERT INTO tags (name, slug, tag_type, description)
VALUES 
  ('Peace', 'peace', 'emotional', 'Content related to inner peace and tranquility'),
  ('Gratitude', 'gratitude', 'emotional', 'Content focused on appreciation and thankfulness'),
  ('Hope', 'hope', 'emotional', 'Content that inspires optimism and positive expectation'),
  ('Joy', 'joy', 'emotional', 'Content that evokes happiness and delight'),
  ('Love', 'love', 'emotional', 'Content related to compassion and deep connection'),
  ('Resilience', 'resilience', 'emotional', 'Content about bouncing back and inner strength'),
  ('Inspiration', 'inspiration', 'emotional', 'Content that motivates and uplifts'),
  ('Happiness', 'happiness', 'emotional', 'Content related to overall well-being and contentment'),
  ('Comfort', 'comfort', 'emotional', 'Content that soothes and reassures'),
  ('Courage', 'courage', 'emotional', 'Content about bravery and facing fears');

-- Insert action tags
INSERT INTO tags (name, slug, tag_type, description)
VALUES 
  ('Breathing', 'breathing', 'action', 'Practices involving conscious breath awareness'),
  ('Meditation', 'meditation', 'action', 'Mindfulness and meditation practices'),
  ('Goal Setting', 'goal-setting', 'action', 'Techniques for setting and achieving goals'),
  ('Kindness', 'kindness', 'action', 'Acts of compassion toward others'),
  ('Giving', 'giving', 'action', 'Generosity and sharing with others'),
  ('Journaling', 'journaling', 'action', 'Writing practices for reflection and growth'),
  ('Exercise', 'exercise', 'action', 'Physical movement and activity'),
  ('Rest', 'rest', 'action', 'Practices of restoration and relaxation'),
  ('Prayer', 'prayer', 'action', 'Spiritual communication practices'),
  ('Reflection', 'reflection-action', 'action', 'Practices of contemplation and introspection');

-- Insert theme tags
INSERT INTO tags (name, slug, tag_type, description)
VALUES 
  ('Overcoming Challenges', 'overcoming-challenges', 'theme', 'Navigating and growing through difficulties'),
  ('Finding Purpose', 'finding-purpose', 'theme', 'Discovering meaning and direction in life'),
  ('Building Relationships', 'building-relationships', 'theme', 'Developing and nurturing connections with others'),
  ('Self-Care', 'self-care', 'theme', 'Practices that nurture personal wellbeing'),
  ('Mindfulness', 'mindfulness', 'theme', 'Present-moment awareness and attention'),
  ('Personal Growth', 'personal-growth', 'theme', 'Development and improvement of self'),
  ('Spiritual Growth', 'spiritual-growth', 'theme', 'Development of spiritual awareness and practices'),
  ('Community', 'community', 'theme', 'Connection to broader groups and society'),
  ('Nature Connection', 'nature-connection', 'theme', 'Relationship with the natural world'),
  ('Inner Peace', 'inner-peace', 'theme', 'Cultivating tranquility and calm within');

-- Insert source tags
INSERT INTO tags (name, slug, tag_type, description)
VALUES 
  ('Scripture', 'scripture', 'source', 'Content derived from or inspired by religious texts'),
  ('Philosopher', 'philosopher', 'source', 'Content from philosophical thinkers'),
  ('Poet', 'poet', 'source', 'Content from poetic sources'),
  ('Historical Figure', 'historical-figure', 'source', 'Content from notable figures in history'),
  ('Contemporary Author', 'contemporary-author', 'source', 'Content from modern writers and thinkers'),
  ('Spiritual Leader', 'spiritual-leader', 'source', 'Content from religious and spiritual guides'),
  ('Anonymous', 'anonymous', 'source', 'Content from unknown or traditional sources');

-- Create function to get content based on tags
CREATE OR REPLACE FUNCTION get_content_by_tags(
  p_user_id UUID,
  p_preferred_tags UUID[] DEFAULT NULL,
  p_avoided_tags UUID[] DEFAULT NULL
)
RETURNS TABLE (
  content_set_id UUID,
  title TEXT,
  paragraph_content TEXT,
  quote_content TEXT,
  quote_author TEXT,
  tags JSONB
) AS $$
BEGIN
  RETURN QUERY
  WITH user_history AS (
    -- Get content already delivered to the user
    SELECT content_set_id
    FROM content_delivery_history
    WHERE user_id = p_user_id
  ),
  content_with_tags AS (
    -- Get all content sets with their tags
    SELECT 
      cs.id,
      cs.title,
      cs.paragraph_content,
      cs.quote_content,
      cs.quote_author,
      jsonb_agg(
        jsonb_build_object(
          'id', t.id,
          'name', t.name,
          'type', t.tag_type
        )
      ) AS tags,
      COUNT(CASE WHEN p_preferred_tags IS NOT NULL AND t.id = ANY(p_preferred_tags) THEN 1 END) AS preferred_tag_count,
      COUNT(CASE WHEN p_avoided_tags IS NOT NULL AND t.id = ANY(p_avoided_tags) THEN 1 END) AS avoided_tag_count
    FROM content_sets cs
    JOIN content_set_tags cst ON cs.id = cst.content_set_id
    JOIN tags t ON cst.tag_id = t.id
    WHERE cs.is_active = true
    GROUP BY cs.id
  )
  SELECT 
    cwt.id AS content_set_id,
    cwt.title,
    cwt.paragraph_content,
    cwt.quote_content,
    cwt.quote_author,
    cwt.tags
  FROM content_with_tags cwt
  WHERE 
    -- Exclude content already delivered to the user
    cwt.id NOT IN (SELECT content_set_id FROM user_history)
    -- Exclude content with avoided tags (if specified)
    AND (p_avoided_tags IS NULL OR cwt.avoided_tag_count = 0)
  ORDER BY 
    -- Prioritize content with preferred tags (if specified)
    CASE WHEN p_preferred_tags IS NOT NULL THEN cwt.preferred_tag_count ELSE 0 END DESC,
    -- Add some randomness for variety
    RANDOM()
  LIMIT 10;
END;
$$ LANGUAGE plpgsql;

-- Create function to get user tag preferences
CREATE OR REPLACE FUNCTION get_user_tag_preferences(
  p_user_id UUID
)
RETURNS TABLE (
  preferred_tags UUID[],
  avoided_tags UUID[]
) AS $$
DECLARE
  v_preferred_tags UUID[];
  v_avoided_tags UUID[];
BEGIN
  -- Get preferred tags
  SELECT ARRAY_AGG(tag_id)
  INTO v_preferred_tags
  FROM user_tag_preferences
  WHERE user_id = p_user_id AND preference_type = 'prefer';
  
  -- Get avoided tags
  SELECT ARRAY_AGG(tag_id)
  INTO v_avoided_tags
  FROM user_tag_preferences
  WHERE user_id = p_user_id AND preference_type = 'avoid';
  
  RETURN QUERY
  SELECT v_preferred_tags, v_avoided_tags;
END;
$$ LANGUAGE plpgsql;

-- Update existing content sets to add content type tags
-- This assumes the existing content sets don't have content type tags yet
DO $$
DECLARE
  v_story_tag_id UUID;
  v_practical_tip_tag_id UUID;
  v_reflection_tag_id UUID;
  v_affirmation_tag_id UUID;
  v_content_set RECORD;
BEGIN
  -- Get tag IDs
  SELECT id INTO v_story_tag_id FROM tags WHERE slug = 'story';
  SELECT id INTO v_practical_tip_tag_id FROM tags WHERE slug = 'practical-tip';
  SELECT id INTO v_reflection_tag_id FROM tags WHERE slug = 'reflection';
  SELECT id INTO v_affirmation_tag_id FROM tags WHERE slug = 'affirmation';
  
  -- For existing content, we'll assign content types based on a simple heuristic
  -- In a real implementation, you would manually review and assign appropriate types
  FOR v_content_set IN SELECT id FROM content_sets LOOP
    -- For this example, we'll randomly assign content types
    -- In practice, you would use a more sophisticated approach
    CASE floor(random() * 4)
      WHEN 0 THEN
        INSERT INTO content_set_tags (content_set_id, tag_id)
        VALUES (v_content_set.id, v_story_tag_id)
        ON CONFLICT DO NOTHING;
      WHEN 1 THEN
        INSERT INTO content_set_tags (content_set_id, tag_id)
        VALUES (v_content_set.id, v_practical_tip_tag_id)
        ON CONFLICT DO NOTHING;
      WHEN 2 THEN
        INSERT INTO content_set_tags (content_set_id, tag_id)
        VALUES (v_content_set.id, v_reflection_tag_id)
        ON CONFLICT DO NOTHING;
      WHEN 3 THEN
        INSERT INTO content_set_tags (content_set_id, tag_id)
        VALUES (v_content_set.id, v_affirmation_tag_id)
        ON CONFLICT DO NOTHING;
    END CASE;
  END LOOP;
END $$;
