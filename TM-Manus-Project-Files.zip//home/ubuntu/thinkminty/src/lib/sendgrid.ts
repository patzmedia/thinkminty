import sgMail from '@sendgrid/mail';

// Initialize SendGrid with API key
if (process.env.SENDGRID_API_KEY) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
}

export interface EmailData {
  to: string | string[];
  from: string;
  subject: string;
  text?: string;
  html: string;
  templateId?: string;
  dynamicTemplateData?: Record<string, any>;
  attachments?: any[];
  categories?: string[];
}

export const sendEmail = async (data: EmailData) => {
  try {
    const response = await sgMail.send(data);
    return { success: true, response };
  } catch (error) {
    console.error('SendGrid error:', error);
    return { success: false, error };
  }
};

export const sendNewsletterEmail = async (
  subscribers: string[],
  subject: string,
  content: string,
  templateId?: string,
  dynamicTemplateData?: Record<string, any>
) => {
  // Split subscribers into batches of 1000 to avoid SendGrid limits
  const batchSize = 1000;
  const batches = [];
  
  for (let i = 0; i < subscribers.length; i += batchSize) {
    batches.push(subscribers.slice(i, i + batchSize));
  }
  
  const results = [];
  
  for (const batch of batches) {
    try {
      const emailData: EmailData = {
        to: batch,
        from: process.env.SENDGRID_FROM_EMAIL || 'newsletter@thinkminty.com',
        subject,
        html: content,
      };
      
      if (templateId) {
        emailData.templateId = templateId;
        emailData.dynamicTemplateData = dynamicTemplateData;
      }
      
      const result = await sgMail.sendMultiple(emailData);
      results.push({ success: true, result });
    } catch (error) {
      console.error('SendGrid batch error:', error);
      results.push({ success: false, error });
    }
  }
  
  return results;
};
