# ThinkMinty Database Schema Update for Content Categories and Personalization

## New Tables

### 1. Content Categories

```sql
CREATE TABLE content_categories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  parent_id UUID REFERENCES content_categories(id),
  image_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add indexes
CREATE INDEX idx_content_categories_slug ON content_categories(slug);
CREATE INDEX idx_content_categories_parent_id ON content_categories(parent_id);
```

### 2. Content Sets

```sql
CREATE TABLE content_sets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(255) NOT NULL,
  paragraph_content TEXT NOT NULL,
  quote_content TEXT NOT NULL,
  quote_author VARCHAR(255),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 3. Content Set Categories (Many-to-Many)

```sql
CREATE TABLE content_set_categories (
  content_set_id UUID REFERENCES content_sets(id) ON DELETE CASCADE,
  category_id UUID REFERENCES content_categories(id) ON DELETE CASCADE,
  PRIMARY KEY (content_set_id, category_id)
);

-- Add indexes
CREATE INDEX idx_content_set_categories_content_set_id ON content_set_categories(content_set_id);
CREATE INDEX idx_content_set_categories_category_id ON content_set_categories(category_id);
```

### 4. User Preferences

```sql
CREATE TABLE user_preferences (
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  category_id UUID REFERENCES content_categories(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  PRIMARY KEY (user_id, category_id)
);

-- Add indexes
CREATE INDEX idx_user_preferences_user_id ON user_preferences(user_id);
CREATE INDEX idx_user_preferences_category_id ON user_preferences(category_id);
```

### 5. Content Delivery History

```sql
CREATE TABLE content_delivery_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  content_set_id UUID REFERENCES content_sets(id) ON DELETE CASCADE,
  delivered_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add indexes
CREATE INDEX idx_content_delivery_history_user_id ON content_delivery_history(user_id);
CREATE INDEX idx_content_delivery_history_content_set_id ON content_delivery_history(content_set_id);
CREATE INDEX idx_content_delivery_history_delivered_at ON content_delivery_history(delivered_at);
```

## Initial Category Data

```sql
-- Main categories
INSERT INTO content_categories (name, slug, description, display_order) VALUES
('Mindful Moments', 'mindful-moments', 'Focusing on present-moment awareness and inner peace. Content includes short guided meditations, simple breathing exercises, and reflections on gratitude and appreciation. Aimed for those seeking calm, reduced anxiety, and a deeper connection to themselves.', 1),
('Resilience Recharge', 'resilience-recharge', 'Focusing on building inner strength and bouncing back from adversity. Content includes stories of overcoming challenges, practical tips for coping with stress, and affirmations for building self-confidence. For those facing challenges and needing to build mental fortitude.', 2),
('Joyful Living', 'joyful-living', 'Focusing on all sources of joy and happiness. Content includes humorous anecdotes and lighthearted stories, tips for finding joy in everyday moments, and celebrations of small victories. For those wanting to add more lightheartedness to their days.', 3),
('Purposeful Path', 'purposeful-path', 'Focusing on finding meaning and direction in life. Content includes inspiring stories of people living their purpose, practical exercises for setting and achieving goals, and reflections on values and priorities. For those seeking direction and fulfillment.', 4),
('Connection & Kindness', 'connection-kindness', 'Focusing on the power of human connection and acts of kindness. Content includes stories of inspiring acts of kindness or sacrifice, tips for building stronger relationships, and reminders to practice empathy and compassion. For those who value community and want to make a positive impact.', 5),
('Calm & Comfort', 'calm-comfort', 'Focusing on the power of compassion and finding inner peace through encouragement. Content includes soothing affirmations, gentle encouragement, reminders of self-compassion, and encouraging stories of overcoming difficult situations. For those seeking a soft, gentle, and safe space.', 6);

-- Subcategories for Mindful Moments
INSERT INTO content_categories (name, slug, description, parent_id, display_order)
SELECT 'Affirmative', 'affirmative', 'Positive affirmations and self-talk to build inner peace', id, 1
FROM content_categories WHERE slug = 'mindful-moments';

INSERT INTO content_categories (name, slug, description, parent_id, display_order)
SELECT 'Spiritual', 'spiritual', 'Content focused on spiritual growth and connection', id, 2
FROM content_categories WHERE slug = 'mindful-moments';

-- Subcategories for Resilience Recharge
INSERT INTO content_categories (name, slug, description, parent_id, display_order)
SELECT 'Encouraging', 'encouraging', 'Content that provides encouragement during difficult times', id, 1
FROM content_categories WHERE slug = 'resilience-recharge';

-- Subcategories for Joyful Living
INSERT INTO content_categories (name, slug, description, parent_id, display_order)
SELECT 'Funny', 'funny', 'Humorous content to brighten your day', id, 1
FROM content_categories WHERE slug = 'joyful-living';

-- Subcategories for Purposeful Path
INSERT INTO content_categories (name, slug, description, parent_id, display_order)
SELECT 'Motivational', 'motivational', 'Content that motivates and inspires action', id, 1
FROM content_categories WHERE slug = 'purposeful-path';

INSERT INTO content_categories (name, slug, description, parent_id, display_order)
SELECT 'Success', 'success', 'Stories and tips about achieving success and fulfillment', id, 2
FROM content_categories WHERE slug = 'purposeful-path';

-- Subcategories for Connection & Kindness
INSERT INTO content_categories (name, slug, description, parent_id, display_order)
SELECT 'Community', 'community', 'Content focused on building and nurturing community', id, 1
FROM content_categories WHERE slug = 'connection-kindness';

INSERT INTO content_categories (name, slug, description, parent_id, display_order)
SELECT 'Relationships', 'relationships', 'Content about developing meaningful relationships', id, 2
FROM content_categories WHERE slug = 'connection-kindness';

-- Subcategories for Calm & Comfort
INSERT INTO content_categories (name, slug, description, parent_id, display_order)
SELECT 'Encouraging', 'encouraging-calm', 'Gentle encouragement for finding peace', id, 1
FROM content_categories WHERE slug = 'calm-comfort';
```

## Database Functions

### 1. Get User Preferred Content

```sql
CREATE OR REPLACE FUNCTION get_user_preferred_content(user_id UUID)
RETURNS TABLE (
  content_set_id UUID,
  title VARCHAR(255),
  paragraph_content TEXT,
  quote_content TEXT,
  quote_author VARCHAR(255),
  category_names TEXT[]
) AS $$
BEGIN
  RETURN QUERY
  WITH user_categories AS (
    SELECT category_id FROM user_preferences WHERE user_id = $1
  ),
  delivered_content AS (
    SELECT content_set_id FROM content_delivery_history WHERE user_id = $1
  ),
  available_content AS (
    SELECT DISTINCT cs.id
    FROM content_sets cs
    JOIN content_set_categories csc ON cs.id = csc.content_set_id
    JOIN user_categories uc ON csc.category_id = uc.category_id
    WHERE cs.is_active = TRUE
    AND cs.id NOT IN (SELECT content_set_id FROM delivered_content)
  ),
  random_content AS (
    SELECT ac.id
    FROM available_content ac
    ORDER BY RANDOM()
    LIMIT 1
  )
  SELECT 
    cs.id,
    cs.title,
    cs.paragraph_content,
    cs.quote_content,
    cs.quote_author,
    ARRAY_AGG(cc.name) as category_names
  FROM content_sets cs
  JOIN random_content rc ON cs.id = rc.id
  JOIN content_set_categories csc ON cs.id = csc.content_set_id
  JOIN content_categories cc ON csc.category_id = cc.id
  GROUP BY cs.id, cs.title, cs.paragraph_content, cs.quote_content, cs.quote_author;
END;
$$ LANGUAGE plpgsql;
```

### 2. Record Content Delivery

```sql
CREATE OR REPLACE FUNCTION record_content_delivery(user_id UUID, content_set_id UUID)
RETURNS VOID AS $$
BEGIN
  INSERT INTO content_delivery_history (user_id, content_set_id)
  VALUES (user_id, content_set_id);
END;
$$ LANGUAGE plpgsql;
```
