// Additional content examples for ThinkMinty

// MINDFUL MOMENTS - Additional Examples

// Example 2
const mindfulMoments2 = {
  title: "Gratitude Practice",
  paragraph_content: "Take a moment to reflect on three things you're grateful for today. They can be as simple as a warm cup of tea or as profound as a loving relationship. Gratitude shifts our focus from what's lacking to what's abundant in our lives. This simple practice can transform your outlook and bring a sense of contentment to your day.",
  quote_content: "Gratitude turns what we have into enough.",
  quote_author: "Melody Beattie",
  category: "Mindful Moments"
};

// Example 3
const mindfulMoments3 = {
  title: "Nature Connection",
  paragraph_content: "Step outside and notice the natural world around you. Feel the air on your skin, listen to the sounds of birds or rustling leaves, observe the colors and shapes of plants. Nature has a way of bringing us into the present moment and reminding us of our connection to something larger than ourselves.",
  quote_content: "Look deep into nature, and then you will understand everything better.",
  quote_author: "Albert Einstein",
  category: "Mindful Moments"
};

// Example 4
const mindfulMoments4 = {
  title: "Mindful Eating",
  paragraph_content: "For your next meal, try eating with full awareness. Notice the colors, textures, and aromas of your food. Take small bites and chew slowly, savoring each flavor. When we eat mindfully, we not only enjoy our food more deeply but also become more attuned to what our body truly needs.",
  quote_content: "When walking, walk. When eating, eat.",
  quote_author: "Zen Proverb",
  category: "Mindful Moments"
};

// RESILIENCE RECHARGE - Additional Examples

// Example 2
const resilienceRecharge2 = {
  title: "Growth Through Challenges",
  paragraph_content: "Every challenge you face is an opportunity for growth. When you encounter difficulties, ask yourself: 'What can I learn from this?' This simple shift in perspective transforms obstacles into stepping stones for personal development. Remember that your capacity for resilience grows stronger with each challenge you overcome.",
  quote_content: "The greatest glory in living lies not in never falling, but in rising every time we fall.",
  quote_author: "Nelson Mandela",
  category: "Resilience Recharge"
};

// Example 3
const resilienceRecharge3 = {
  title: "Inner Strength Reminder",
  paragraph_content: "Take a moment to recall a time when you faced a significant challenge and persevered. Remember how you felt, what resources you drew upon, and how you ultimately moved forward. This memory is evidence of your inner strength and resilience. You've overcome difficulties before, and you have that same strength within you now.",
  quote_content: "You have power over your mind—not outside events. Realize this, and you will find strength.",
  quote_author: "Marcus Aurelius",
  category: "Resilience Recharge"
};

// Example 4
const resilienceRecharge4 = {
  title: "Adapting to Change",
  paragraph_content: "Change is inevitable, but our response to it is within our control. When facing unexpected transitions, take a deep breath and remind yourself that adaptation is a natural human strength. Focus on what you can influence rather than what you cannot. Small adjustments each day build the flexibility that helps us thrive through life's changes.",
  quote_content: "It is not the strongest of the species that survive, nor the most intelligent, but the one most responsive to change.",
  quote_author: "Charles Darwin",
  category: "Resilience Recharge"
};

// JOYFUL LIVING - Additional Examples

// Example 2
const joyfulLiving2 = {
  title: "Laughter as Medicine",
  paragraph_content: "Make time for laughter today. Watch a funny video, share a joke with a friend, or recall a humorous memory. Laughter releases endorphins, reduces stress, and connects us with others. It's one of life's simplest yet most powerful pleasures, instantly shifting our perspective and lightening our mood.",
  quote_content: "A good laugh is sunshine in the house.",
  quote_author: "William Makepeace Thackeray",
  category: "Joyful Living"
};

// Example 3
const joyfulLiving3 = {
  title: "Playful Spirit",
  paragraph_content: "Reconnect with your playful spirit today. Whether it's dancing to your favorite song, playing a game, or simply being silly for a moment, playfulness brings joy and creativity into our lives. As adults, we often forget the importance of play, yet it remains essential for our wellbeing and zest for life.",
  quote_content: "We don't stop playing because we grow old; we grow old because we stop playing.",
  quote_author: "George Bernard Shaw",
  category: "Joyful Living"
};

// Example 4
const joyfulLiving4 = {
  title: "Celebrating Small Wins",
  paragraph_content: "Take time to celebrate your small victories today. Completed a task? Learned something new? Helped someone out? Acknowledge these moments. By recognizing and celebrating small wins, we train our minds to notice the positive aspects of our lives, creating a foundation for greater joy and satisfaction.",
  quote_content: "Enjoy the little things, for one day you may look back and realize they were the big things.",
  quote_author: "Robert Brault",
  category: "Joyful Living"
};

// PURPOSEFUL PATH - Additional Examples

// Example 2
const purposefulPath2 = {
  title: "Values Alignment",
  paragraph_content: "Consider what truly matters to you. Is it creativity, connection, learning, or service to others? When we align our daily actions with our core values, we experience greater fulfillment and purpose. Today, choose one activity that reflects something you deeply value, and notice how it affects your sense of meaning.",
  quote_content: "The purpose of life is not to be happy. It is to be useful, to be honorable, to be compassionate, to have it make some difference that you have lived and lived well.",
  quote_author: "Ralph Waldo Emerson",
  category: "Purposeful Path"
};

// Example 3
const purposefulPath3 = {
  title: "Small Steps Forward",
  paragraph_content: "Purpose isn't always found in grand gestures or major life changes. Often, it's in the small, consistent steps we take toward meaningful goals. Today, identify one small action you can take that connects to your larger sense of purpose. Remember that even tiny steps in the right direction create momentum and meaning.",
  quote_content: "The meaning of life is to find your gift. The purpose of life is to give it away.",
  quote_author: "Pablo Picasso",
  category: "Purposeful Path"
};

// Example 4
const purposefulPath4 = {
  title: "Legacy Thinking",
  paragraph_content: "Consider what you'd like your legacy to be. How do you want to be remembered? What impact do you hope to have on others and the world? This perspective can clarify what matters most to you and guide your choices today. Your purpose unfolds in the present through the values you embody and the contributions you make.",
  quote_content: "The two most important days in your life are the day you are born and the day you find out why.",
  quote_author: "Mark Twain",
  category: "Purposeful Path"
};

// CONNECTION & KINDNESS - Additional Examples

// Example 2
const connectionKindness2 = {
  title: "Active Listening",
  paragraph_content: "The next time someone speaks to you, practice truly listening. Set aside distractions, make eye contact, and focus fully on understanding rather than preparing your response. Active listening is one of the greatest gifts we can offer others, creating space for authentic connection and mutual understanding.",
  quote_content: "Listening is an act of love.",
  quote_author: "Dave Isay",
  category: "Connection & Kindness"
};

// Example 3
const connectionKindness3 = {
  title: "Unexpected Kindness",
  paragraph_content: "Consider performing an unexpected act of kindness today. Leave an encouraging note, send a thoughtful message, or offer help without being asked. These small gestures create ripples of positivity that extend far beyond the initial act. In a world where you can be anything, choose to be kind.",
  quote_content: "No act of kindness, no matter how small, is ever wasted.",
  quote_author: "Aesop",
  category: "Connection & Kindness"
};

// Example 4
const connectionKindness4 = {
  title: "Self-Compassion Practice",
  paragraph_content: "Extend the same kindness to yourself that you would offer to a good friend. Speak to yourself with understanding rather than criticism. Acknowledge your humanity and imperfections with gentleness. Self-compassion isn't self-indulgence—it's the foundation for authentic connection with others and a more fulfilling life.",
  quote_content: "You yourself, as much as anybody in the entire universe, deserve your love and affection.",
  quote_author: "Buddha",
  category: "Connection & Kindness"
};

// CALM & COMFORT - Additional Examples

// Example 2
const calmComfort2 = {
  title: "Creating Sanctuary",
  paragraph_content: "Create a small sanctuary in your home or workspace—a corner with items that bring you comfort and peace. Perhaps a soft blanket, a beautiful plant, or a meaningful photo. Having a dedicated space for calm can provide refuge during stressful moments and remind you to pause and breathe throughout your day.",
  quote_content: "Peace is not the absence of trouble, but the presence of God.",
  quote_author: "J.C. Macaulay",
  category: "Calm & Comfort"
};

// Example 3
const calmComfort3 = {
  title: "Gentle Movement",
  paragraph_content: "When feeling overwhelmed, try gentle movement to restore calm. Stretch your arms overhead, roll your shoulders, or take a slow walk. Our bodies and minds are interconnected—physical movement can release tension and shift our emotional state. Move with kindness toward yourself, without pushing or straining.",
  quote_content: "Movement is a medicine for creating change in a person's physical, emotional, and mental states.",
  quote_author: "Carol Welch",
  category: "Calm & Comfort"
};

// Example 4
const calmComfort4 = {
  title: "Evening Wind-Down",
  paragraph_content: "Create a gentle evening ritual to signal to your body and mind that it's time to rest. Perhaps a warm drink, a few minutes of reading, or simply washing your face mindfully. These small acts of self-care can ease the transition from day to night, inviting restfulness and peace as you prepare for sleep.",
  quote_content: "Each night, when I go to sleep, I die. And the next morning, when I wake up, I am reborn.",
  quote_author: "Mahatma Gandhi",
  category: "Calm & Comfort"
};

// Export all examples in a format ready for database insertion
const additionalContentExamples = [
  mindfulMoments2, mindfulMoments3, mindfulMoments4,
  resilienceRecharge2, resilienceRecharge3, resilienceRecharge4,
  joyfulLiving2, joyfulLiving3, joyfulLiving4,
  purposefulPath2, purposefulPath3, purposefulPath4,
  connectionKindness2, connectionKindness3, connectionKindness4,
  calmComfort2, calmComfort3, calmComfort4
];

// This file can be used to generate SQL inserts or directly imported in a Node.js environment
// to populate the database with additional content examples
