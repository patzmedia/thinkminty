'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface NewsletterFormProps {
  variant?: 'inline' | 'card';
  title?: string;
  description?: string;
}

export default function NewsletterSubscribeForm({
  variant = 'card',
  title = 'Subscribe to Our Newsletter',
  description = 'Get the latest positive content and updates delivered to your inbox.'
}: NewsletterFormProps) {
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Check if subscriber already exists
      const { data: existingSubscriber, error: checkError } = await supabase
        .from('newsletter_subscribers')
        .select('id, is_active')
        .eq('email', email)
        .maybeSingle();

      if (checkError) {
        throw checkError;
      }

      if (existingSubscriber) {
        if (existingSubscriber.is_active) {
          setSuccess(true);
          return;
        } else {
          // Reactivate subscriber
          const { error: updateError } = await supabase
            .from('newsletter_subscribers')
            .update({ 
              is_active: true,
              first_name: firstName || null,
              updated_at: new Date().toISOString()
            })
            .eq('email', email);

          if (updateError) {
            throw updateError;
          }
        }
      } else {
        // Create new subscriber
        const { error: insertError } = await supabase
          .from('newsletter_subscribers')
          .insert({
            email,
            first_name: firstName || null
          });

        if (insertError) {
          throw insertError;
        }
      }

      // Subscribe to default newsletter
      const { data: defaultNewsletter, error: newsletterError } = await supabase
        .from('newsletters')
        .select('id')
        .eq('is_active', true)
        .single();

      if (!newsletterError && defaultNewsletter) {
        const { data: subscriber, error: subscriberError } = await supabase
          .from('newsletter_subscribers')
          .select('id')
          .eq('email', email)
          .single();

        if (!subscriberError && subscriber) {
          await supabase
            .from('newsletter_subscriptions')
            .upsert({
              subscriber_id: subscriber.id,
              newsletter_id: defaultNewsletter.id
            });
        }
      }

      setSuccess(true);
      
      // Send welcome email via API
      await fetch('/api/send-welcome-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          firstName: firstName || undefined,
        }),
      });
      
    } catch (error: any) {
      setError(error.message || 'An error occurred while subscribing');
      console.error('Newsletter subscription error:', error);
    } finally {
      setLoading(false);
    }
  };

  if (variant === 'inline') {
    return (
      <div className="w-full">
        {success ? (
          <div className="bg-green-50 text-green-800 p-4 rounded-md">
            <p className="font-medium">Thank you for subscribing!</p>
            <p className="text-sm mt-1">We've sent a welcome email to your inbox.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email address"
              className="flex-grow px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
            />
            <button
              type="submit"
              disabled={loading}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-md font-medium transition-colors"
            >
              {loading ? 'Subscribing...' : 'Subscribe'}
            </button>
          </form>
        )}
        {error && (
          <div className="mt-2 text-red-600 text-sm">
            {error}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      
      {success ? (
        <div className="bg-green-50 text-green-800 p-4 rounded-md">
          <p className="font-medium">Thank you for subscribing!</p>
          <p className="text-sm mt-1">We've sent a welcome email to your inbox.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="firstName" className="block text-gray-700 mb-1 text-sm">
              First Name (Optional)
            </label>
            <input
              id="firstName"
              type="text"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="email" className="block text-gray-700 mb-1 text-sm">
              Email Address
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
            />
          </div>
          
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2 rounded-md font-medium transition-colors"
          >
            {loading ? 'Subscribing...' : 'Subscribe'}
          </button>
          
          {error && (
            <div className="mt-2 text-red-600 text-sm">
              {error}
            </div>
          )}
          
          <p className="mt-3 text-xs text-gray-500 text-center">
            By subscribing, you agree to our Privacy Policy and consent to receive updates from ThinkMinty.
          </p>
        </form>
      )}
    </div>
  );
}
