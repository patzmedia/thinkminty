'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { sendEmail } from '@/lib/sendgrid';

interface NewsletterIssue {
  id: string;
  title: string;
  subject: string;
  content: string;
  status: 'draft' | 'scheduled' | 'sent';
  scheduled_for: string | null;
  sent_at: string | null;
  created_at: string;
  updated_at: string;
}

export default function NewsletterEditor({
  initialData,
  isEditing = false,
}: {
  initialData?: Partial<NewsletterIssue>;
  isEditing?: boolean;
}) {
  const [title, setTitle] = useState(initialData?.title || '');
  const [subject, setSubject] = useState(initialData?.subject || '');
  const [content, setContent] = useState(initialData?.content || '');
  const [status, setStatus] = useState<'draft' | 'scheduled' | 'sent'>(
    initialData?.status || 'draft'
  );
  const [scheduledFor, setScheduledFor] = useState(
    initialData?.scheduled_for ? new Date(initialData.scheduled_for).toISOString().slice(0, 16) : ''
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [subscriberCount, setSubscriberCount] = useState(0);

  useEffect(() => {
    const fetchSubscriberCount = async () => {
      try {
        const { count, error } = await supabase
          .from('newsletter_subscribers')
          .select('*', { count: 'exact', head: true })
          .eq('is_active', true);

        if (error) {
          throw error;
        }

        setSubscriberCount(count || 0);
      } catch (error) {
        console.error('Error fetching subscriber count:', error);
      }
    };

    fetchSubscriberCount();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const newsletterId = initialData?.id || 'default';
      const newStatus = status === 'scheduled' && !scheduledFor ? 'draft' : status;
      
      const issueData = {
        title,
        subject,
        content,
        status: newStatus,
        scheduled_for: newStatus === 'scheduled' ? scheduledFor : null,
        updated_at: new Date().toISOString(),
      };

      if (isEditing && initialData?.id) {
        // Update existing issue
        const { error } = await supabase
          .from('newsletter_issues')
          .update(issueData)
          .eq('id', initialData.id);

        if (error) throw error;
      } else {
        // Create new issue
        const { error } = await supabase
          .from('newsletter_issues')
          .insert({
            ...issueData,
            newsletter_id: newsletterId,
          });

        if (error) throw error;
      }

      setSuccess(true);
      
      // If status is sent, trigger the send-newsletter API
      if (newStatus === 'sent') {
        const sendResponse = await fetch('/api/send-newsletter', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            issueId: initialData?.id,
            subject,
            content,
          }),
        });
        
        if (!sendResponse.ok) {
          const errorData = await sendResponse.json();
          throw new Error(errorData.error || 'Failed to send newsletter');
        }
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred while saving the newsletter');
      console.error('Error saving newsletter:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">
          {isEditing ? 'Edit Newsletter Issue' : 'Create Newsletter Issue'}
        </h2>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-500">
            {subscriberCount} active subscribers
          </span>
          <button
            type="button"
            onClick={() => setPreviewMode(!previewMode)}
            className="px-4 py-2 bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200"
          >
            {previewMode ? 'Edit' : 'Preview'}
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}

      {success && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          Newsletter {isEditing ? 'updated' : 'created'} successfully!
          {status === 'sent' && ' Newsletter has been sent to all subscribers.'}
        </div>
      )}

      {previewMode ? (
        <div className="border border-gray-200 rounded-md p-6">
          <h3 className="text-xl font-bold mb-2">{subject || 'Newsletter Subject'}</h3>
          <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: content }} />
          <button
            type="button"
            onClick={() => setPreviewMode(false)}
            className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
          >
            Back to Editing
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="title" className="block text-gray-700 mb-2">
              Internal Title (not shown to subscribers)
            </label>
            <input
              id="title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
            />
          </div>

          <div className="mb-4">
            <label htmlFor="subject" className="block text-gray-700 mb-2">
              Email Subject Line
            </label>
            <input
              id="subject"
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
            />
          </div>

          <div className="mb-4">
            <label htmlFor="content" className="block text-gray-700 mb-2">
              Email Content (HTML)
            </label>
            <textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
              rows={15}
              required
            />
            <p className="text-xs text-gray-500 mt-1">
              You can use HTML tags to format your newsletter.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label htmlFor="status" className="block text-gray-700 mb-2">
                Status
              </label>
              <select
                id="status"
                value={status}
                onChange={(e) => setStatus(e.target.value as 'draft' | 'scheduled' | 'sent')}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              >
                <option value="draft">Draft</option>
                <option value="scheduled">Scheduled</option>
                <option value="sent">Send Immediately</option>
              </select>
            </div>

            {status === 'scheduled' && (
              <div>
                <label htmlFor="scheduledFor" className="block text-gray-700 mb-2">
                  Schedule Date and Time
                </label>
                <input
                  id="scheduledFor"
                  type="datetime-local"
                  value={scheduledFor}
                  onChange={(e) => setScheduledFor(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required={status === 'scheduled'}
                />
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => window.history.back()}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
            >
              {loading
                ? 'Saving...'
                : status === 'sent'
                ? 'Save & Send'
                : isEditing
                ? 'Update'
                : 'Create'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
