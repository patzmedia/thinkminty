'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { sendgrid } from '@/lib/sendgrid';

interface PersonalizedNewsletterProps {
  onComplete?: () => void;
}

export default function PersonalizedNewsletter({ onComplete }: PersonalizedNewsletterProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(true);
  const [newsletterTitle, setNewsletterTitle] = useState('Your Daily Positive Content');
  const [newsletterSubtitle, setNewsletterSubtitle] = useState('Personalized content to brighten your day');
  const [customIntro, setCustomIntro] = useState('');
  const [customOutro, setCustomOutro] = useState('');
  const [previewHtml, setPreviewHtml] = useState<string | null>(null);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [users, setUsers] = useState<{id: string, email: string}[]>([]);
  const [sendToAll, setSendToAll] = useState(false);
  const [scheduleTime, setScheduleTime] = useState('');
  const [sendNow, setSendNow] = useState(true);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      // Get users with preferences
      const { data, error } = await supabase
        .from('user_preferences')
        .select(`
          user_id,
          user:user_id(email)
        `)
        .order('user_id');

      if (error) throw error;
      
      // Remove duplicates (users with multiple preferences)
      const uniqueUsers = Array.from(
        new Map(data.map(item => [item.user_id, { id: item.user_id, email: item.user.email }]))
        .values()
      );
      
      setUsers(uniqueUsers);
    } catch (error: any) {
      console.error('Error fetching users:', error);
      setError('Failed to load users. Please try again later.');
    }
  };

  const generatePreview = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      // Get a sample user with preferences
      const sampleUserId = users.length > 0 ? users[0].id : null;
      
      if (!sampleUserId) {
        throw new Error('No users available for preview');
      }
      
      // Find matching content for the sample user
      const { data, error } = await supabase.rpc('get_user_preferred_content', {
        user_id: sampleUserId
      });
      
      if (error) throw error;
      
      if (!data || data.length === 0) {
        throw new Error('No matching content found for preview. Try adding more content sets.');
      }
      
      // Generate HTML preview
      const contentHtml = generateNewsletterHtml(
        newsletterTitle,
        newsletterSubtitle,
        customIntro,
        data[0],
        customOutro,
        users.find(u => u.id === sampleUserId)?.email || 'sample@example.com'
      );
      
      setPreviewHtml(contentHtml);
      setSuccess('Preview generated successfully');
    } catch (error: any) {
      setError(error.message || 'An error occurred while generating preview');
      console.error('Preview generation error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSendNewsletter = async () => {
    if (!sendToAll && selectedUsers.length === 0) {
      setError('Please select at least one user');
      return;
    }
    
    if (!sendNow && !scheduleTime) {
      setError('Please select a schedule time');
      return;
    }
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      const targetUsers = sendToAll ? users : users.filter(user => selectedUsers.includes(user.id));
      
      // For each user, find matching content and send personalized newsletter
      let successCount = 0;
      let errorCount = 0;
      
      for (const user of targetUsers) {
        try {
          // Find matching content for the user
          const { data, error } = await supabase.rpc('get_user_preferred_content', {
            user_id: user.id
          });
          
          if (error) throw error;
          
          if (!data || data.length === 0) {
            console.warn(`No matching content found for user ${user.email}`);
            errorCount++;
            continue;
          }
          
          // Generate personalized newsletter
          const contentHtml = generateNewsletterHtml(
            newsletterTitle,
            newsletterSubtitle,
            customIntro,
            data[0],
            customOutro,
            user.email
          );
          
          // Send email via SendGrid
          // Note: In a real implementation, this would use the SendGrid API
          // For this demo, we'll just simulate the sending
          console.log(`Sending newsletter to ${user.email}`);
          
          // Record content delivery
          await supabase.rpc('record_content_delivery', {
            user_id: user.id,
            content_set_id: data[0].content_set_id
          });
          
          successCount++;
        } catch (userError) {
          console.error(`Error processing user ${user.email}:`, userError);
          errorCount++;
        }
      }
      
      if (successCount > 0) {
        setSuccess(`Successfully sent newsletters to ${successCount} users${errorCount > 0 ? ` (${errorCount} failed)` : ''}`);
      } else {
        setError('Failed to send newsletters to any users');
      }
      
      if (onComplete) {
        onComplete();
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred while sending newsletters');
      console.error('Newsletter sending error:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateNewsletterHtml = (
    title: string,
    subtitle: string,
    intro: string,
    content: any,
    outro: string,
    recipientEmail: string
  ) => {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${title}</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
          }
          .logo {
            font-size: 24px;
            font-weight: bold;
            color: #10b981;
          }
          .title {
            font-size: 28px;
            margin: 20px 0 5px;
            color: #10b981;
          }
          .subtitle {
            font-size: 16px;
            margin: 0 0 30px;
            color: #6b7280;
          }
          .content {
            background-color: #f9fafb;
            padding: 25px;
            border-radius: 8px;
            margin-bottom: 30px;
          }
          .quote {
            font-style: italic;
            border-left: 3px solid #10b981;
            padding-left: 15px;
            margin: 20px 0;
          }
          .quote-author {
            text-align: right;
            font-size: 14px;
            color: #6b7280;
          }
          .footer {
            text-align: center;
            font-size: 12px;
            color: #6b7280;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
          }
          .intro, .outro {
            margin-bottom: 20px;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo">ThinkMinty</div>
          <h1 class="title">${title}</h1>
          <p class="subtitle">${subtitle}</p>
        </div>
        
        ${intro ? `<div class="intro">${intro}</div>` : ''}
        
        <div class="content">
          <p>${content.paragraph_content}</p>
          
          <div class="quote">
            <p>${content.quote_content}</p>
            ${content.quote_author ? `<p class="quote-author">— ${content.quote_author}</p>` : ''}
          </div>
        </div>
        
        ${outro ? `<div class="outro">${outro}</div>` : ''}
        
        <div class="footer">
          <p>This content was selected just for you based on your preferences.</p>
          <p>Sent to: ${recipientEmail}</p>
          <p>ThinkMinty &copy; ${new Date().getFullYear()}</p>
          <p><a href="https://thinkminty.com/unsubscribe">Unsubscribe</a> | <a href="https://thinkminty.com/preferences">Update Preferences</a></p>
        </div>
      </body>
      </html>
    `;
  };

  const handleUserSelection = (userId: string) => {
    setSelectedUsers(prev => {
      if (prev.includes(userId)) {
        return prev.filter(id => id !== userId);
      } else {
        return [...prev, userId];
      }
    });
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Personalized Newsletter</h2>
      
      <div className="mb-6">
        <div className="flex space-x-4 mb-4">
          <label className="flex items-center">
            <input
              type="radio"
              checked={previewMode}
              onChange={() => setPreviewMode(true)}
              className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300"
            />
            <span className="ml-2 text-gray-700">Preview Mode</span>
          </label>
          
          <label className="flex items-center">
            <input
              type="radio"
              checked={!previewMode}
              onChange={() => setPreviewMode(false)}
              className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300"
            />
            <span className="ml-2 text-gray-700">Send Mode</span>
          </label>
        </div>
      </div>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          {success}
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold mb-4">Newsletter Settings</h3>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-gray-700 mb-1">
                Newsletter Title
              </label>
              <input
                id="title"
                type="text"
                value={newsletterTitle}
                onChange={(e) => setNewsletterTitle(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            
            <div>
              <label htmlFor="subtitle" className="block text-gray-700 mb-1">
                Newsletter Subtitle
              </label>
              <input
                id="subtitle"
                type="text"
                value={newsletterSubtitle}
                onChange={(e) => setNewsletterSubtitle(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            
            <div>
              <label htmlFor="intro" className="block text-gray-700 mb-1">
                Custom Introduction (Optional)
              </label>
              <textarea
                id="intro"
                value={customIntro}
                onChange={(e) => setCustomIntro(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                rows={3}
                placeholder="Add a custom introduction to your newsletter..."
              />
            </div>
            
            <div>
              <label htmlFor="outro" className="block text-gray-700 mb-1">
                Custom Conclusion (Optional)
              </label>
              <textarea
                id="outro"
                value={customOutro}
                onChange={(e) => setCustomOutro(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                rows={3}
                placeholder="Add a custom conclusion to your newsletter..."
              />
            </div>
            
            {previewMode ? (
              <button
                onClick={generatePreview}
                disabled={loading}
                className="w-full px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
              >
                {loading ? 'Generating...' : 'Generate Preview'}
              </button>
            ) : (
              <>
                <div>
                  <label className="flex items-center mb-2">
                    <input
                      type="checkbox"
                      checked={sendToAll}
                      onChange={(e) => setSendToAll(e.target.checked)}
                      className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300 rounded"
                    />
                    <span className="ml-2 text-gray-700">Send to All Users</span>
                  </label>
                  
                  {!sendToAll && (
                    <div className="max-h-60 overflow-y-auto border border-gray-200 rounded-md p-2">
                      {users.length === 0 ? (
                        <p className="text-gray-500 text-sm p-2">No users available</p>
                      ) : (
                        users.map((user) => (
                          <label key={user.id} className="flex items-center p-2 hover:bg-gray-50">
                            <input
                              type="checkbox"
                              checked={selectedUsers.includes(user.id)}
                              onChange={() => handleUserSelection(user.id)}
                              className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300 rounded"
                            />
                            <span className="ml-2 text-gray-700 text-sm">{user.email}</span>
                          </label>
                        ))
                      )}
                    </div>
                  )}
                </div>
                
                <div>
                  <label className="flex items-center mb-2">
                    <input
                      type="checkbox"
                      checked={sendNow}
                      onChange={(e) => setSendNow(e.target.checked)}
                      className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300 rounded"
                    />
                    <span className="ml-2 text-gray-700">Send Immediately</span>
                  </label>
                  
                  {!sendNow && (
                    <input
                      type="datetime-local"
                      value={scheduleTime}
                      onChange={(e) => setScheduleTime(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  )}
                </div>
                
                <button
                  onClick={handleSendNewsletter}
                  disabled={loading}
                  className="w-full px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
                >
                  {loading ? 'Sending...' : 'Send Newsletter'}
                </button>
              </>
     <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>