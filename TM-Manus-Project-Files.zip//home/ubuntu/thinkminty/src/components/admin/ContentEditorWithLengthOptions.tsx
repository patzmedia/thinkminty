'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface ContentEditorWithLengthOptionsProps {
  contentSetId?: string;
  onComplete?: () => void;
}

interface ContentSet {
  id?: string;
  title: string;
  short_form_content: string;
  long_form_content: string;
  quote_content: string;
  quote_author: string;
  is_active: boolean;
  category_id?: string;
  content_type_id?: string;
}

interface Category {
  id: string;
  name: string;
}

interface ContentType {
  id: string;
  name: string;
}

export default function ContentEditorWithLengthOptions({ 
  contentSetId, 
  onComplete 
}: ContentEditorWithLengthOptionsProps) {
  const [loading, setLoading] = useState(contentSetId ? true : false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [contentSet, setContentSet] = useState<ContentSet>({
    title: '',
    short_form_content: '',
    long_form_content: '',
    quote_content: '',
    quote_author: '',
    is_active: true
  });
  const [categories, setCategories] = useState<Category[]>([]);
  const [contentTypes, setContentTypes] = useState<ContentType[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedContentType, setSelectedContentType] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'short' | 'long'>('short');
  const [shortFormWordCount, setShortFormWordCount] = useState(0);
  const [longFormWordCount, setLongFormWordCount] = useState(0);
  const [shortFormReadTime, setShortFormReadTime] = useState(0);
  const [longFormReadTime, setLongFormReadTime] = useState(0);

  useEffect(() => {
    fetchCategories();
    fetchContentTypes();
    
    if (contentSetId) {
      fetchContentSet();
    }
  }, [contentSetId]);

  useEffect(() => {
    // Calculate word count and estimated read time for short form
    const shortWords = contentSet.short_form_content.trim().split(/\s+/).length;
    setShortFormWordCount(shortWords);
    // Average reading speed: 200-250 words per minute
    setShortFormReadTime(Math.ceil(shortWords / 225));
    
    // Calculate word count and estimated read time for long form
    const longWords = contentSet.long_form_content.trim().split(/\s+/).length;
    setLongFormWordCount(longWords);
    setLongFormReadTime(Math.ceil(longWords / 225));
  }, [contentSet.short_form_content, contentSet.long_form_content]);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('content_categories')
        .select('id, name')
        .is('parent_id', null)
        .order('name');

      if (error) throw error;
      setCategories(data || []);
    } catch (error: any) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchContentTypes = async () => {
    try {
      // Get content type tags
      const { data, error } = await supabase
        .from('tags')
        .select('id, name')
        .eq('tag_type', 'content_type')
        .order('name');

      if (error) throw error;
      setContentTypes(data || []);
    } catch (error: any) {
      console.error('Error fetching content types:', error);
    }
  };

  const fetchContentSet = async () => {
    try {
      setLoading(true);
      
      // Fetch content set
      const { data, error } = await supabase
        .from('content_sets')
        .select(`
          id,
          title,
          short_form_content,
          long_form_content,
          quote_content,
          quote_author,
          is_active,
          content_set_categories(category_id),
          content_set_tags(tag_id)
        `)
        .eq('id', contentSetId)
        .single();

      if (error) throw error;
      
      // Set content set data
      setContentSet({
        id: data.id,
        title: data.title,
        short_form_content: data.short_form_content || '',
        long_form_content: data.long_form_content || '',
        quote_content: data.quote_content || '',
        quote_author: data.quote_author || '',
        is_active: data.is_active
      });
      
      // Set category if available
      if (data.content_set_categories && data.content_set_categories.length > 0) {
        setSelectedCategory(data.content_set_categories[0].category_id);
      }
      
      // Set content type if available
      if (data.content_set_tags && data.content_set_tags.length > 0) {
        // Find content type tag
        const { data: tagData, error: tagError } = await supabase
          .from('tags')
          .select('id, tag_type')
          .in('id', data.content_set_tags.map((t: any) => t.tag_id));
        
        if (tagError) throw tagError;
        
        const contentTypeTag = tagData.find((t: any) => t.tag_type === 'content_type');
        if (contentTypeTag) {
          setSelectedContentType(contentTypeTag.id);
        }
      }
    } catch (error: any) {
      console.error('Error fetching content set:', error);
      setError('Failed to load content set. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setContentSet(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    // Validate inputs
    if (!contentSet.title.trim()) {
      setError('Please enter a title');
      return;
    }
    
    if (!contentSet.short_form_content.trim()) {
      setError('Please enter short-form content');
      return;
    }
    
    if (!selectedCategory) {
      setError('Please select a category');
      return;
    }
    
    if (!selectedContentType) {
      setError('Please select a content type');
      return;
    }
    
    setSaving(true);
    setError(null);
    setSuccess(null);
    
    try {
      let contentSetId = contentSet.id;
      
      // Insert or update content set
      if (contentSetId) {
        // Update existing content set
        const { error: updateError } = await supabase
          .from('content_sets')
          .update({
            title: contentSet.title,
            short_form_content: contentSet.short_form_content,
            long_form_content: contentSet.long_form_content || null,
            quote_content: contentSet.quote_content,
            quote_author: contentSet.quote_author,
            is_active: contentSet.is_active
          })
          .eq('id', contentSetId);
        
        if (updateError) throw updateError;
      } else {
        // Insert new content set
        const { data: insertData, error: insertError } = await supabase
          .from('content_sets')
          .insert({
            title: contentSet.title,
            short_form_content: contentSet.short_form_content,
            long_form_content: contentSet.long_form_content || null,
            quote_content: contentSet.quote_content,
            quote_author: contentSet.quote_author,
            is_active: contentSet.is_active
          })
          .select();
        
        if (insertError) throw insertError;
        contentSetId = insertData[0].id;
        
        // Set the content set ID
        setContentSet(prev => ({ ...prev, id: contentSetId }));
      }
      
      // Update category association
      if (contentSetId) {
        // First delete existing category associations
        const { error: deleteError } = await supabase
          .from('content_set_categories')
          .delete()
          .eq('content_set_id', contentSetId);
        
        if (deleteError) throw deleteError;
        
        // Insert new category association
        const { error: categoryError } = await supabase
          .from('content_set_categories')
          .insert({
            content_set_id: contentSetId,
            category_id: selectedCategory
          });
        
        if (categoryError) throw categoryError;
        
        // Update content type tag
        // First get all existing tags
        const { data: existingTags, error: tagsError } = await supabase
          .from('content_set_tags')
          .select('tag_id')
          .eq('content_set_id', contentSetId);
        
        if (tagsError) throw tagsError;
        
        // Get content type tags
        const { data: contentTypeTags, error: typeTagsError } = await supabase
          .from('tags')
          .select('id')
          .eq('tag_type', 'content_type');
        
        if (typeTagsError) throw typeTagsError;
        
        const contentTypeTagIds = contentTypeTags.map((t: any) => t.id);
        
        // Remove existing content type tags
        for (const tag of existingTags) {
          if (contentTypeTagIds.includes(tag.tag_id)) {
            const { error: deleteTagError } = await supabase
              .from('content_set_tags')
              .delete()
              .eq('content_set_id', contentSetId)
              .eq('tag_id', tag.tag_id);
            
            if (deleteTagError) throw deleteTagError;
          }
        }
        
        // Add new content type tag
        const { error: addTagError } = await supabase
          .from('content_set_tags')
          .insert({
            content_set_id: contentSetId,
            tag_id: selectedContentType
          });
        
        if (addTagError) throw addTagError;
      }
      
      setSuccess('Content set saved successfully');
      
      if (onComplete) {
        onComplete();
      }
    } catch (error: any) {
      console.error('Error saving content set:', error);
      setError(error.message || 'An error occurred while saving the content set');
    } finally {
      setSaving(false);
    }
  };

  const getReadTimeClass = (minutes: number, isShortForm: boolean) => {
    if (isShortForm) {
      // For short form, ideal is 1-2 minutes
      if (minutes <= 2) return 'text-green-600';
      if (minutes <= 3) return 'text-yellow-600';
      return 'text-red-600';
    } else {
      // For long form, ideal is 5-10 minutes
      if (minutes >= 5 && minutes <= 10) return 'text-green-600';
      if ((minutes >= 3 && minutes < 5) || (minutes > 10 && minutes <= 12)) return 'text-yellow-600';
      return 'text-red-600';
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-4 bg-gray-200 rounded w-full"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">
        {contentSet.id ? 'Edit Content Set' : 'Create New Content Set'}
      </h2>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          {success}
        </div>
      )}
      
      <div className="space-y-6">
        <div>
          <label htmlFor="title" className="block text-gray-700 mb-1">
            Title (for internal reference)
          </label>
          <input
            id="title"
            name="title"
            type="text"
            value={contentSet.title}
            onChange={handleInputChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
            required
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="category" className="block text-gray-700 mb-1">
              Category
            </label>
            <select
              id="category"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
            >
              <option value="">Select a category</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="content-type" className="block text-gray-700 mb-1">
              Content Type
            </label>
            <select
              id="content-type"
              value={selectedContentType}
              onChange={(e) => setSelectedContentType(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
            >
              <option value="">Select a content type</option>
              {contentTypes.map((type) => (
                <option key={type.id} value={type.id}>
                  {type.name}
                </option>
              ))}
            </select>
          </div>
        </div>
        
        <div>
          <div className="flex border-b border-gray-200">
            <button
              className={`py-2 px-4 font-medium ${
                activeTab === 'short'
                  ? 'text-emerald-600 border-b-2 border-emerald-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setActiveTab('short')}
            >
              Short-Form Content
            </button>
            <button
              className={`py-2 px-4 font-medium ${
                activeTab === 'long'
                  ? 'text-emerald-600 border-b-2 border-emerald-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setActiveTab('long')}
            >
              Long-Form Content
            </button>
          </div>
          
          {activeTab === 'short' ? (
            <div className="mt-4">
              <div className="flex justify-between items-center mb-1">
                <label htmlFor="short_form_content" className="block text-gray-700">
                  Short-Form Content (1-2 minute read)
                </label>
                <div className="text-sm">
                  <span className={getReadTimeClass(shortFormReadTime, true)}>
                    ~{shortFormWordCount} words / {shortFormReadTime} min read
                  </span>
                </div>
              </div>
              <div className="bg-gray-50 p-3 rounded-md mb-2 text-sm">
                <p>Guidelines for short-form content:</p>
                <ul className="list-disc pl-5 mt-1 space-y-1">
                  <li>Aim for approximately 150-250 words (1-2 minute read)</li>
                  <li>Focus on a single key message or insight</li>
                  <li>Keep paragraphs brief and focused</li>
                  <li>These are flexible guidelines, not strict requirements</li>
                </ul>
              </div>
              <textarea
                id="short_form_content"
                name="short_form_content"
                value={contentSet.short_form_content}
                onChange={handleInputChange}
                rows={6}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              ></textarea>
            </div>
          ) : (
            <div className="mt-4">
              <div className="flex justify-between items-center mb-1">
                <label htmlFor="long_form_content" className="block te<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>