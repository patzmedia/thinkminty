'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export default function ContentDeliveryTest() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [testUser, setTestUser] = useState<{id: string, email: string} | null>(null);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [categories, setCategories] = useState<{id: string, name: string}[]>([]);
  const [matchedContent, setMatchedContent] = useState<any | null>(null);
  const [deliveryHistory, setDeliveryHistory] = useState<any[]>([]);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('content_categories')
        .select('id, name')
        .is('parent_id', null)
        .order('name');

      if (error) throw error;
      setCategories(data || []);
    } catch (error: any) {
      console.error('Error fetching categories:', error);
      setError('Failed to load categories. Please try again later.');
    }
  };

  const handleCategoryToggle = (categoryId: string) => {
    setSelectedCategories(prev => {
      if (prev.includes(categoryId)) {
        return prev.filter(id => id !== categoryId);
      } else {
        return [...prev, categoryId];
      }
    });
  };

  const createTestUser = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      // Create a test user with a random email
      const testEmail = `test_user_${Date.now()}@example.com`;
      
      // In a real implementation, you would create a user in auth
      // For this test, we'll simulate with a placeholder user ID
      const testUserId = `test_${Date.now()}`;
      
      setTestUser({
        id: testUserId,
        email: testEmail
      });
      
      setSuccess(`Created test user: ${testEmail}`);
    } catch (error: any) {
      setError(error.message || 'An error occurred while creating test user');
      console.error('Test user creation error:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveUserPreferences = async () => {
    if (!testUser) {
      setError('Please create a test user first');
      return;
    }
    
    if (selectedCategories.length === 0) {
      setError('Please select at least one category');
      return;
    }
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      // In a real implementation, you would insert into user_preferences table
      // For this test, we'll simulate the preferences
      
      setSuccess(`Saved preferences for ${testUser.email}: ${selectedCategories.length} categories selected`);
      
      // After saving preferences, find matching content
      await findMatchingContent();
    } catch (error: any) {
      setError(error.message || 'An error occurred while saving preferences');
      console.error('Preference saving error:', error);
    } finally {
      setLoading(false);
    }
  };

  const findMatchingContent = async () => {
    if (!testUser) {
      setError('Please create a test user first');
      return;
    }
    
    if (selectedCategories.length === 0) {
      setError('Please select at least one category');
      return;
    }
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      // Find content sets in the selected categories
      const { data, error } = await supabase
        .from('content_sets')
        .select(`
          id,
          title,
          paragraph_content,
          quote_content,
          quote_author,
          categories:content_set_categories(
            category:category_id(
              id,
              name
            )
          )
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Filter content sets that match the selected categories
      const matchingContent = data.filter((contentSet: any) => {
        return contentSet.categories.some((cat: any) => 
          selectedCategories.includes(cat.category.id)
        );
      });
      
      if (matchingContent.length === 0) {
        setError('No matching content found for the selected categories');
        return;
      }
      
      // Select a random content set from the matching ones
      const randomIndex = Math.floor(Math.random() * matchingContent.length);
      const selectedContent = matchingContent[randomIndex];
      
      // Format the content for display
      const formattedContent = {
        id: selectedContent.id,
        title: selectedContent.title,
        paragraph_content: selectedContent.paragraph_content,
        quote_content: selectedContent.quote_content,
        quote_author: selectedContent.quote_author,
        categories: selectedContent.categories.map((cat: any) => cat.category.name)
      };
      
      setMatchedContent(formattedContent);
      setSuccess('Successfully found matching content');
    } catch (error: any) {
      setError(error.message || 'An error occurred while finding matching content');
      console.error('Content matching error:', error);
    } finally {
      setLoading(false);
    }
  };

  const recordContentDelivery = async () => {
    if (!testUser || !matchedContent) {
      setError('Please create a test user and find matching content first');
      return;
    }
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      // In a real implementation, you would insert into content_delivery_history table
      // For this test, we'll simulate the delivery
      
      const deliveryRecord = {
        id: `delivery_${Date.now()}`,
        user_id: testUser.id,
        content_set_id: matchedContent.id,
        delivered_at: new Date().toISOString(),
        content_set: matchedContent
      };
      
      setDeliveryHistory(prev => [deliveryRecord, ...prev]);
      setSuccess('Successfully recorded content delivery');
      
      // Clear the matched content to simulate sending it
      setMatchedContent(null);
    } catch (error: any) {
      setError(error.message || 'An error occurred while recording delivery');
      console.error('Delivery recording error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Content Delivery Test</h2>
      
      <p className="text-gray-600 mb-6">
        This tool allows you to test the AI matching algorithm and content delivery system.
      </p>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          {success}
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Step 1: Create Test User</h3>
            
            {testUser ? (
              <div className="bg-blue-50 p-3 rounded-md">
                <p className="text-blue-800">
                  <span className="font-medium">Test User:</span> {testUser.email}
                </p>
              </div>
            ) : (
              <button
                onClick={createTestUser}
                disabled={loading}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
              >
                {loading ? 'Creating...' : 'Create Test User'}
              </button>
            )}
          </div>
          
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Step 2: Select Content Preferences</h3>
            
            <div className="space-y-2 mb-4">
              {categories.map((category) => (
                <label key={category.id} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={selectedCategories.includes(category.id)}
                    onChange={() => handleCategoryToggle(category.id)}
                    className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300 rounded"
                  />
                  <span className="ml-2 text-gray-700">{category.name}</span>
                </label>
              ))}
            </div>
            
            <button
              onClick={saveUserPreferences}
              disabled={loading || !testUser || selectedCategories.length === 0}
              className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
            >
              {loading ? 'Saving...' : 'Save Preferences & Find Content'}
            </button>
          </div>
          
          {matchedContent && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Step 3: Review Matched Content</h3>
              
              <div className="bg-gray-50 p-4 rounded-md">
                <h4 className="font-medium mb-2">{matchedContent.title}</h4>
                
                <p className="mb-4">{matchedContent.paragraph_content}</p>
                
                <div className="border-l-4 border-emerald-200 pl-4 italic mb-4">
                  <p className="text-gray-700">{matchedContent.quote_content}</p>
                  {matchedContent.quote_author && (
                    <p className="text-gray-500 text-sm mt-1">— {matchedContent.quote_author}</p>
                  )}
                </div>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {matchedContent.categories.map((category: string, index: number) => (
                    <span 
                      key={index}
                      className="px-2 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs"
                    >
                      {category}
                    </span>
                  ))}
                </div>
                
                <button
                  onClick={recordContentDelivery}
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {loading ? 'Recording...' : 'Record Content Delivery'}
                </button>
              </div>
            </div>
          )}
        </div>
        
        <div>
          <h3 className="text-lg font-semibold mb-4">Delivery History</h3>
          
          {deliveryHistory.length === 0 ? (
            <div className="bg-gray-50 p-4 rounded-md text-center">
              <p className="text-gray-500">No content has been delivered yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {deliveryHistory.map((delivery) => (
                <div key={delivery.id} className="border border-gray-200 rounded-md p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-medium">{delivery.content_set.title}</h4>
                      <p className="text-sm text-gray-500">
                        Delivered on {new Date(delivery.delivered_at).toLocaleDateString()} at {new Date(delivery.delivered_at).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  
                  <p className="text-sm mb-2 line-clamp-2">{delivery.content_set.paragraph_content}</p>
                  
                  <div className="text-xs italic">
                    <p>"{delivery.content_set.quote_content}"</p>
                    {delivery.content_set.quote_author && <p className="text-right">— {delivery.content_set.quote_author}</p>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
