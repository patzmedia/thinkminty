'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface AIMatchingAlgorithmProps {
  userId?: string;
  onComplete?: () => void;
}

interface ContentSet {
  id: string;
  title: string;
  paragraph_content: string;
  quote_content: string;
  quote_author: string;
  tags: {
    id: string;
    name: string;
    type: string;
  }[];
}

interface UserPreference {
  tag_id: string;
  preference_type: 'prefer' | 'neutral' | 'avoid';
}

export default function AIMatchingAlgorithmEnhanced({ userId, onComplete }: AIMatchingAlgorithmProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [matchedContent, setMatchedContent] = useState<ContentSet | null>(null);
  const [userPreferences, setUserPreferences] = useState<UserPreference[]>([]);
  const [preferredTags, setPreferredTags] = useState<string[]>([]);
  const [avoidedTags, setAvoidedTags] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [categories, setCategories] = useState<{id: string, name: string}[]>([]);
  const [deliveryHistory, setDeliveryHistory] = useState<ContentSet[]>([]);
  const [testMode, setTestMode] = useState(true);
  const [testUserId, setTestUserId] = useState<string | null>(null);

  useEffect(() => {
    fetchCategories();
    
    if (userId) {
      setTestMode(false);
      fetchUserPreferences(userId);
    } else {
      setTestMode(true);
    }
  }, [userId]);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('content_categories')
        .select('id, name')
        .is('parent_id', null)
        .order('name');

      if (error) throw error;
      setCategories(data || []);
    } catch (error: any) {
      console.error('Error fetching categories:', error);
      setError('Failed to load categories. Please try again later.');
    }
  };

  const fetchUserPreferences = async (uid: string) => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('user_tag_preferences')
        .select('tag_id, preference_type')
        .eq('user_id', uid);

      if (error) throw error;
      
      setUserPreferences(data || []);
      
      // Extract preferred and avoided tags
      const preferred: string[] = [];
      const avoided: string[] = [];
      
      data.forEach((pref: UserPreference) => {
        if (pref.preference_type === 'prefer') {
          preferred.push(pref.tag_id);
        } else if (pref.preference_type === 'avoid') {
          avoided.push(pref.tag_id);
        }
      });
      
      setPreferredTags(preferred);
      setAvoidedTags(avoided);
    } catch (error: any) {
      console.error('Error fetching user preferences:', error);
      setError('Failed to load user preferences. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const createTestUser = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      // Generate a random test user ID
      const randomId = `test_${Date.now()}`;
      setTestUserId(randomId);
      setSuccess(`Created test user ID: ${randomId}`);
    } catch (error: any) {
      setError(error.message || 'An error occurred while creating test user');
      console.error('Test user creation error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCategoryToggle = (categoryId: string) => {
    setSelectedCategories(prev => {
      if (prev.includes(categoryId)) {
        return prev.filter(id => id !== categoryId);
      } else {
        return [...prev, categoryId];
      }
    });
  };

  const handleTagPreferenceChange = (tagId: string, preferenceType: 'prefer' | 'neutral' | 'avoid') => {
    setUserPreferences(prev => {
      // Remove existing preference if any
      const filtered = prev.filter(p => p.tag_id !== tagId);
      
      // If setting to neutral, just remove the preference
      if (preferenceType === 'neutral') {
        return filtered;
      }
      
      // Otherwise add the new preference
      return [...filtered, { tag_id: tagId, preference_type: preferenceType }];
    });
    
    // Update preferred and avoided tag lists
    if (preferenceType === 'prefer') {
      setPreferredTags(prev => [...prev.filter(id => id !== tagId), tagId]);
      setAvoidedTags(prev => prev.filter(id => id !== tagId));
    } else if (preferenceType === 'avoid') {
      setAvoidedTags(prev => [...prev.filter(id => id !== tagId), tagId]);
      setPreferredTags(prev => prev.filter(id => id !== tagId));
    } else {
      // Neutral
      setPreferredTags(prev => prev.filter(id => id !== tagId));
      setAvoidedTags(prev => prev.filter(id => id !== tagId));
    }
  };

  const findMatchingContent = async () => {
    if (testMode && !testUserId) {
      setError('Please create a test user first');
      return;
    }
    
    if (selectedCategories.length === 0) {
      setError('Please select at least one category');
      return;
    }
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      // In a real implementation, you would use the database function:
      // SELECT * FROM get_content_by_tags(user_id, preferred_tags, avoided_tags)
      
      // For this demo, we'll implement the matching logic in JavaScript
      
      // 1. Get content sets in the selected categories
      const { data: categoryContentSets, error: categoryError } = await supabase
        .from('content_set_categories')
        .select(`
          content_set_id,
          content_set:content_set_id(
            id,
            title,
            paragraph_content,
            quote_content,
            quote_author,
            tags:content_set_tags(
              tag:tag_id(
                id,
                name,
                tag_type
              )
            )
          )
        `)
        .in('category_id', selectedCategories);
      
      if (categoryError) throw categoryError;
      
      // 2. Transform data and filter out content already delivered
      const deliveredIds = deliveryHistory.map(item => item.id);
      
      const availableContentSets = categoryContentSets
        .filter(item => !deliveredIds.includes(item.content_set.id))
        .map(item => {
          const contentSet = item.content_set;
          return {
            id: contentSet.id,
            title: contentSet.title,
            paragraph_content: contentSet.paragraph_content,
            quote_content: contentSet.quote_content,
            quote_author: contentSet.quote_author,
            tags: contentSet.tags.map((t: any) => ({
              id: t.tag.id,
              name: t.tag.name,
              type: t.tag.tag_type
            }))
          };
        });
      
      if (availableContentSets.length === 0) {
        setError('No matching content found for the selected categories');
        return;
      }
      
      // 3. Score content sets based on tag preferences
      const scoredContentSets = availableContentSets.map(contentSet => {
        const tagIds = contentSet.tags.map(tag => tag.id);
        
        // Calculate preference score
        let score = 0;
        
        // Boost score for preferred tags
        preferredTags.forEach(tagId => {
          if (tagIds.includes(tagId)) {
            score += 10;
          }
        });
        
        // Penalize score for avoided tags
        avoidedTags.forEach(tagId => {
          if (tagIds.includes(tagId)) {
            score -= 20; // Higher penalty to ensure avoided tags are really avoided
          }
        });
        
        return {
          contentSet,
          score
        };
      });
      
      // 4. Sort by score (highest first) and add some randomness for variety
      scoredContentSets.sort((a, b) => {
        // If scores differ significantly, sort by score
        if (Math.abs(a.score - b.score) > 5) {
          return b.score - a.score;
        }
        
        // Otherwise, add some randomness
        return Math.random() - 0.5;
      });
      
      // 5. Select the top content set
      const selectedContent = scoredContentSets[0]?.contentSet;
      
      if (!selectedContent) {
        setError('No suitable content found based on your preferences');
        return;
      }
      
      setMatchedContent(selectedContent);
      setSuccess('Successfully found matching content');
    } catch (error: any) {
      setError(error.message || 'An error occurred while finding matching content');
      console.error('Content matching error:', error);
    } finally {
      setLoading(false);
    }
  };

  const recordContentDelivery = async () => {
    if (!matchedContent) {
      setError('Please find matching content first');
      return;
    }
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      // In a real implementation, you would insert into content_delivery_history table
      // For this demo, we'll just add to the local state
      
      setDeliveryHistory(prev => [matchedContent, ...prev]);
      setSuccess('Successfully recorded content delivery');
      
      // Clear the matched content to simulate sending it
      setMatchedContent(null);
    } catch (error: any) {
      setError(error.message || 'An error occurred while recording delivery');
      console.error('Delivery recording error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Enhanced AI Matching Algorithm</h2>
      
      <p className="text-gray-600 mb-6">
        This tool demonstrates the enhanced AI matching algorithm that uses tag preferences to personalize content delivery.
      </p>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          {success}
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          {testMode && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Step 1: Create Test User</h3>
              
              {testUserId ? (
                <div className="bg-blue-50 p-3 rounded-md">
                  <p className="text-blue-800">
                    <span className="font-medium">Test User ID:</span> {testUserId}
                  </p>
                </div>
              ) : (
                <button
                  onClick={createTestUser}
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {loading ? 'Creating...' : 'Create Test User'}
                </button>
              )}
            </div>
          )}
          
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Step {testMode ? '2' : '1'}: Select Content Categories</h3>
            
            <div className="space-y-2 mb-4">
              {categories.map((category) => (
                <label key={category.id} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={selectedCategories.includes(category.id)}
                    onChange={() => handleCategoryToggle(category.id)}
                    className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300 rounded"
                  />
                  <span className="ml-2 text-gray-700">{category.name}</span>
                </label>
              ))}
            </div>
          </div>
          
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Step {testMode ? '3' : '2'}: Set Tag Preferences</h3>
            
            <div className="bg-gray-50 p-4 rounded-md mb-4">
              <p className="text-sm text-gray-700 mb-2">
                Select your content preferences by marking tags as preferred or avoided:
              </p>
              
              <div className="flex space-x-4 text-sm">
                <div className="flex items-center">
                  <span className="inline-block w-3 h-3 bg-emerald-500 rounded-full mr-1"></span>
                  <span>Prefer</span>
                </div>
                <div className="flex items-center">
                  <span className="inline-block w-3 h-3 bg-gray-300 rounded-full mr-1"></span>
                  <span>Neutral</span>
                </div>
                <div className="flex items-center">
                  <span className="inline-block w-3 h-3 bg-red-500 rounded-full mr-1"></span>
                  <span>Avoid</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-4 max-h-[300px] overflow-y-auto">
              {['emotional', 'theme', 'action'].map(tagType => (
                <div key={tagType} className="border border-gray-200 rounded-md p-3">
                  <h4 className="font-medium mb-2 capitalize">
                    {tagType === 'emotional' ? 'Emotions' : 
                     tagType === 'action' ? 'Actions' : 
                     'Themes'}
                  </h4>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {/* In a real implementation, these would be fetched from the database */}
                    {[
                      { id: `${tagType}_1`, name: `${tagType === 'emotional' ? 'Peace' : tagType === 'action' ? 'Meditation' : 'Overcoming Challenges'}` },
                      { id: `${tagType}_2`, name: `${tagType === 'emotional' ? 'Joy' : tagType === 'action' ? 'Journaling' : 'Finding Purpose'}` },
                      { id: `${tagType}_3`, name: `${tagType === 'emotional' ? 'Hope' : tagType === 'action' ? 'Exercise' : 'Self-Care'}` },
                      { id: `${tagType}_4`, name: `${tagType === 'emotional' ? 'Gratitude' : tagType === 'action' ? 'Kindness' : 'Community'}` }
                    ].map(tag => {
                      const isPreferred = preferredTags.includes(tag.id);
                      const isAvoided = avoidedTags.includes(tag.id);
                      
                      return (
                        <div key={tag.id} className="flex items-center justify-between">
                          <span className="text-sm">{tag.name}</span>
                          
                          <div className="flex space-x-1">
                            <button
                              onClick={() => handleTagPreferenceChange(tag.id, 'prefer')}
                              className={`w-6 h-6 rounded-full ${isPreferred ? 'bg-emerald-500' : 'bg-gray-200'}`}
                              title="Prefer"
                            ></button>
                            
                            <button
                              onClick={() => handleTagPreferenceChange(tag.id, 'neutral')}
                              className={`w-6 h-6 rounded-full ${!isPreferred && !isAvoided ? 'bg-gray-400' : 'bg-gray-200'}`}
                              title="Neutral"
                            ></button>
                            
                            <button
                              onClick={() => handleTagPreferenceChange(tag.id, 'avoid')}
                              className={`w-6 h-6 rounded-full ${isAvoided ? 'bg-red-500' : 'bg-gray-200'}`}
                              title="Avoid"
                            ></button>
                          </div>
                        </div>
                      );
          <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>