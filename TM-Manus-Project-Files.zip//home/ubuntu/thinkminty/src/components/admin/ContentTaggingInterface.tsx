'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface ContentTaggingInterfaceProps {
  onComplete?: () => void;
}

interface ContentSet {
  id: string;
  title: string;
  paragraph_content: string;
  quote_content: string;
  quote_author: string;
  tags: {
    id: string;
    name: string;
    type: string;
  }[];
}

interface Tag {
  id: string;
  name: string;
  slug: string;
  tag_type: string;
  description: string;
}

export default function ContentTaggingInterface({ onComplete }: ContentTaggingInterfaceProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [contentSets, setContentSets] = useState<ContentSet[]>([]);
  const [selectedContentSet, setSelectedContentSet] = useState<ContentSet | null>(null);
  const [availableTags, setAvailableTags] = useState<Tag[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterContentType, setFilterContentType] = useState<string>('all');
  const [filterTagType, setFilterTagType] = useState<string>('all');
  const [submitting, setSubmitting] = useState(false);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const pageSize = 10;

  useEffect(() => {
    fetchContentSets();
    fetchAvailableTags();
  }, [page, searchTerm, filterContentType]);

  const fetchContentSets = async () => {
    try {
      setLoading(true);
      
      // Calculate pagination
      const from = (page - 1) * pageSize;
      const to = from + pageSize - 1;
      
      // Build query
      let query = supabase
        .from('content_sets')
        .select(`
          id,
          title,
          paragraph_content,
          quote_content,
          quote_author,
          tags:content_set_tags(
            tag:tag_id(
              id,
              name,
              tag_type
            )
          )
        `, { count: 'exact' })
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .range(from, to);
      
      // Apply search filter if provided
      if (searchTerm) {
        query = query.or(`title.ilike.%${searchTerm}%,paragraph_content.ilike.%${searchTerm}%,quote_content.ilike.%${searchTerm}%`);
      }
      
      // Apply content type filter if selected
      if (filterContentType !== 'all') {
        // This is a simplification - in a real implementation, you would need to filter by tag relationship
        // For this demo, we'll assume the filtering happens client-side
      }
      
      const { data, error, count } = await query;
      
      if (error) throw error;
      
      // Transform data
      const transformedData = data.map((item: any) => ({
        id: item.id,
        title: item.title,
        paragraph_content: item.paragraph_content,
        quote_content: item.quote_content,
        quote_author: item.quote_author,
        tags: item.tags.map((t: any) => ({
          id: t.tag.id,
          name: t.tag.name,
          type: t.tag.tag_type
        }))
      }));
      
      // Filter by content type if needed (client-side)
      const filteredData = filterContentType !== 'all'
        ? transformedData.filter(cs => 
            cs.tags.some(tag => 
              tag.type === 'content_type' && 
              tag.name.toLowerCase() === filterContentType.toLowerCase()
            )
          )
        : transformedData;
      
      setContentSets(filteredData);
      
      // Calculate total pages
      if (count) {
        setTotalPages(Math.ceil(count / pageSize));
      }
    } catch (error: any) {
      console.error('Error fetching content sets:', error);
      setError('Failed to load content sets. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const fetchAvailableTags = async () => {
    try {
      const { data, error } = await supabase
        .from('tags')
        .select('*')
        .order('name');

      if (error) throw error;
      setAvailableTags(data || []);
    } catch (error: any) {
      console.error('Error fetching tags:', error);
      setError('Failed to load tags. Please try again later.');
    }
  };

  const handleContentSetSelect = (contentSet: ContentSet) => {
    setSelectedContentSet(contentSet);
    setSelectedTags(contentSet.tags.map(tag => tag.id));
  };

  const handleTagToggle = (tagId: string) => {
    setSelectedTags(prev => {
      if (prev.includes(tagId)) {
        return prev.filter(id => id !== tagId);
      } else {
        return [...prev, tagId];
      }
    });
  };

  const handleSaveTags = async () => {
    if (!selectedContentSet) {
      setError('Please select a content set first');
      return;
    }
    
    setSubmitting(true);
    setError(null);
    setSuccess(null);
    
    try {
      // Get current tags for the content set
      const { data: currentTags, error: fetchError } = await supabase
        .from('content_set_tags')
        .select('tag_id')
        .eq('content_set_id', selectedContentSet.id);
      
      if (fetchError) throw fetchError;
      
      const currentTagIds = currentTags.map(t => t.tag_id);
      
      // Tags to add (in selected but not in current)
      const tagsToAdd = selectedTags.filter(tagId => !currentTagIds.includes(tagId));
      
      // Tags to remove (in current but not in selected)
      const tagsToRemove = currentTagIds.filter(tagId => !selectedTags.includes(tagId));
      
      // Add new tags
      if (tagsToAdd.length > 0) {
        const tagsToInsert = tagsToAdd.map(tagId => ({
          content_set_id: selectedContentSet.id,
          tag_id: tagId
        }));
        
        const { error: insertError } = await supabase
          .from('content_set_tags')
          .insert(tagsToInsert);
        
        if (insertError) throw insertError;
      }
      
      // Remove tags
      if (tagsToRemove.length > 0) {
        const { error: deleteError } = await supabase
          .from('content_set_tags')
          .delete()
          .eq('content_set_id', selectedContentSet.id)
          .in('tag_id', tagsToRemove);
        
        if (deleteError) throw deleteError;
      }
      
      // Update local state
      setContentSets(prev => 
        prev.map(cs => {
          if (cs.id === selectedContentSet.id) {
            const updatedTags = availableTags
              .filter(tag => selectedTags.includes(tag.id))
              .map(tag => ({
                id: tag.id,
                name: tag.name,
                type: tag.tag_type
              }));
            
            return {
              ...cs,
              tags: updatedTags
            };
          }
          return cs;
        })
      );
      
      setSuccess('Tags updated successfully');
      
      if (onComplete) {
        onComplete();
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred while saving tags');
      console.error('Tag saving error:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const getContentTypeLabel = (contentSet: ContentSet) => {
    const contentTypeTag = contentSet.tags.find(tag => tag.type === 'content_type');
    return contentTypeTag ? contentTypeTag.name : 'Unspecified';
  };

  const getContentTypeColor = (contentType: string) => {
    switch (contentType.toLowerCase()) {
      case 'story':
        return 'bg-blue-100 text-blue-800';
      case 'practical tip':
        return 'bg-green-100 text-green-800';
      case 'reflection':
        return 'bg-purple-100 text-purple-800';
      case 'affirmation':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredAvailableTags = availableTags.filter(tag => 
    filterTagType === 'all' || tag.tag_type === filterTagType
  );

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Content Tagging Interface</h2>
      
      <p className="text-gray-600 mb-6">
        Use this interface to manage tags for your content sets. Select a content set from the list, then add or remove tags as needed.
      </p>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          {success}
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-semibold mb-4">Content Sets</h3>
          
          <div className="mb-4 flex flex-col sm:flex-row gap-2">
            <div className="flex-grow">
              <input
                type="text"
                placeholder="Search content sets..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            
            <div>
              <select
                value={filterContentType}
                onChange={(e) => setFilterContentType(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="all">All Content Types</option>
                <option value="story">Stories</option>
                <option value="practical tip">Practical Tips</option>
                <option value="reflection">Reflections</option>
                <option value="affirmation">Affirmations</option>
              </select>
            </div>
          </div>
          
          {loading ? (
            <div className="animate-pulse space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-20 bg-gray-200 rounded"></div>
              ))}
            </div>
          ) : contentSets.length === 0 ? (
            <div className="bg-gray-50 p-4 rounded-md text-center">
              <p className="text-gray-500">No content sets found</p>
            </div>
          ) : (
            <div className="space-y-4 max-h-[600px] overflow-y-auto">
              {contentSets.map((contentSet) => (
                <div 
                  key={contentSet.id} 
                  className={`border rounded-md p-4 cursor-pointer transition-colors ${
                    selectedContentSet?.id === contentSet.id
                      ? 'border-emerald-500 bg-emerald-50'
                      : 'border-gray-200 hover:bg-gray-50'
                  }`}
                  onClick={() => handleContentSetSelect(contentSet)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">{contentSet.title}</h4>
                      <p className="text-sm text-gray-500 line-clamp-2 mt-1">
                        {contentSet.paragraph_content}
                      </p>
                    </div>
                    
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        getContentTypeColor(getContentTypeLabel(contentSet))
                      }`}
                    >
                      {getContentTypeLabel(contentSet)}
                    </span>
                  </div>
                  
                  {contentSet.tags.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {contentSet.tags
                        .filter(tag => tag.type !== 'content_type' && tag.type !== 'category')
                        .slice(0, 5)
                        .map((tag) => (
                          <span 
                            key={tag.id}
                            className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full text-xs"
                          >
                            {tag.name}
                          </span>
                        ))}
                      {contentSet.tags.length > 6 && (
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full text-xs">
                          +{contentSet.tags.length - 6} more
                        </span>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
          
          {totalPages > 1 && (
            <div className="flex justify-center mt-4">
              <nav className="flex items-center space-x-2">
                <button
                  onClick={() => setPage(p => Math.max(p - 1, 1))}
                  disabled={page === 1}
                  className="px-3 py-1 rounded-md border border-gray-300 disabled:opacity-50"
                >
                  Previous
                </button>
                
                <span className="text-sm text-gray-700">
                  Page {page} of {totalPages}
                </span>
                
                <button
                  onClick={() => setPage(p => Math.min(p + 1, totalPages))}
                  disabled={page === totalPages}
                  className="px-3 py-1 rounded-md border border-gray-300 disabled:opacity-50"
                >
                  Next
                </button>
              </nav>
            </div>
          )}
        </div>
        
        <div>
          <h3 className="text-lg font-semibold mb-4">Tag Management</h3>
          
          {selectedContentSet ? (
            <>
              <div className="bg-gray-50 p-4 rounded-md mb-4">
                <h4 className="font-medium">{selectedContentSet.title}</h4>
                <p className="text-sm text-gray-700 mt-2 mb-2">
                  {selectedContentSet.paragraph_content.substring(0, 150)}
                  {selectedContentSet.paragraph_content.length > 150 ? '...' : ''}
                </p>
                <div className="text-sm italic text-gray-600">
                  "{selectedContentSet.quote_content}"
                  {selectedContentSet.quote_author && (
                    <span> — {selectedContentSet.quote_author}</span>
                  )}
                </div>
              </div>
              
              <div className="mb-4">
                <label className="block text-gray-700 mb-2">Filter Tags</label>
                <select
                  value={filterTagType}
                  onChange={(e) => setFilterTagType(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">All Tag Types</option>
                  <option value="category">Categories</option>
                  <option value="content_type">Content Types</option>
                  <option value="emotional">Emotional Tags</option>
                  <option value="action">Action Tags</option>
                  <option value="theme">Theme Tags</option>
                  <option value="source">Source Tags</option>
                </select>
              </div>
              
              <div className="mb-6">
                <label className="block text-gray-700 mb-2">Available Tags</label>
                <div className="max-h-[300px] overflow-y-auto border border-gray-200 rounded-md p-3">
                  <div className="space-y-2">
                    {filteredAvailableTags.map((tag) => (
                      <label key={tag.id} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={selectedTa<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>