'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface ContentCalendarProps {
  onComplete?: () => void;
}

interface CategoryProgress {
  id: string;
  name: string;
  count: number;
  goal: number;
  percentage: number;
}

interface ScheduledContent {
  id: string;
  title: string;
  scheduled_date: string;
  category_name: string;
  status: 'draft' | 'ready' | 'sent';
}

export default function ContentCalendar({ onComplete }: ContentCalendarProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [categoryProgress, setCategoryProgress] = useState<CategoryProgress[]>([]);
  const [scheduledContent, setScheduledContent] = useState<ScheduledContent[]>([]);
  const [totalProgress, setTotalProgress] = useState({ count: 0, goal: 180, percentage: 0 });
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedContentSet, setSelectedContentSet] = useState<string>('');
  const [contentSets, setContentSets] = useState<{id: string, title: string}[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [scheduleStatus, setScheduleStatus] = useState<'draft' | 'ready'>('ready');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    fetchCategoryProgress();
    fetchScheduledContent();
    fetchAvailableContentSets();
  }, []);

  const fetchCategoryProgress = async () => {
    try {
      setLoading(true);
      
      // Get all categories
      const { data: categories, error: categoriesError } = await supabase
        .from('content_categories')
        .select('id, name, slug')
        .is('parent_id', null)
        .order('display_order', { ascending: true });

      if (categoriesError) throw categoriesError;
      
      // For each category, count the content sets
      const progressData: CategoryProgress[] = [];
      let totalCount = 0;
      
      for (const category of categories) {
        const { count, error: countError } = await supabase
          .from('content_set_categories')
          .select('*', { count: 'exact', head: true })
          .eq('category_id', category.id);
          
        if (countError) throw countError;
        
        const categoryCount = count || 0;
        totalCount += categoryCount;
        
        progressData.push({
          id: category.id,
          name: category.name,
          count: categoryCount,
          goal: 30,
          percentage: Math.round((categoryCount / 30) * 100)
        });
      }
      
      setCategoryProgress(progressData);
      setTotalProgress({
        count: totalCount,
        goal: 180,
        percentage: Math.round((totalCount / 180) * 100)
      });
    } catch (error: any) {
      console.error('Error fetching category progress:', error);
      setError('Failed to load content progress. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const fetchScheduledContent = async () => {
    try {
      // This would typically fetch from a content_schedule table
      // For this demo, we'll simulate with a placeholder
      // In a real implementation, you would create this table in your database
      
      // Placeholder data
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const nextWeek = new Date(today);
      nextWeek.setDate(nextWeek.getDate() + 7);
      
      const scheduledItems: ScheduledContent[] = [
        {
          id: '1',
          title: 'Present Moment Breathing',
          scheduled_date: today.toISOString().split('T')[0],
          category_name: 'Mindful Moments',
          status: 'ready'
        },
        {
          id: '2',
          title: 'Obstacles as Stepping Stones',
          scheduled_date: tomorrow.toISOString().split('T')[0],
          category_name: 'Resilience Recharge',
          status: 'draft'
        },
        {
          id: '3',
          title: 'Simple Pleasures',
          scheduled_date: nextWeek.toISOString().split('T')[0],
          category_name: 'Joyful Living',
          status: 'draft'
        }
      ];
      
      setScheduledContent(scheduledItems);
    } catch (error: any) {
      console.error('Error fetching scheduled content:', error);
    }
  };

  const fetchAvailableContentSets = async () => {
    try {
      const { data, error } = await supabase
        .from('content_sets')
        .select(`
          id,
          title,
          categories:content_set_categories(
            category:category_id(
              id,
              name
            )
          )
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setContentSets(data.map((item: any) => ({
        id: item.id,
        title: item.title
      })));
    } catch (error: any) {
      console.error('Error fetching content sets:', error);
    }
  };

  const handleScheduleContent = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedContentSet || !selectedDate) {
      setError('Please select a content set and date');
      return;
    }
    
    setSubmitting(true);
    setError(null);
    setSuccess(null);
    
    try {
      // In a real implementation, you would insert into a content_schedule table
      // For this demo, we'll simulate success
      
      // Find the content set title
      const contentSet = contentSets.find(cs => cs.id === selectedContentSet);
      
      // Add to the scheduled content list
      setScheduledContent(prev => [
        ...prev,
        {
          id: Date.now().toString(), // Generate a temporary ID
          title: contentSet?.title || 'Unknown Content',
          scheduled_date: selectedDate,
          category_name: selectedCategory || 'Uncategorized',
          status: scheduleStatus
        }
      ]);
      
      setSuccess('Content scheduled successfully');
      
      // Reset form
      setSelectedContentSet('');
      setSelectedCategory('');
      
      if (onComplete) {
        onComplete();
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred while scheduling content');
      console.error('Content scheduling error:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteScheduledItem = (id: string) => {
    // In a real implementation, you would delete from the database
    // For this demo, we'll just remove from the state
    setScheduledContent(prev => prev.filter(item => item.id !== id));
  };

  if (loading && categoryProgress.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-4 bg-gray-200 rounded w-full"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Content Calendar</h2>
      
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Content Development Progress</h3>
        
        <div className="mb-6">
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium">Overall Progress: {totalProgress.count}/{totalProgress.goal} content sets</span>
            <span className="text-sm font-medium">{totalProgress.percentage}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-emerald-600 h-2.5 rounded-full" 
              style={{ width: `${totalProgress.percentage}%` }}
            ></div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {categoryProgress.map((category) => (
            <div key={category.id} className="border border-gray-200 rounded-md p-4">
              <h4 className="font-medium mb-2">{category.name}</h4>
              <div className="flex justify-between mb-1">
                <span className="text-sm text-gray-500">{category.count}/{category.goal} content sets</span>
                <span className="text-sm text-gray-500">{category.percentage}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className={`h-2.5 rounded-full ${
                    category.percentage >= 100 
                      ? 'bg-green-600' 
                      : category.percentage >= 50 
                        ? 'bg-emerald-600' 
                        : 'bg-yellow-500'
                  }`}
                  style={{ width: `${category.percentage}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-semibold mb-4">Schedule Content</h3>
          
          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
              {error}
            </div>
          )}
          
          {success && (
            <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
              {success}
            </div>
          )}
          
          <form onSubmit={handleScheduleContent} className="space-y-4">
            <div>
              <label htmlFor="content-set" className="block text-gray-700 mb-1">
                Content Set
              </label>
              <select
                id="content-set"
                value={selectedContentSet}
                onChange={(e) => setSelectedContentSet(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              >
                <option value="">Select a content set</option>
                {contentSets.map((cs) => (
                  <option key={cs.id} value={cs.id}>
                    {cs.title}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="category" className="block text-gray-700 mb-1">
                Category
              </label>
              <select
                id="category"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="">Select a category</option>
                {categoryProgress.map((cat) => (
                  <option key={cat.id} value={cat.name}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="schedule-date" className="block text-gray-700 mb-1">
                Schedule Date
              </label>
              <input
                id="schedule-date"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>
            
            <div>
              <label className="block text-gray-700 mb-1">Status</label>
              <div className="flex space-x-4">
                <label className="flex items-center">
                  <input
                    type="radio"
                    value="draft"
                    checked={scheduleStatus === 'draft'}
                    onChange={() => setScheduleStatus('draft')}
                    className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300"
                  />
                  <span className="ml-2 text-gray-700">Draft</span>
                </label>
                
                <label className="flex items-center">
                  <input
                    type="radio"
                    value="ready"
                    checked={scheduleStatus === 'ready'}
                    onChange={() => setScheduleStatus('ready')}
                    className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300"
                  />
                  <span className="ml-2 text-gray-700">Ready to Send</span>
                </label>
              </div>
            </div>
            
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
            >
              {submitting ? 'Scheduling...' : 'Schedule Content'}
            </button>
          </form>
        </div>
        
        <div>
          <h3 className="text-lg font-semibold mb-4">Scheduled Content</h3>
          
          {scheduledContent.length === 0 ? (
            <div className="bg-gray-50 p-4 rounded-md text-center">
              <p className="text-gray-500">No content scheduled yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {scheduledContent.map((item) => (
                <div key={item.id} className="border border-gray-200 rounded-md p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">{item.title}</h4>
                      <p className="text-sm text-gray-500">
                        {new Date(item.scheduled_date).toLocaleDateString()} • {item.category_name}
                      </p>
                      <span
                        className={`mt-2 inline-block px-2 py-1 text-xs rounded-full ${
                          item.status === 'sent'
                            ? 'bg-gray-100 text-gray-800'
                            : item.status === 'ready'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {item.status === 'sent' ? 'Sent' : item.status === 'ready' ? 'Ready' : 'Draft'}
                      </span>
                    </div>
                    
                    <button
                      onClick={() => handleDeleteScheduledItem(item.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
