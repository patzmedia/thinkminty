'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface ContentSet {
  id: string;
  title: string;
  paragraph_content: string;
  quote_content: string;
  quote_author: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  categories: {
    id: string;
    name: string;
  }[];
}

interface Category {
  id: string;
  name: string;
  parent_id: string | null;
  parent_name?: string;
}

export default function ContentSetManager() {
  const [contentSets, setContentSets] = useState<ContentSet[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  
  const [newContentSet, setNewContentSet] = useState({
    title: '',
    paragraph_content: '',
    quote_content: '',
    quote_author: '',
    is_active: true,
    selectedCategories: [] as string[]
  });
  
  const [editingContentSet, setEditingContentSet] = useState({
    title: '',
    paragraph_content: '',
    quote_content: '',
    quote_author: '',
    is_active: true,
    selectedCategories: [] as string[]
  });

  useEffect(() => {
    fetchCategories();
    fetchContentSets();
  }, []);

  const fetchCategories = async () => {
    try {
      // Get all categories
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('content_categories')
        .select('id, name, parent_id')
        .order('display_order', { ascending: true });

      if (categoriesError) {
        throw categoriesError;
      }

      // Add parent name to subcategories
      const categoriesWithParentNames = categoriesData.map(category => {
        if (category.parent_id) {
          const parentCategory = categoriesData.find(c => c.id === category.parent_id);
          return {
            ...category,
            parent_name: parentCategory ? parentCategory.name : undefined
          };
        }
        return category;
      });

      setCategories(categoriesWithParentNames);
    } catch (error: any) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchContentSets = async () => {
    try {
      setLoading(true);
      
      // Get content sets with their categories
      const { data, error } = await supabase
        .from('content_sets')
        .select(`
          *,
          categories:content_set_categories(
            category:category_id(
              id,
              name
            )
          )
        `)
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      // Transform data to flatten the categories
      const transformedData = data.map((item: any) => ({
        ...item,
        categories: item.categories.map((cat: any) => cat.category)
      }));

      setContentSets(transformedData);
    } catch (error: any) {
      setError(error.message || 'An error occurred while fetching content sets');
      console.error('Error fetching content sets:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddContentSet = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    
    try {
      // Insert new content set
      const { data, error } = await supabase
        .from('content_sets')
        .insert({
          title: newContentSet.title,
          paragraph_content: newContentSet.paragraph_content,
          quote_content: newContentSet.quote_content,
          quote_author: newContentSet.quote_author,
          is_active: newContentSet.is_active
        })
        .select();

      if (error) {
        throw error;
      }

      // Add category associations
      if (newContentSet.selectedCategories.length > 0 && data && data[0]) {
        const contentSetId = data[0].id;
        const categoryAssociations = newContentSet.selectedCategories.map(categoryId => ({
          content_set_id: contentSetId,
          category_id: categoryId
        }));

        const { error: associationError } = await supabase
          .from('content_set_categories')
          .insert(categoryAssociations);

        if (associationError) {
          throw associationError;
        }
      }

      // Reset form and refresh content sets
      setNewContentSet({
        title: '',
        paragraph_content: '',
        quote_content: '',
        quote_author: '',
        is_active: true,
        selectedCategories: []
      });
      setIsAdding(false);
      fetchContentSets();
    } catch (error: any) {
      setError(error.message || 'An error occurred while adding the content set');
      console.error('Error adding content set:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleEditContentSet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isEditing) return;
    
    setSubmitting(true);
    
    try {
      // Update content set
      const { error } = await supabase
        .from('content_sets')
        .update({
          title: editingContentSet.title,
          paragraph_content: editingContentSet.paragraph_content,
          quote_content: editingContentSet.quote_content,
          quote_author: editingContentSet.quote_author,
          is_active: editingContentSet.is_active,
          updated_at: new Date().toISOString()
        })
        .eq('id', isEditing);

      if (error) {
        throw error;
      }

      // Delete existing category associations
      const { error: deleteError } = await supabase
        .from('content_set_categories')
        .delete()
        .eq('content_set_id', isEditing);

      if (deleteError) {
        throw deleteError;
      }

      // Add new category associations
      if (editingContentSet.selectedCategories.length > 0) {
        const categoryAssociations = editingContentSet.selectedCategories.map(categoryId => ({
          content_set_id: isEditing,
          category_id: categoryId
        }));

        const { error: associationError } = await supabase
          .from('content_set_categories')
          .insert(categoryAssociations);

        if (associationError) {
          throw associationError;
        }
      }

      // Reset form and refresh content sets
      setIsEditing(null);
      fetchContentSets();
    } catch (error: any) {
      setError(error.message || 'An error occurred while updating the content set');
      console.error('Error updating content set:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteContentSet = async (id: string) => {
    if (!confirm('Are you sure you want to delete this content set?')) {
      return;
    }

    try {
      // Delete content set (category associations will be deleted via cascade)
      const { error } = await supabase
        .from('content_sets')
        .delete()
        .eq('id', id);

      if (error) {
        throw error;
      }

      // Refresh content sets
      fetchContentSets();
    } catch (error: any) {
      setError(error.message || 'An error occurred while deleting the content set');
      console.error('Error deleting content set:', error);
    }
  };

  const startEditing = (contentSet: ContentSet) => {
    setIsEditing(contentSet.id);
    setEditingContentSet({
      title: contentSet.title,
      paragraph_content: contentSet.paragraph_content,
      quote_content: contentSet.quote_content,
      quote_author: contentSet.quote_author || '',
      is_active: contentSet.is_active,
      selectedCategories: contentSet.categories.map(cat => cat.id)
    });
  };

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>, isForNewContentSet: boolean) => {
    const selectedOptions = Array.from(e.target.selectedOptions).map(option => option.value);
    
    if (isForNewContentSet) {
      setNewContentSet({
        ...newContentSet,
        selectedCategories: selectedOptions
      });
    } else {
      setEditingContentSet({
        ...editingContentSet,
        selectedCategories: selectedOptions
      });
    }
  };

  if (loading && contentSets.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Content Set Management</h2>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
        >
          {isAdding ? 'Cancel' : 'Add Content Set'}
        </button>
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}

      {isAdding && (
        <div className="mb-8 p-4 border border-gray-200 rounded-md">
          <h3 className="text-lg font-semibold mb-4">Add New Content Set</h3>
          <form onSubmit={handleAddContentSet}>
            <div className="mb-4">
              <label htmlFor="title" className="block text-gray-700 mb-1">
                Title (Internal Reference)
              </label>
              <input
                id="title"
                type="text"
                value={newContentSet.title}
                onChange={(e) => setNewContentSet({ ...newContentSet, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="paragraph" className="block text-gray-700 mb-1">
                Paragraph Content
              </label>
              <textarea
                id="paragraph"
                value={newContentSet.paragraph_content}
                onChange={(e) => setNewContentSet({ ...newContentSet, paragraph_content: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                rows={5}
                required
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="quote" className="block text-gray-700 mb-1">
                Quote Content
              </label>
              <textarea
                id="quote"
                value={newContentSet.quote_content}
                onChange={(e) => setNewContentSet({ ...newContentSet, quote_content: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                rows={2}
                required
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="author" className="block text-gray-700 mb-1">
                Quote Author
              </label>
              <input
                id="author"
                type="text"
                value={newContentSet.quote_author}
                onChange={(e) => setNewContentSet({ ...newContentSet, quote_author: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="categories" className="block text-gray-700 mb-1">
                Categories (Select Multiple)
              </label>
              <select
                id="categories"
                multiple
                value={newContentSet.selectedCategories}
                onChange={(e) => handleCategoryChange(e, true)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                size={5}
                required
              >
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.parent_name ? `${category.parent_name} > ${category.name}` : category.name}
                  </option>
                ))}
              </select>
              <p className="text-xs text-gray-500 mt-1">
                Hold Ctrl (or Cmd on Mac) to select multiple categories
              </p>
            </div>
            
            <div className="mb-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={newContentSet.is_active}
                  onChange={(e) => setNewContentSet({ ...newContentSet, is_active: e.target.checked })}
                  className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-gray-700">Active</span>
              </label>
            </div>
            
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={submitting}
                className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
              >
                {submitting ? 'Adding...' : 'Add Content Set'}
              </button>
            </div>
          </form>
        </div>
      )}

      {isEditing && (
        <div className="mb-8 p-4 border border-gray-200 rounded-md">
          <h3 className="text-lg font-semibold mb-4">Edit Content Set</h3>
          <form onSubmit={handleEditContentSet}>
            <div className="mb-4">
              <label htmlFor="edit-title" className="block text-gray-700 mb-1">
                Title (Internal Reference)
              </label>
              <input
                id="edit-title"
                type="text"
                value={editingContentSet.title}
                onChange={(e) => setEditingContentSet({ ...editingContentSet, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="edit-paragraph" className="block text-gray-700 mb-1">
                Paragraph Content
              </label>
              <textarea
                id="edit-paragraph"
                value={editingContentSet.paragraph_content}
                onChange={(e) => setEditingContentSet({ ...editingContentSet, paragraph_content: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                rows={5}
                required
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="edit-quote" className="block text-gray-700 mb-1">
                Quote Content
              </label>
              <textarea
                id="edit-quote"
                value={editingContentSet.quote_content}
                onChange={(e) => setEditingContentSet({ ...editingContentSet, quote_content:<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>