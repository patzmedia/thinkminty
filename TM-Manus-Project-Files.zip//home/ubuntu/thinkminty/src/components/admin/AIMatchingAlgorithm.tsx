'use client';

import { useState } from 'react';
import { supabase } from '@/lib/supabase';

interface AIMatchingAlgorithmProps {
  onComplete?: () => void;
}

export default function AIMatchingAlgorithm({ onComplete }: AIMatchingAlgorithmProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [results, setResults] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState('');
  const [users, setUsers] = useState<{id: string, email: string}[]>([]);
  const [matchingMode, setMatchingMode] = useState<'single' | 'all'>('single');

  useState(() => {
    fetchUsers();
  });

  const fetchUsers = async () => {
    try {
      // Get users with preferences
      const { data, error } = await supabase
        .from('user_preferences')
        .select(`
          user_id,
          user:user_id(email)
        `)
        .order('user_id');

      if (error) throw error;
      
      // Remove duplicates (users with multiple preferences)
      const uniqueUsers = Array.from(
        new Map(data.map(item => [item.user_id, { id: item.user_id, email: item.user.email }]))
        .values()
      );
      
      setUsers(uniqueUsers);
    } catch (error: any) {
      console.error('Error fetching users:', error);
      setError('Failed to load users. Please try again later.');
    }
  };

  const handleFindMatch = async () => {
    if (matchingMode === 'single' && !selectedUser) {
      setError('Please select a user');
      return;
    }
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    setResults([]);
    
    try {
      if (matchingMode === 'single') {
        // Find match for single user
        const { data, error } = await supabase.rpc('get_user_preferred_content', {
          user_id: selectedUser
        });
        
        if (error) throw error;
        
        if (!data || data.length === 0) {
          setSuccess('No matching content found for this user. They may have already seen all available content in their preferred categories.');
        } else {
          setResults([{
            user_id: selectedUser,
            user_email: users.find(u => u.id === selectedUser)?.email || 'Unknown',
            content: data
          }]);
          setSuccess('Successfully found matching content for the selected user.');
        }
      } else {
        // Find matches for all users with preferences
        const allResults = [];
        
        for (const user of users) {
          const { data, error } = await supabase.rpc('get_user_preferred_content', {
            user_id: user.id
          });
          
          if (error) throw error;
          
          if (data && data.length > 0) {
            allResults.push({
              user_id: user.id,
              user_email: user.email,
              content: data
            });
          }
        }
        
        if (allResults.length === 0) {
          setSuccess('No matching content found for any users. They may have already seen all available content in their preferred categories.');
        } else {
          setResults(allResults);
          setSuccess(`Successfully found matching content for ${allResults.length} users.`);
        }
      }
      
      if (onComplete) {
        onComplete();
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred while finding matching content');
      console.error('Matching error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRecordDelivery = async (userId: string, contentSetId: string) => {
    try {
      setLoading(true);
      
      // Record content delivery
      const { error } = await supabase.rpc('record_content_delivery', {
        user_id: userId,
        content_set_id: contentSetId
      });
      
      if (error) throw error;
      
      // Remove the delivered content from results
      setResults(prevResults => 
        prevResults.map(result => {
          if (result.user_id === userId) {
            return {
              ...result,
              content: result.content.filter((c: any) => c.content_set_id !== contentSetId)
            };
          }
          return result;
        })
      );
      
      setSuccess('Content delivery recorded successfully.');
    } catch (error: any) {
      setError(error.message || 'An error occurred while recording content delivery');
      console.error('Delivery recording error:', error);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">AI Content Matching Algorithm</h2>
      
      <p className="text-gray-600 mb-6">
        This tool finds personalized content for users based on their preferences. You can test the algorithm for a single user or run it for all users.
      </p>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          {success}
        </div>
      )}
      
      <div className="mb-6">
        <div className="flex space-x-4 mb-4">
          <label className="flex items-center">
            <input
              type="radio"
              value="single"
              checked={matchingMode === 'single'}
              onChange={() => setMatchingMode('single')}
              className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300"
            />
            <span className="ml-2 text-gray-700">Single User</span>
          </label>
          
          <label className="flex items-center">
            <input
              type="radio"
              value="all"
              checked={matchingMode === 'all'}
              onChange={() => setMatchingMode('all')}
              className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300"
            />
            <span className="ml-2 text-gray-700">All Users</span>
          </label>
        </div>
        
        {matchingMode === 'single' && (
          <div className="mb-4">
            <label htmlFor="user" className="block text-gray-700 mb-2">
              Select User
            </label>
            <select
              id="user"
              value={selectedUser}
              onChange={(e) => setSelectedUser(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
            >
              <option value="">Select a user</option>
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.email}
                </option>
              ))}
            </select>
          </div>
        )}
        
        <button
          onClick={handleFindMatch}
          disabled={loading}
          className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
        >
          {loading ? 'Processing...' : matchingMode === 'single' ? 'Find Match for User' : 'Find Matches for All Users'}
        </button>
      </div>
      
      {results.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold mb-4">Matching Results</h3>
          
          <div className="space-y-8">
            {results.map((result) => (
              <div key={result.user_id} className="border border-gray-200 rounded-lg p-4">
                <h4 className="text-lg font-medium mb-2">
                  User: {result.user_email}
                </h4>
                
                {result.content.length === 0 ? (
                  <p className="text-gray-500 italic">No matching content available</p>
                ) : (
                  <div className="space-y-4">
                    {result.content.map((content: any) => (
                      <div key={content.content_set_id} className="bg-gray-50 p-4 rounded-md">
                        <div className="flex justify-between items-start mb-2">
                          <h5 className="font-medium">{content.title}</h5>
                          <button
                            onClick={() => handleRecordDelivery(result.user_id, content.content_set_id)}
                            className="text-sm px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
                          >
                            Record Delivery
                          </button>
                        </div>
                        
                        <p className="text-sm mb-2">{content.paragraph_content.substring(0, 150)}...</p>
                        
                        <div className="text-xs italic">
                          <p>"{content.quote_content}"</p>
                          {content.quote_author && <p className="text-right">— {content.quote_author}</p>}
                        </div>
                        
                        <div className="mt-2 text-xs text-gray-500">
                          Categories: {content.category_names.join(', ')}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
