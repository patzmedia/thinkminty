'use client';

import { useState } from 'react';
import { supabase } from '@/lib/supabase';

interface ContentSetBulkUploadProps {
  onComplete?: () => void;
}

export default function ContentSetBulkUpload({ onComplete }: ContentSetBulkUploadProps) {
  const [bulkContent, setBulkContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [categories, setCategories] = useState<{id: string, name: string}[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('');

  useState(() => {
    fetchCategories();
  });

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('content_categories')
        .select('id, name')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setCategories(data || []);
    } catch (error: any) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!bulkContent.trim()) {
      setError('Please enter content to upload');
      return;
    }

    if (!selectedCategory) {
      setError('Please select a category for the content sets');
      return;
    }
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      // Parse the bulk content
      // Format expected: 
      // Title: [title]
      // Paragraph: [paragraph content]
      // Quote: [quote content]
      // Author: [quote author]
      // ---
      
      const contentSets = [];
      const contentBlocks = bulkContent.split('---').filter(block => block.trim());
      
      for (const block of contentBlocks) {
        const lines = block.trim().split('\n');
        const contentSet: any = {};
        
        for (const line of lines) {
          if (line.startsWith('Title:')) {
            contentSet.title = line.replace('Title:', '').trim();
          } else if (line.startsWith('Paragraph:')) {
            contentSet.paragraph_content = line.replace('Paragraph:', '').trim();
          } else if (line.startsWith('Quote:')) {
            contentSet.quote_content = line.replace('Quote:', '').trim();
          } else if (line.startsWith('Author:')) {
            contentSet.quote_author = line.replace('Author:', '').trim();
          }
        }
        
        // Validate required fields
        if (!contentSet.title || !contentSet.paragraph_content || !contentSet.quote_content) {
          throw new Error('Each content set must have a title, paragraph, and quote');
        }
        
        contentSet.is_active = true;
        contentSets.push(contentSet);
      }
      
      if (contentSets.length === 0) {
        throw new Error('No valid content sets found in the input');
      }
      
      // Insert content sets
      for (const contentSet of contentSets) {
        // Insert content set
        const { data, error } = await supabase
          .from('content_sets')
          .insert(contentSet)
          .select();
        
        if (error) throw error;
        
        if (data && data[0]) {
          // Associate with selected category
          const { error: categoryError } = await supabase
            .from('content_set_categories')
            .insert({
              content_set_id: data[0].id,
              category_id: selectedCategory
            });
          
          if (categoryError) throw categoryError;
        }
      }
      
      setSuccess(`Successfully uploaded ${contentSets.length} content sets`);
      setBulkContent('');
      
      if (onComplete) {
        onComplete();
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred during bulk upload');
      console.error('Bulk upload error:', error);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Bulk Upload Content Sets</h2>
      
      <p className="text-gray-600 mb-4">
        Upload multiple content sets at once using the format below. Separate each content set with three dashes (---).
      </p>
      
      <div className="bg-gray-50 p-3 rounded-md mb-6 text-sm">
        <pre className="whitespace-pre-wrap">
          Title: [title]
          Paragraph: [paragraph content]
          Quote: [quote content]
          Author: [quote author]
          ---
          Title: [next title]
          ...
        </pre>
      </div>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          {success}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="category" className="block text-gray-700 mb-2">
            Category for All Content Sets
          </label>
          <select
            id="category"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
            required
          >
            <option value="">Select a category</option>
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
          <p className="text-xs text-gray-500 mt-1">
            All uploaded content sets will be associated with this category. You can edit individual associations later.
          </p>
        </div>
        
        <div className="mb-4">
          <label htmlFor="bulkContent" className="block text-gray-700 mb-2">
            Content Sets
          </label>
          <textarea
            id="bulkContent"
            value={bulkContent}
            onChange={(e) => setBulkContent(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
            rows={15}
            placeholder="Title: Embracing Gratitude
Paragraph: Gratitude is a powerful practice that can transform your perspective on life. Taking a few moments each day to reflect on what you're thankful for can shift your focus from what's lacking to the abundance that surrounds you. This simple habit has been shown to improve mental health, enhance relationships, and even boost physical wellbeing.
Quote: Gratitude turns what we have into enough.
Author: Anonymous
---
Title: Finding Joy in Small Moments
..."
            required
          />
        </div>
        
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
          >
            {loading ? 'Uploading...' : 'Upload Content Sets'}
          </button>
        </div>
      </form>
    </div>
  );
}
