'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface ContentCalendarExpandedProps {
  onComplete?: () => void;
}

interface CategoryProgress {
  id: string;
  name: string;
  count: number;
  goal: number;
  percentage: number;
  contentTypeCounts: {
    story: number;
    practicalTip: number;
    reflection: number;
    affirmation: number;
  };
  contentTypeGoals: {
    story: number;
    practicalTip: number;
    reflection: number;
    affirmation: number;
  };
}

interface ScheduledContent {
  id: string;
  title: string;
  scheduled_date: string;
  category_name: string;
  content_type: string;
  tags: string[];
  status: 'draft' | 'ready' | 'sent';
}

export default function ContentCalendarExpanded({ onComplete }: ContentCalendarExpandedProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [categoryProgress, setCategoryProgress] = useState<CategoryProgress[]>([]);
  const [scheduledContent, setScheduledContent] = useState<ScheduledContent[]>([]);
  const [totalProgress, setTotalProgress] = useState({ 
    count: 0, 
    goal: 540, 
    percentage: 0,
    contentTypeCounts: {
      story: 0,
      practicalTip: 0,
      reflection: 0,
      affirmation: 0
    },
    contentTypeGoals: {
      story: 270, // 50% of 540
      practicalTip: 135, // 25% of 540
      reflection: 81, // 15% of 540
      affirmation: 54 // 10% of 540
    }
  });
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedContentSet, setSelectedContentSet] = useState<string>('');
  const [contentSets, setContentSets] = useState<{id: string, title: string, content_type: string, tags: string[]}[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [scheduleStatus, setScheduleStatus] = useState<'draft' | 'ready'>('ready');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'calendar' | 'progress'>('progress');
  const [filterContentType, setFilterContentType] = useState<string>('all');
  const [filterTags, setFilterTags] = useState<string[]>([]);
  const [availableTags, setAvailableTags] = useState<{id: string, name: string, type: string}[]>([]);

  useEffect(() => {
    fetchCategoryProgress();
    fetchScheduledContent();
    fetchAvailableContentSets();
    fetchAvailableTags();
  }, []);

  const fetchAvailableTags = async () => {
    try {
      const { data, error } = await supabase
        .from('tags')
        .select('id, name, tag_type')
        .order('name');

      if (error) throw error;
      setAvailableTags(data.map(tag => ({
        id: tag.id,
        name: tag.name,
        type: tag.tag_type
      })));
    } catch (error: any) {
      console.error('Error fetching tags:', error);
    }
  };

  const fetchCategoryProgress = async () => {
    try {
      setLoading(true);
      
      // Get all categories
      const { data: categories, error: categoriesError } = await supabase
        .from('content_categories')
        .select('id, name, slug')
        .is('parent_id', null)
        .order('display_order', { ascending: true });

      if (categoriesError) throw categoriesError;
      
      // For each category, count the content sets and their types
      const progressData: CategoryProgress[] = [];
      let totalCount = 0;
      let totalStoryCount = 0;
      let totalPracticalTipCount = 0;
      let totalReflectionCount = 0;
      let totalAffirmationCount = 0;
      
      for (const category of categories) {
        // Get content sets for this category
        const { data: contentSets, error: contentError } = await supabase
          .from('content_set_categories')
          .select(`
            content_set_id,
            content_set:content_set_id(
              id,
              tags:content_set_tags(
                tag:tag_id(
                  id,
                  name,
                  tag_type
                )
              )
            )
          `)
          .eq('category_id', category.id);
          
        if (contentError) throw contentError;
        
        // Count by content type
        let storyCount = 0;
        let practicalTipCount = 0;
        let reflectionCount = 0;
        let affirmationCount = 0;
        
        contentSets.forEach((cs: any) => {
          const contentTypeTags = cs.content_set.tags.filter((t: any) => 
            t.tag.tag_type === 'content_type'
          );
          
          if (contentTypeTags.length > 0) {
            const contentType = contentTypeTags[0].tag.name;
            if (contentType === 'Story') storyCount++;
            else if (contentType === 'Practical Tip') practicalTipCount++;
            else if (contentType === 'Reflection') reflectionCount++;
            else if (contentType === 'Affirmation') affirmationCount++;
          }
        });
        
        const categoryCount = contentSets.length;
        totalCount += categoryCount;
        totalStoryCount += storyCount;
        totalPracticalTipCount += practicalTipCount;
        totalReflectionCount += reflectionCount;
        totalAffirmationCount += affirmationCount;
        
        progressData.push({
          id: category.id,
          name: category.name,
          count: categoryCount,
          goal: 90,
          percentage: Math.round((categoryCount / 90) * 100),
          contentTypeCounts: {
            story: storyCount,
            practicalTip: practicalTipCount,
            reflection: reflectionCount,
            affirmation: affirmationCount
          },
          contentTypeGoals: {
            story: 45, // 50% of 90
            practicalTip: 23, // 25% of 90
            reflection: 14, // 15% of 90
            affirmation: 9 // 10% of 90
          }
        });
      }
      
      setCategoryProgress(progressData);
      setTotalProgress({
        count: totalCount,
        goal: 540,
        percentage: Math.round((totalCount / 540) * 100),
        contentTypeCounts: {
          story: totalStoryCount,
          practicalTip: totalPracticalTipCount,
          reflection: totalReflectionCount,
          affirmation: totalAffirmationCount
        },
        contentTypeGoals: {
          story: 270, // 50% of 540
          practicalTip: 135, // 25% of 540
          reflection: 81, // 15% of 540
          affirmation: 54 // 10% of 540
        }
      });
    } catch (error: any) {
      console.error('Error fetching category progress:', error);
      setError('Failed to load content progress. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const fetchScheduledContent = async () => {
    try {
      // This would typically fetch from a content_schedule table
      // For this demo, we'll simulate with a placeholder
      // In a real implementation, you would create this table in your database
      
      // Placeholder data
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const nextWeek = new Date(today);
      nextWeek.setDate(nextWeek.getDate() + 7);
      
      const scheduledItems: ScheduledContent[] = [
        {
          id: '1',
          title: 'Present Moment Breathing',
          scheduled_date: today.toISOString().split('T')[0],
          category_name: 'Mindful Moments',
          content_type: 'Practical Tip',
          tags: ['Peace', 'Breathing', 'Mindfulness'],
          status: 'ready'
        },
        {
          id: '2',
          title: 'Obstacles as Stepping Stones',
          scheduled_date: tomorrow.toISOString().split('T')[0],
          category_name: 'Resilience Recharge',
          content_type: 'Story',
          tags: ['Resilience', 'Overcoming Challenges', 'Hope'],
          status: 'draft'
        },
        {
          id: '3',
          title: 'Simple Pleasures',
          scheduled_date: nextWeek.toISOString().split('T')[0],
          category_name: 'Joyful Living',
          content_type: 'Reflection',
          tags: ['Joy', 'Gratitude', 'Mindfulness'],
          status: 'draft'
        }
      ];
      
      setScheduledContent(scheduledItems);
    } catch (error: any) {
      console.error('Error fetching scheduled content:', error);
    }
  };

  const fetchAvailableContentSets = async () => {
    try {
      const { data, error } = await supabase
        .from('content_sets')
        .select(`
          id,
          title,
          tags:content_set_tags(
            tag:tag_id(
              id,
              name,
              tag_type
            )
          )
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setContentSets(data.map((item: any) => {
        const contentTypeTag = item.tags.find((t: any) => t.tag.tag_type === 'content_type');
        const allTags = item.tags.map((t: any) => t.tag.name);
        
        return {
          id: item.id,
          title: item.title,
          content_type: contentTypeTag ? contentTypeTag.tag.name : 'Unknown',
          tags: allTags
        };
      }));
    } catch (error: any) {
      console.error('Error fetching content sets:', error);
    }
  };

  const handleScheduleContent = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedContentSet || !selectedDate) {
      setError('Please select a content set and date');
      return;
    }
    
    setSubmitting(true);
    setError(null);
    setSuccess(null);
    
    try {
      // In a real implementation, you would insert into a content_schedule table
      // For this demo, we'll simulate success
      
      // Find the content set
      const contentSet = contentSets.find(cs => cs.id === selectedContentSet);
      
      if (!contentSet) {
        throw new Error('Content set not found');
      }
      
      // Add to the scheduled content list
      setScheduledContent(prev => [
        ...prev,
        {
          id: Date.now().toString(), // Generate a temporary ID
          title: contentSet.title,
          scheduled_date: selectedDate,
          category_name: selectedCategory || 'Uncategorized',
          content_type: contentSet.content_type,
          tags: contentSet.tags,
          status: scheduleStatus
        }
      ]);
      
      setSuccess('Content scheduled successfully');
      
      // Reset form
      setSelectedContentSet('');
      setSelectedCategory('');
      
      if (onComplete) {
        onComplete();
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred while scheduling content');
      console.error('Content scheduling error:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteScheduledItem = (id: string) => {
    // In a real implementation, you would delete from the database
    // For this demo, we'll just remove from the state
    setScheduledContent(prev => prev.filter(item => item.id !== id));
  };

  const handleTagFilterToggle = (tagName: string) => {
    setFilterTags(prev => {
      if (prev.includes(tagName)) {
        return prev.filter(tag => tag !== tagName);
      } else {
        return [...prev, tagName];
      }
    });
  };

  const getContentTypeProgressBar = (current: number, goal: number, type: string) => {
    const percentage = Math.round((current / goal) * 100);
    let color;
    
    switch (type) {
      case 'story':
        color = 'bg-blue-600';
        break;
      case 'practicalTip':
        color = 'bg-green-600';
        break;
      case 'reflection':
        color = 'bg-purple-600';
        break;
      case 'affirmation':
        color = 'bg-yellow-600';
        break;
      default:
        color = 'bg-gray-600';
    }
    
    return (
      <div className="mb-2">
        <div className="flex justify-between mb-1">
          <span className="text-xs font-medium">
            {type === 'story' ? 'Stories' : 
             type === 'practicalTip' ? 'Practical Tips' : 
             type === 'reflection' ? 'Reflections' : 
             'Affirmations'}: {current}/{goal}
          </span>
          <span className="text-xs font-medium">{percentage}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-1.5">
          <div 
            className={`h-1.5 rounded-full ${color}`} 
            style={{ width: `${percentage}%` }}
          ></div>
        </div>
      </div>
    );
  };

  if (loading && categoryProgress.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-4 bg-gray-200 rounded w-full"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Content Calendar</h2>
      
      <div className="mb-6">
        <div className="flex space-x-4">
          <button
            onClick={() => setViewMode('progress')}
            className={`px-4 py-2 rounded-md ${
              viewMode === 'progress' 
                ? 'bg-emerald-600 text-white' 
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Progress Tracking
          </button>
          <button
            onClick={() => setViewMode('calendar')}
            className={`px-4 py-2 rounded-md ${
              viewMode === 'calendar' 
                ? 'bg-emerald-600 text-white' 
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Content Calendar
          </button>
        </div>
      </div>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          {success}
        </div>
      )}
      
      {viewMode === 'progress' ? (
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Content Development Progress</h3>
          
          <div className="mb-6">
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium">Overall Progress: {totalProgress.count}/{totalProgress.goal} content sets</span>
              <span className="text-sm font-medium">{totalProgress.percentage}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
              <div 
                className="bg-emerald-600 h-2.5 rounded-full" 
                style={{ width: `${totalProgress.percentage}%` }}
              ></div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-md mb-4">
              <h4 className="font-medium mb-2">Content Type Distribution</h4>
              {getContentTypeProgressBar(
                totalProgress.contentTypeCounts.story,
                totalProgress.contentTypeGoals.story,
                'story'
              )}
              {getContentTypeProgressBar(
                totalProgress.contentTypeCounts.practicalTip,
                totalProgress.contentTypeGoals.practicalTip,
                'practicalTip'
              )}
              {getContentTypeProgressBar(
                totalProgress.contentTypeCounts.reflection,
                totalProgress.contentTypeGoals.reflection,
                'reflection'
              )}
              {getContentTypeProgressBar(
                totalProgress.contentTypeCounts.affirmation,
                totalProgress.contentTypeGoals.affirmatio<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>