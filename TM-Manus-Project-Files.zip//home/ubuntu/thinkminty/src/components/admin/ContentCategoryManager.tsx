'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import Link from 'next/link';

interface ContentCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  parent_id: string | null;
  image_url: string | null;
  is_active: boolean;
  display_order: number;
  subcategories?: ContentCategory[];
}

export default function ContentCategoryManager() {
  const [categories, setCategories] = useState<ContentCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [newCategory, setNewCategory] = useState({
    name: '',
    description: '',
    parent_id: '',
    image_url: '',
    is_active: true,
    display_order: 0
  });
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [editingCategory, setEditingCategory] = useState({
    name: '',
    description: '',
    parent_id: '',
    image_url: '',
    is_active: true,
    display_order: 0
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      
      // Get all categories
      const { data, error } = await supabase
        .from('content_categories')
        .select('*')
        .order('display_order', { ascending: true });

      if (error) {
        throw error;
      }

      // Organize into hierarchy (parent categories with subcategories)
      const parentCategories = data.filter(cat => cat.parent_id === null);
      const childCategories = data.filter(cat => cat.parent_id !== null);
      
      const categoriesWithChildren = parentCategories.map(parent => ({
        ...parent,
        subcategories: childCategories.filter(child => child.parent_id === parent.id)
      }));

      setCategories(categoriesWithChildren);
    } catch (error: any) {
      setError(error.message || 'An error occurred while fetching categories');
      console.error('Error fetching categories:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    
    try {
      // Generate slug from name
      const slug = newCategory.name
        .toLowerCase()
        .replace(/[^\w\s]/gi, '')
        .replace(/\s+/g, '-');
      
      // Insert new category
      const { data, error } = await supabase
        .from('content_categories')
        .insert({
          name: newCategory.name,
          slug,
          description: newCategory.description,
          parent_id: newCategory.parent_id || null,
          image_url: newCategory.image_url || null,
          is_active: newCategory.is_active,
          display_order: newCategory.display_order
        })
        .select();

      if (error) {
        throw error;
      }

      // Reset form and refresh categories
      setNewCategory({
        name: '',
        description: '',
        parent_id: '',
        image_url: '',
        is_active: true,
        display_order: 0
      });
      setIsAdding(false);
      fetchCategories();
    } catch (error: any) {
      setError(error.message || 'An error occurred while adding the category');
      console.error('Error adding category:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleEditCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isEditing) return;
    
    setSubmitting(true);
    
    try {
      // Update category
      const { error } = await supabase
        .from('content_categories')
        .update({
          name: editingCategory.name,
          description: editingCategory.description,
          parent_id: editingCategory.parent_id || null,
          image_url: editingCategory.image_url || null,
          is_active: editingCategory.is_active,
          display_order: editingCategory.display_order
        })
        .eq('id', isEditing);

      if (error) {
        throw error;
      }

      // Reset form and refresh categories
      setIsEditing(null);
      fetchCategories();
    } catch (error: any) {
      setError(error.message || 'An error occurred while updating the category');
      console.error('Error updating category:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteCategory = async (id: string) => {
    if (!confirm('Are you sure you want to delete this category? This will also delete all subcategories.')) {
      return;
    }

    try {
      // Delete category
      const { error } = await supabase
        .from('content_categories')
        .delete()
        .eq('id', id);

      if (error) {
        throw error;
      }

      // Refresh categories
      fetchCategories();
    } catch (error: any) {
      setError(error.message || 'An error occurred while deleting the category');
      console.error('Error deleting category:', error);
    }
  };

  const startEditing = (category: ContentCategory) => {
    setIsEditing(category.id);
    setEditingCategory({
      name: category.name,
      description: category.description || '',
      parent_id: category.parent_id || '',
      image_url: category.image_url || '',
      is_active: category.is_active,
      display_order: category.display_order
    });
  };

  if (loading && categories.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Content Category Management</h2>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
        >
          {isAdding ? 'Cancel' : 'Add Category'}
        </button>
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}

      {isAdding && (
        <div className="mb-8 p-4 border border-gray-200 rounded-md">
          <h3 className="text-lg font-semibold mb-4">Add New Category</h3>
          <form onSubmit={handleAddCategory}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="name" className="block text-gray-700 mb-1">
                  Name
                </label>
                <input
                  id="name"
                  type="text"
                  value={newCategory.name}
                  onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="parent" className="block text-gray-700 mb-1">
                  Parent Category (Optional)
                </label>
                <select
                  id="parent"
                  value={newCategory.parent_id}
                  onChange={(e) => setNewCategory({ ...newCategory, parent_id: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">None (Top Level)</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="mb-4">
              <label htmlFor="description" className="block text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="description"
                value={newCategory.description}
                onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                rows={3}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="imageUrl" className="block text-gray-700 mb-1">
                  Image URL (Optional)
                </label>
                <input
                  id="imageUrl"
                  type="text"
                  value={newCategory.image_url}
                  onChange={(e) => setNewCategory({ ...newCategory, image_url: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              
              <div>
                <label htmlFor="displayOrder" className="block text-gray-700 mb-1">
                  Display Order
                </label>
                <input
                  id="displayOrder"
                  type="number"
                  value={newCategory.display_order}
                  onChange={(e) => setNewCategory({ ...newCategory, display_order: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  min="0"
                />
              </div>
            </div>
            
            <div className="mb-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={newCategory.is_active}
                  onChange={(e) => setNewCategory({ ...newCategory, is_active: e.target.checked })}
                  className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-gray-700">Active</span>
              </label>
            </div>
            
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={submitting}
                className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
              >
                {submitting ? 'Adding...' : 'Add Category'}
              </button>
            </div>
          </form>
        </div>
      )}

      {isEditing && (
        <div className="mb-8 p-4 border border-gray-200 rounded-md">
          <h3 className="text-lg font-semibold mb-4">Edit Category</h3>
          <form onSubmit={handleEditCategory}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="edit-name" className="block text-gray-700 mb-1">
                  Name
                </label>
                <input
                  id="edit-name"
                  type="text"
                  value={editingCategory.name}
                  onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="edit-parent" className="block text-gray-700 mb-1">
                  Parent Category (Optional)
                </label>
                <select
                  id="edit-parent"
                  value={editingCategory.parent_id}
                  onChange={(e) => setEditingCategory({ ...editingCategory, parent_id: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">None (Top Level)</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="mb-4">
              <label htmlFor="edit-description" className="block text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="edit-description"
                value={editingCategory.description}
                onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                rows={3}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="edit-imageUrl" className="block text-gray-700 mb-1">
                  Image URL (Optional)
                </label>
                <input
                  id="edit-imageUrl"
                  type="text"
                  value={editingCategory.image_url}
                  onChange={(e) => setEditingCategory({ ...editingCategory, image_url: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              
              <div>
                <label htmlFor="edit-displayOrder" className="block text-gray-700 mb-1">
                  Display Order
                </label>
                <input
                  id="edit-displayOrder"
                  type="number"
                  value={editingCategory.display_order}
                  onChange={(e) => setEditingCategory({ ...editingCategory, display_order: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  min="0"
                />
              </div>
            </div>
            
            <div className="mb-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={editingCategory.is_active}
                  onChange={(e) => setEditingCategory({ ...editingCategory, is_active: e.target.checked })}
                  className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-gray-700">Active</span>
              </label>
            </div>
            
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setIsEditing(null)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-4 py-2 bg-emerald-600 text-white rounded-m<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>