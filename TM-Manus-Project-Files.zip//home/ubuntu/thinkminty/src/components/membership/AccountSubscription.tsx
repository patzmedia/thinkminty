'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

interface SubscriptionData {
  id: string;
  tier_id: string;
  status: string;
  current_period_end: string;
  cancel_at_period_end: boolean;
  tier: {
    name: string;
    price_monthly: number;
    price_yearly: number;
  };
}

export default function AccountSubscription() {
  const [subscription, setSubscription] = useState<SubscriptionData | null>(null);
  const [loading, setLoading] = useState(true);
  const [cancelLoading, setCancelLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const fetchSubscription = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session) {
          router.push('/auth/signin');
          return;
        }

        const { data, error } = await supabase
          .from('subscriptions')
          .select(`
            id,
            tier_id,
            status,
            current_period_end,
            cancel_at_period_end,
            tier:tier_id (
              name,
              price_monthly,
              price_yearly
            )
          `)
          .eq('user_id', session.user.id)
          .eq('status', 'active')
          .single();

        if (error) {
          console.error('Error fetching subscription:', error);
        } else {
          setSubscription(data);
        }
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSubscription();
  }, [router]);

  const handleCancelSubscription = async () => {
    if (!subscription) return;
    
    setCancelLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/cancel-subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          subscriptionId: subscription.id,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to cancel subscription');
      }

      // Update subscription data
      setSubscription({
        ...subscription,
        cancel_at_period_end: true,
      });
      
    } catch (error: any) {
      setError(error.message || 'An error occurred while canceling your subscription');
    } finally {
      setCancelLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-6 bg-white rounded-lg shadow-md">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-2/3 mb-6"></div>
          <div className="h-10 bg-gray-200 rounded w-1/3"></div>
        </div>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className="p-6 bg-white rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">No Active Subscription</h2>
        <p className="text-gray-600 mb-6">
          You don't have an active subscription. Upgrade to access premium content and features.
        </p>
        <Link
          href="/membership"
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-md font-medium transition-colors"
        >
          View Membership Options
        </Link>
      </div>
    );
  }

  const formattedEndDate = new Date(subscription.current_period_end).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Your Subscription</h2>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-gray-600">Plan:</span>
          <span className="font-medium">{subscription.tier.name}</span>
        </div>
        <div className="flex justify-between items-center mb-2">
          <span className="text-gray-600">Status:</span>
          <span className="font-medium">
            {subscription.cancel_at_period_end ? 'Canceling' : 'Active'}
          </span>
        </div>
        <div className="flex justify-between items-center mb-2">
          <span className="text-gray-600">
            {subscription.cancel_at_period_end ? 'Access until:' : 'Renews on:'}
          </span>
          <span className="font-medium">{formattedEndDate}</span>
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-3">
        <Link
          href="/membership"
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-md font-medium transition-colors text-center"
        >
          Change Plan
        </Link>
        
        {!subscription.cancel_at_period_end && (
          <button
            onClick={handleCancelSubscription}
            disabled={cancelLoading}
            className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-md font-medium transition-colors"
          >
            {cancelLoading ? 'Processing...' : 'Cancel Subscription'}
          </button>
        )}
      </div>
      
      {subscription.cancel_at_period_end && (
        <p className="mt-4 text-sm text-gray-500">
          Your subscription will be canceled at the end of the current billing period. You'll continue to have access until {formattedEndDate}.
        </p>
      )}
    </div>
  );
}
