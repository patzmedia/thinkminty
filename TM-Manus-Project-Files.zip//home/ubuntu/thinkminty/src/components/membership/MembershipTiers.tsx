'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { getStripe } from '@/lib/stripe';
import { supabase } from '@/lib/supabase';

interface MembershipTier {
  id: string;
  name: string;
  description: string;
  price_monthly: number;
  price_yearly: number;
  features: string[];
  stripe_price_id_monthly: string;
  stripe_price_id_yearly: string;
}

export default function MembershipTiers({ 
  tiers, 
  currentTierId 
}: { 
  tiers: MembershipTier[]; 
  currentTierId?: string;
}) {
  const [billingInterval, setBillingInterval] = useState<'monthly' | 'yearly'>('monthly');
  const [loading, setLoading] = useState<string | null>(null);
  const router = useRouter();

  const handleSubscription = async (tier: MembershipTier) => {
    setLoading(tier.id);

    try {
      // Check if user is authenticated
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        // Redirect to sign in if not authenticated
        router.push('/auth/signin?redirect=/membership');
        return;
      }

      // Create checkout session
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          priceId: billingInterval === 'monthly' 
            ? tier.stripe_price_id_monthly 
            : tier.stripe_price_id_yearly,
          tierId: tier.id,
          userId: session.user.id,
          interval: billingInterval,
        }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const { sessionId } = await response.json();
      
      // Redirect to Stripe checkout
      const stripe = await getStripe();
      const { error } = await stripe!.redirectToCheckout({ sessionId });
      
      if (error) {
        throw error;
      }
    } catch (error) {
      console.error('Error creating checkout session:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="sm:flex sm:flex-col sm:align-center">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-center">
            Membership Plans
          </h1>
          <p className="mt-5 text-xl text-gray-500 sm:text-center">
            Choose the plan that's right for your financial journey
          </p>
          
          {/* Billing interval toggle */}
          <div className="relative self-center mt-6 bg-gray-100 rounded-lg p-0.5 flex sm:mt-8">
            <button
              type="button"
              className={`${
                billingInterval === 'monthly'
                  ? 'bg-white border-gray-200 shadow-sm text-gray-900'
                  : 'border border-transparent text-gray-500'
              } relative w-1/2 rounded-md py-2 text-sm font-medium whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:z-10 sm:w-auto sm:px-8`}
              onClick={() => setBillingInterval('monthly')}
            >
              Monthly
            </button>
            <button
              type="button"
              className={`${
                billingInterval === 'yearly'
                  ? 'bg-white border-gray-200 shadow-sm text-gray-900'
                  : 'border border-transparent text-gray-500'
              } ml-0.5 relative w-1/2 rounded-md py-2 text-sm font-medium whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:z-10 sm:w-auto sm:px-8`}
              onClick={() => setBillingInterval('yearly')}
            >
              Yearly
              <span className="absolute -top-2 -right-12 bg-emerald-500 text-white text-xs px-2 py-0.5 rounded-full">
                Save 20%
              </span>
            </button>
          </div>
        </div>

        <div className="mt-12 space-y-4 sm:mt-16 sm:space-y-0 sm:grid sm:grid-cols-3 sm:gap-6 lg:max-w-4xl lg:mx-auto xl:max-w-none xl:mx-0">
          {tiers.map((tier) => {
            const price = billingInterval === 'monthly' ? tier.price_monthly : tier.price_yearly;
            const isCurrentPlan = currentTierId === tier.id;
            
            return (
              <div
                key={tier.id}
                className={`${
                  tier.name === 'Premium' 
                    ? 'border-2 border-emerald-500 shadow-xl' 
                    : 'border border-gray-200'
                } rounded-lg shadow-sm divide-y divide-gray-200 bg-white`}
              >
                {tier.name === 'Premium' && (
                  <div className="bg-emerald-500 text-white text-center py-1 rounded-t-lg">
                    Most Popular
                  </div>
                )}
                
                <div className="p-6">
                  <h2 className="text-xl font-semibold text-gray-900">{tier.name}</h2>
                  <p className="mt-2 text-gray-500">{tier.description}</p>
                  <p className="mt-4">
                    <span className="text-3xl font-extrabold text-gray-900">${price}</span>
                    <span className="text-base font-medium text-gray-500">
                      /{billingInterval === 'monthly' ? 'mo' : 'yr'}
                    </span>
                  </p>
                  
                  <ul className="mt-6 space-y-4">
                    {tier.features.map((feature, index) => (
                      <li key={index} className="flex">
                        <svg
                          className="flex-shrink-0 h-5 w-5 text-emerald-500"
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 20 20"
                          fill="currentColor"
                          aria-hidden="true"
                        >
                          <path
                            fillRule="evenodd"
                            d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                            clipRule="evenodd"
                          />
                        </svg>
                        <span className="ml-3 text-gray-500">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <div className="mt-8">
                    {isCurrentPlan ? (
                      <button
                        disabled
                        className="w-full bg-gray-100 text-gray-800 py-2 px-4 rounded-md font-medium"
                      >
                        Current Plan
                      </button>
                    ) : (
                      <button
                        onClick={() => handleSubscription(tier)}
                        disabled={loading === tier.id}
                        className={`w-full ${
                          tier.name === 'Premium'
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            : tier.name === 'Pro'
                            ? 'bg-gray-800 hover:bg-gray-900 text-white'
                            : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                        } py-2 px-4 rounded-md font-medium transition-colors`}
                      >
                        {loading === tier.id
                          ? 'Processing...'
                          : tier.name === 'Free'
                          ? 'Sign Up Free'
                          : `Get ${tier.name}`}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
