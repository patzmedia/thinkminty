'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import Link from 'next/link';

interface ContentDetails {
  id: string;
  title: string;
  description: string;
  content: string;
  featured_image_url: string | null;
  author: {
    id: string;
    full_name: string;
  };
  category: {
    id: string;
    name: string;
    slug: string;
  };
  published_at: string;
  view_count: number;
  tags: {
    id: string;
    name: string;
    slug: string;
  }[];
  related_content?: {
    id: string;
    title: string;
    featured_image_url: string | null;
  }[];
}

export default function ContentDetail({ contentId }: { contentId: string }) {
  const [content, setContent] = useState<ContentDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchContentDetails = async () => {
      try {
        setLoading(true);
        
        // Increment view count
        await supabase.rpc('increment_content_view', { content_id: contentId });
        
        // Fetch content details
        const { data, error } = await supabase
          .from('content_items')
          .select(`
            id,
            title,
            description,
            content,
            featured_image_url,
            published_at,
            view_count,
            author:author_id (
              id,
              full_name
            ),
            category:category_id (
              id,
              name,
              slug
            ),
            tags:content_items_tags (
              tag:tag_id (
                id,
                name,
                slug
              )
            )
          `)
          .eq('id', contentId)
          .eq('status', 'published')
          .single();

        if (error) {
          throw error;
        }

        // Transform tags data structure
        const transformedData = {
          ...data,
          tags: data.tags.map((tag: any) => tag.tag),
        };

        // Fetch related content
        const { data: relatedData, error: relatedError } = await supabase
          .from('content_items')
          .select('id, title, featured_image_url')
          .eq('category_id', data.category.id)
          .eq('status', 'published')
          .neq('id', contentId)
          .limit(3);

        if (relatedError) {
          console.error('Error fetching related content:', relatedError);
        } else {
          transformedData.related_content = relatedData;
        }

        setContent(transformedData);
      } catch (error: any) {
        setError(error.message || 'An error occurred while fetching content');
        console.error('Error fetching content details:', error);
      } finally {
        setLoading(false);
      }
    };

    if (contentId) {
      fetchContentDetails();
    }
  }, [contentId]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-10 bg-gray-200 rounded w-3/4 mb-6"></div>
          <div className="h-6 bg-gray-200 rounded w-1/2 mb-8"></div>
          <div className="h-64 bg-gray-200 rounded mb-8"></div>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-4 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error || !content) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 text-red-600 p-6 rounded-md">
          <h2 className="text-xl font-bold mb-2">Error Loading Content</h2>
          <p>{error || 'Content not found or not available'}</p>
          <Link href="/content" className="mt-4 inline-block text-emerald-600 hover:underline">
            Back to Content
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Breadcrumb */}
        <div className="mb-6 text-sm text-gray-500">
          <Link href="/content" className="hover:text-emerald-600">
            Content
          </Link>
          <span className="mx-2">/</span>
          <Link href={`/content/category/${content.category.slug}`} className="hover:text-emerald-600">
            {content.category.name}
          </Link>
          <span className="mx-2">/</span>
          <span className="text-gray-700">{content.title}</span>
        </div>
        
        {/* Title and meta */}
        <h1 className="text-3xl md:text-4xl font-bold mb-4">{content.title}</h1>
        
        <div className="flex flex-wrap items-center text-sm text-gray-500 mb-8">
          <span>By {content.author.full_name}</span>
          <span className="mx-2">•</span>
          <span>{new Date(content.published_at).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          })}</span>
          <span className="mx-2">•</span>
          <span>{content.view_count} views</span>
        </div>
        
        {/* Featured image */}
        {content.featured_image_url && (
          <div className="mb-8">
            <img
              src={content.featured_image_url}
              alt={content.title}
              className="w-full h-auto rounded-lg"
            />
          </div>
        )}
        
        {/* Description */}
        <div className="text-lg text-gray-700 mb-8 font-medium">
          {content.description}
        </div>
        
        {/* Content */}
        <div className="prose prose-emerald max-w-none mb-12" 
          dangerouslySetInnerHTML={{ __html: content.content }} 
        />
        
        {/* Tags */}
        {content.tags && content.tags.length > 0 && (
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-2">Tags</h3>
            <div className="flex flex-wrap gap-2">
              {content.tags.map((tag) => (
                <Link
                  key={tag.id}
                  href={`/content/tag/${tag.slug}`}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-1 rounded-full text-sm"
                >
                  {tag.name}
                </Link>
              ))}
            </div>
          </div>
        )}
        
        {/* Related content */}
        {content.related_content && content.related_content.length > 0 && (
          <div className="mt-12">
            <h3 className="text-xl font-bold mb-6">Related Content</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {content.related_content.map((item) => (
                <Link key={item.id} href={`/content/${item.id}`}>
                  <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
                    {item.featured_image_url ? (
                      <div 
                        className="h-40 bg-cover bg-center" 
                        style={{ backgroundImage: `url(${item.featured_image_url})` }}
                      ></div>
                    ) : (
                      <div className="h-40 bg-gray-200 flex items-center justify-center">
                        <span className="text-gray-400">No image</span>
                      </div>
                    )}
                    <div className="p-4">
                      <h4 className="font-medium text-gray-900 line-clamp-2">{item.title}</h4>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
