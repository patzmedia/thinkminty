'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import Link from 'next/link';

interface ContentCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  parent_id: string | null;
  image_url: string | null;
  is_active: boolean;
  display_order: number;
  content_count?: number;
}

export default function CategoryManager() {
  const [categories, setCategories] = useState<ContentCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [newCategory, setNewCategory] = useState({
    name: '',
    description: '',
    parent_id: '',
    is_active: true,
  });
  const [isAdding, setIsAdding] = useState(false);
  const [addingCategory, setAddingCategory] = useState(false);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      
      // Get categories with content count
      const { data, error } = await supabase
        .from('content_categories')
        .select(`
          *,
          content_count:content_items(count)
        `)
        .order('display_order', { ascending: true });

      if (error) {
        throw error;
      }

      // Transform data to include content count
      const categoriesWithCount = data.map(category => ({
        ...category,
        content_count: category.content_count?.[0]?.count || 0
      }));

      setCategories(categoriesWithCount);
    } catch (error: any) {
      setError(error.message || 'An error occurred while fetching categories');
      console.error('Error fetching categories:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddingCategory(true);
    
    try {
      // Generate slug from name
      const slug = newCategory.name
        .toLowerCase()
        .replace(/[^\w\s]/gi, '')
        .replace(/\s+/g, '-');
      
      // Get max display order
      const maxOrder = categories.length > 0
        ? Math.max(...categories.map(c => c.display_order || 0))
        : 0;
      
      // Insert new category
      const { data, error } = await supabase
        .from('content_categories')
        .insert({
          name: newCategory.name,
          slug,
          description: newCategory.description,
          parent_id: newCategory.parent_id || null,
          is_active: newCategory.is_active,
          display_order: maxOrder + 1,
        })
        .select();

      if (error) {
        throw error;
      }

      // Reset form and refresh categories
      setNewCategory({
        name: '',
        description: '',
        parent_id: '',
        is_active: true,
      });
      setIsAdding(false);
      fetchCategories();
    } catch (error: any) {
      setError(error.message || 'An error occurred while adding the category');
      console.error('Error adding category:', error);
    } finally {
      setAddingCategory(false);
    }
  };

  const handleToggleActive = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('content_categories')
        .update({ is_active: !currentStatus })
        .eq('id', id);

      if (error) {
        throw error;
      }

      // Update local state
      setCategories(
        categories.map(category =>
          category.id === id
            ? { ...category, is_active: !currentStatus }
            : category
        )
      );
    } catch (error: any) {
      alert(`Error updating category: ${error.message}`);
      console.error('Error updating category:', error);
    }
  };

  const handleDeleteCategory = async (id: string, contentCount: number) => {
    if (contentCount > 0) {
      alert(`Cannot delete category with ${contentCount} content items. Reassign content first.`);
      return;
    }

    if (!confirm('Are you sure you want to delete this category?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('content_categories')
        .delete()
        .eq('id', id);

      if (error) {
        throw error;
      }

      // Remove from local state
      setCategories(categories.filter(category => category.id !== id));
    } catch (error: any) {
      alert(`Error deleting category: ${error.message}`);
      console.error('Error deleting category:', error);
    }
  };

  if (loading && categories.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Category Management</h2>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
        >
          {isAdding ? 'Cancel' : 'Add Category'}
        </button>
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}

      {isAdding && (
        <div className="mb-8 p-4 border border-gray-200 rounded-md">
          <h3 className="text-lg font-semibold mb-4">Add New Category</h3>
          <form onSubmit={handleAddCategory}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="name" className="block text-gray-700 mb-1">
                  Name
                </label>
                <input
                  id="name"
                  type="text"
                  value={newCategory.name}
                  onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="parent" className="block text-gray-700 mb-1">
                  Parent Category (Optional)
                </label>
                <select
                  id="parent"
                  value={newCategory.parent_id}
                  onChange={(e) => setNewCategory({ ...newCategory, parent_id: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">None (Top Level)</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="mb-4">
              <label htmlFor="description" className="block text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="description"
                value={newCategory.description}
                onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                rows={2}
              />
            </div>
            
            <div className="mb-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={newCategory.is_active}
                  onChange={(e) => setNewCategory({ ...newCategory, is_active: e.target.checked })}
                  className="h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-gray-700">Active</span>
              </label>
            </div>
            
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={addingCategory}
                className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
              >
                {addingCategory ? 'Adding...' : 'Add Category'}
              </button>
            </div>
          </form>
        </div>
      )}

      {categories.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500 mb-4">No categories found</p>
          <button
            onClick={() => setIsAdding(true)}
            className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
          >
            Create Your First Category
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Name
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Description
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Content Count
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Status
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {categories.map((category) => (
                <tr key={category.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {category.name}
                    </div>
                    {category.parent_id && (
                      <div className="text-xs text-gray-500">
                        Sub-category of {categories.find(c => c.id === category.parent_id)?.name}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-500 truncate max-w-xs">
                      {category.description || 'No description'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {category.content_count}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        category.is_active
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {category.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                      <button
                        onClick={() => handleToggleActive(category.id, category.is_active)}
                        className="text-indigo-600 hover:text-indigo-900"
                      >
                        {category.is_active ? 'Deactivate' : 'Activate'}
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(category.id, category.content_count || 0)}
                        className="text-red-600 hover:text-red-900"
                        disabled={category.content_count! > 0}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
