'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import Link from 'next/link';

interface ForumTopic {
  id: string;
  title: string;
  slug: string;
  content: string;
  created_at: string;
  updated_at: string;
  is_pinned: boolean;
  is_locked: boolean;
  view_count: number;
  reply_count: number;
  author: {
    id: string;
    full_name: string;
    avatar_url: string | null;
  };
  last_reply?: {
    created_at: string;
    author: {
      full_name: string;
    };
  };
}

interface TopicListProps {
  categoryId?: string;
  categoryName?: string;
  categorySlug?: string;
}

export default function TopicList({ categoryId, categoryName, categorySlug }: TopicListProps) {
  const [topics, setTopics] = useState<ForumTopic[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTopics = async () => {
      try {
        setLoading(true);
        
        let query = supabase
          .from('forum_topics')
          .select(`
            id,
            title,
            slug,
            content,
            created_at,
            updated_at,
            is_pinned,
            is_locked,
            view_count,
            author:author_id (
              id,
              full_name,
              avatar_url
            ),
            reply_count:forum_replies(count),
            last_reply:forum_replies(
              created_at,
              author:author_id (
                full_name
              )
            )
          `);
        
        if (categoryId) {
          query = query.eq('category_id', categoryId);
        }
        
        const { data, error } = await query
          .order('is_pinned', { ascending: false })
          .order('created_at', { ascending: false });

        if (error) {
          throw error;
        }

        // Transform data to include reply count and last reply
        const transformedData = data.map(topic => ({
          ...topic,
          reply_count: topic.reply_count?.[0]?.count || 0,
          last_reply: topic.last_reply?.length 
            ? topic.last_reply.sort((a: any, b: any) => 
                new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
              )[0]
            : undefined
        }));

        setTopics(transformedData);
      } catch (error: any) {
        setError(error.message || 'An error occurred while fetching topics');
        console.error('Error fetching topics:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTopics();
  }, [categoryId]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-md p-6">
                <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 text-red-600 p-6 rounded-md">
          <h2 className="text-xl font-bold mb-2">Error Loading Topics</h2>
          <p>{error}</p>
          <Link href="/community" className="mt-4 inline-block text-emerald-600 hover:underline">
            Back to Community
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <div className="flex items-center space-x-2 mb-2">
            <Link href="/community" className="text-emerald-600 hover:underline">
              Community
            </Link>
            {categoryName && (
              <>
                <span className="text-gray-500">/</span>
                <span className="font-medium">{categoryName}</span>
              </>
            )}
          </div>
          <h1 className="text-3xl font-bold">
            {categoryName ? `${categoryName} Discussions` : 'All Topics'}
          </h1>
        </div>
        <Link
          href={categorySlug ? `/community/new-topic?category=${categorySlug}` : "/community/new-topic"}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-md font-medium transition-colors"
        >
          Start New Topic
        </Link>
      </div>

      {topics.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-md">
          <p className="text-gray-500 text-lg mb-4">No topics found</p>
          <p className="text-gray-400 mb-6">Be the first to start a discussion!</p>
          <Link
            href={categorySlug ? `/community/new-topic?category=${categorySlug}` : "/community/new-topic"}
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-md font-medium transition-colors"
          >
            Start New Topic
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {topics.map((topic) => (
            <div 
              key={topic.id} 
              className={`bg-white rounded-lg shadow-md p-6 ${
                topic.is_pinned ? 'border-l-4 border-emerald-500' : ''
              }`}
            >
              <div className="flex items-start">
                <div className="flex-shrink-0 mr-4">
                  {topic.author.avatar_url ? (
                    <img
                      src={topic.author.avatar_url}
                      alt={topic.author.full_name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                      <span className="text-gray-500 font-medium">
                        {topic.author.full_name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  )}
                </div>
                <div className="flex-grow">
                  <Link href={`/community/topic/${topic.id}`}>
                    <h2 className="text-xl font-semibold text-gray-900 hover:text-emerald-600 mb-1 group">
                      <span className="group-hover:underline">{topic.title}</span>
                      {topic.is_pinned && (
                        <span className="ml-2 text-xs bg-emerald-100 text-emerald-800 px-2 py-1 rounded-full">
                          Pinned
                        </span>
                      )}
                      {topic.is_locked && (
                        <span className="ml-2 text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded-full">
                          Locked
                        </span>
                      )}
                    </h2>
                  </Link>
                  <p className="text-sm text-gray-500 mb-2">
                    Started by {topic.author.full_name} • {new Date(topic.created_at).toLocaleDateString()}
                  </p>
                  <div className="flex items-center text-xs text-gray-500">
                    <span className="flex items-center mr-4">
                      <svg
                        className="w-4 h-4 mr-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                        />
                      </svg>
                      {topic.view_count} views
                    </span>
                    <span className="flex items-center">
                      <svg
                        className="w-4 h-4 mr-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                        />
                      </svg>
                      {topic.reply_count} replies
                    </span>
                  </div>
                </div>
                {topic.last_reply && (
                  <div className="flex-shrink-0 ml-4 text-right">
                    <p className="text-xs text-gray-500">Last reply</p>
                    <p className="text-sm font-medium">{topic.last_reply.author.full_name}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(topic.last_reply.created_at).toLocaleDateString()}
                    </p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
