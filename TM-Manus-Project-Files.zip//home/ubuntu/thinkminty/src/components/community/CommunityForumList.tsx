'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import Link from 'next/link';

interface ForumCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  image_url: string | null;
  topic_count: number;
}

export default function CommunityForumList() {
  const [categories, setCategories] = useState<ForumCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setLoading(true);
        
        // Get categories with topic count
        const { data, error } = await supabase
          .from('forum_categories')
          .select(`
            id,
            name,
            slug,
            description,
            image_url,
            topic_count:forum_topics(count)
          `)
          .eq('is_active', true)
          .order('display_order', { ascending: true });

        if (error) {
          throw error;
        }

        // Transform data to include topic count
        const categoriesWithCount = data.map(category => ({
          ...category,
          topic_count: category.topic_count?.[0]?.count || 0
        }));

        setCategories(categoriesWithCount);
      } catch (error: any) {
        setError(error.message || 'An error occurred while fetching categories');
        console.error('Error fetching categories:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-md p-6">
                <div className="h-6 bg-gray-200 rounded w-1/3 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 text-red-600 p-6 rounded-md">
          <h2 className="text-xl font-bold mb-2">Error Loading Community</h2>
          <p>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Community Forum</h1>
        <Link
          href="/community/new-topic"
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-md font-medium transition-colors"
        >
          Start New Topic
        </Link>
      </div>

      <p className="text-gray-600 mb-8">
        Join our community discussions about positive living, mindfulness, and personal growth.
      </p>

      {categories.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-md">
          <p className="text-gray-500 text-lg mb-4">No forum categories found</p>
          <p className="text-gray-400">Check back soon for community discussions</p>
        </div>
      ) : (
        <div className="space-y-4">
          {categories.map((category) => (
            <Link key={category.id} href={`/community/category/${category.slug}`}>
              <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start">
                  {category.image_url ? (
                    <div className="flex-shrink-0 mr-4">
                      <img
                        src={category.image_url}
                        alt={category.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="flex-shrink-0 mr-4 w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center">
                      <svg
                        className="w-6 h-6 text-emerald-600"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z"
                        />
                      </svg>
                    </div>
                  )}
                  <div className="flex-grow">
                    <h2 className="text-xl font-semibold text-gray-900 mb-1">
                      {category.name}
                    </h2>
                    <p className="text-gray-600 mb-2">{category.description}</p>
                    <p className="text-sm text-gray-500">
                      {category.topic_count} {category.topic_count === 1 ? 'topic' : 'topics'}
                    </p>
                  </div>
                  <div className="flex-shrink-0 ml-4">
                    <svg
                      className="w-5 h-5 text-gray-400"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
