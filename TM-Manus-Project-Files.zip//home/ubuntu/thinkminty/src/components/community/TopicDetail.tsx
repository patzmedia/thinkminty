'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import Link from 'next/link';

interface TopicDetail {
  id: string;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
  is_pinned: boolean;
  is_locked: boolean;
  view_count: number;
  author: {
    id: string;
    full_name: string;
    avatar_url: string | null;
  };
  category: {
    id: string;
    name: string;
    slug: string;
  };
  replies: {
    id: string;
    content: string;
    created_at: string;
    updated_at: string;
    author: {
      id: string;
      full_name: string;
      avatar_url: string | null;
    };
  }[];
}

export default function TopicDetail({ topicId }: { topicId: string }) {
  const [topic, setTopic] = useState<TopicDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [submittingReply, setSubmittingReply] = useState(false);
  const [replyError, setReplyError] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setIsAuthenticated(!!session);
    };

    checkAuth();
    fetchTopicDetails();
  }, [topicId]);

  const fetchTopicDetails = async () => {
    try {
      setLoading(true);
      
      // Increment view count
      await supabase.rpc('increment_topic_view', { topic_id: topicId });
      
      // Fetch topic details
      const { data, error } = await supabase
        .from('forum_topics')
        .select(`
          id,
          title,
          content,
          created_at,
          updated_at,
          is_pinned,
          is_locked,
          view_count,
          author:author_id (
            id,
            full_name,
            avatar_url
          ),
          category:category_id (
            id,
            name,
            slug
          ),
          replies:forum_replies (
            id,
            content,
            created_at,
            updated_at,
            author:author_id (
              id,
              full_name,
              avatar_url
            )
          )
        `)
        .eq('id', topicId)
        .single();

      if (error) {
        throw error;
      }

      // Sort replies by creation date
      const sortedReplies = data.replies.sort((a: any, b: any) => 
        new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
      );

      setTopic({
        ...data,
        replies: sortedReplies
      });
    } catch (error: any) {
      setError(error.message || 'An error occurred while fetching topic details');
      console.error('Error fetching topic details:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitReply = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingReply(true);
    setReplyError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        window.location.href = '/auth/signin?redirect=/community/topic/' + topicId;
        return;
      }

      // Check if topic is locked
      if (topic?.is_locked) {
        throw new Error('This topic is locked and cannot receive new replies');
      }

      // Create new reply
      const { error } = await supabase
        .from('forum_replies')
        .insert({
          content: replyContent,
          author_id: session.user.id,
          topic_id: topicId,
        });

      if (error) {
        throw error;
      }

      // Clear reply content and refresh topic
      setReplyContent('');
      fetchTopicDetails();
    } catch (error: any) {
      setReplyError(error.message || 'An error occurred while submitting your reply');
      console.error('Error submitting reply:', error);
    } finally {
      setSubmittingReply(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-3/4 mb-6"></div>
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <div className="flex items-start">
                <div className="flex-shrink-0 mr-4">
                  <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                </div>
                <div className="flex-grow">
                  <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                </div>
              </div>
            </div>
            
            <div className="h-6 bg-gray-200 rounded w-1/4 mb-4"></div>
            
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-md p-6 mb-4">
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-4">
                    <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                  </div>
                  <div className="flex-grow">
                    <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error || !topic) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-red-50 text-red-600 p-6 rounded-md">
            <h2 className="text-xl font-bold mb-2">Error Loading Topic</h2>
            <p>{error || 'Topic not found'}</p>
            <Link href="/community" className="mt-4 inline-block text-emerald-600 hover:underline">
              Back to Community
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Breadcrumb */}
        <div className="flex items-center space-x-2 mb-6">
          <Link href="/community" className="text-emerald-600 hover:underline">
            Community
          </Link>
          <span className="text-gray-500">/</span>
          <Link href={`/community/category/${topic.category.slug}`} className="text-emerald-600 hover:underline">
            {topic.category.name}
          </Link>
          <span className="text-gray-500">/</span>
          <span className="font-medium">{topic.title}</span>
        </div>
        
        {/* Topic header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex justify-between items-start mb-4">
            <h1 className="text-2xl font-bold">
              {topic.title}
              {topic.is_pinned && (
                <span className="ml-2 text-xs bg-emerald-100 text-emerald-800 px-2 py-1 rounded-full">
                  Pinned
                </span>
              )}
              {topic.is_locked && (
                <span className="ml-2 text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded-full">
                  Locked
                </span>
              )}
            </h1>
            <div className="text-sm text-gray-500">
              {topic.view_count} views
            </div>
          </div>
          
          <div className="flex items-start">
            <div className="flex-shrink-0 mr-4">
              {topic.author.avatar_url ? (
                <img
                  src={topic.author.avatar_url}
                  alt={topic.author.full_name}
                  className="w-10 h-10 rounded-full object-cover"
                />
              ) : (
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                  <span className="text-gray-500 font-medium">
                    {topic.author.full_name.charAt(0).toUpperCase()}
                  </span>
                </div>
              )}
            </div>
            <div className="flex-grow">
              <div className="flex items-center mb-2">
                <span className="font-medium">{topic.author.full_name}</span>
                <span className="mx-2 text-gray-300">•</span>
                <span className="text-sm text-gray-500">
                  {new Date(topic.created_at).toLocaleDateString()} at {new Date(topic.created_at).toLocaleTimeString()}
                </span>
              </div>
              <div className="prose max-w-none">
                {topic.content}
              </div>
            </div>
          </div>
        </div>
        
        {/* Replies */}
        {topic.replies.length > 0 && (
          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-4">
              {topic.replies.length} {topic.replies.length === 1 ? 'Reply' : 'Replies'}
            </h2>
            
            <div className="space-y-4">
              {topic.replies.map((reply) => (
                <div key={reply.id} className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mr-4">
                      {reply.author.avatar_url ? (
                        <img
                          src={reply.author.avatar_url}
                          alt={reply.author.full_name}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                          <span className="text-gray-500 font-medium">
                            {reply.author.full_name.charAt(0).toUpperCase()}
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="flex-grow">
                      <div className="flex items-center mb-2">
                        <span className="font-medium">{reply.author.full_name}</span>
                        <span className="mx-2 text-gray-300">•</span>
                        <span className="text-sm text-gray-500">
                          {new Date(reply.created_at).toLocaleDateString()} at {new Date(reply.created_at).toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="prose max-w-none">
                        {reply.content}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Reply form */}
        {!topic.is_locked ? (
          isAuthenticated ? (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4">Post a Reply</h2>
              
              {replyError && (
                <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
                  {replyError}
                </div>
              )}
              
              <form onSubmit={handleSubmitReply}>
                <div className="mb-4">
                  <textarea
                    value={replyContent}
                    onChange={(e) => setReplyContent(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    rows={6}
                    required
                    placeholder="Share your thoughts..."
                  />
                </div>
                
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={submittingReply}
                    className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
                  >
                    {submittingReply ? 'Posting...' : 'Post Reply'}
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <p className="text-gray-600 mb-4">You need to be signed in to reply to this topic.</p>
              <Link
                href={`/auth/signin?redirect=/community/topic/${topicId}`}
                className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 inline-block"
              >
                Sign In to Reply
              </Link>
            </div>
          )
        ) : (
          <div className="bg-gray-50 rounded-lg p-6 text-center">
            <p className="text-gray-600">
              This topic is locked and cannot receive new replies.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
