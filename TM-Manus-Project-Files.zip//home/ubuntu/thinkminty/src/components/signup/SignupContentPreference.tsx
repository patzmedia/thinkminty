'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

interface SignupContentPreferenceProps {
  userId: string;
  onComplete?: () => void;
}

export default function SignupContentPreference({ userId, onComplete }: SignupContentPreferenceProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [contentLengthPreference, setContentLengthPreference] = useState<'short-form' | 'long-form'>('short-form');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [categories, setCategories] = useState<{id: string, name: string, description: string}[]>([]);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('content_categories')
        .select('id, name, description')
        .is('parent_id', null)
        .order('display_order', { ascending: true });

      if (error) throw error;
      setCategories(data || []);
    } catch (error: any) {
      console.error('Error fetching categories:', error);
      setError('Failed to load categories. Please try again later.');
    }
  };

  const handleCategoryToggle = (categoryId: string) => {
    setSelectedCategories(prev => {
      if (prev.includes(categoryId)) {
        return prev.filter(id => id !== categoryId);
      } else {
        return [...prev, categoryId];
      }
    });
  };

  const handleSubmit = async () => {
    if (selectedCategories.length === 0) {
      setError('Please select at least one content category');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Update user's content length preference
      const { error: updateError } = await supabase
        .from('users')
        .update({ content_length_preference: contentLengthPreference })
        .eq('id', userId);

      if (updateError) throw updateError;

      // Save user's category preferences
      const categoryPreferences = selectedCategories.map(categoryId => ({
        user_id: userId,
        category_id: categoryId
      }));

      const { error: preferencesError } = await supabase
        .from('user_category_preferences')
        .insert(categoryPreferences);

      if (preferencesError) throw preferencesError;

      if (onComplete) {
        onComplete();
      } else {
        // Redirect to dashboard or next step
        router.push('/dashboard');
      }
    } catch (error: any) {
      console.error('Error saving preferences:', error);
      setError(error.message || 'An error occurred while saving your preferences');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-2">Content Preferences</h2>
      <p className="text-gray-600 mb-6">
        Customize your ThinkMinty experience by selecting your content preferences.
      </p>

      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}

      <div className="space-y-8">
        <div>
          <h3 className="text-lg font-semibold mb-3">Content Length Preference</h3>
          <p className="text-gray-600 mb-4">
            Choose whether you prefer shorter, quick reads or longer, more in-depth content.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div
              className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                contentLengthPreference === 'short-form'
                  ? 'border-emerald-500 bg-emerald-50'
                  : 'border-gray-200 hover:bg-gray-50'
              }`}
              onClick={() => setContentLengthPreference('short-form')}
            >
              <div className="flex items-start">
                <div className={`mt-1 w-5 h-5 rounded-full flex-shrink-0 ${
                  contentLengthPreference === 'short-form' ? 'bg-emerald-500' : 'bg-gray-200'
                }`}></div>
                <div className="ml-3">
                  <h4 className="font-medium">Short-Form Content</h4>
                  <p className="text-sm text-gray-600 mt-1">
                    Brief, focused content that can be read in about 1-2 minutes. Perfect for quick inspiration throughout your day.
                  </p>
                </div>
              </div>
            </div>

            <div
              className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                contentLengthPreference === 'long-form'
                  ? 'border-emerald-500 bg-emerald-50'
                  : 'border-gray-200 hover:bg-gray-50'
              }`}
              onClick={() => setContentLengthPreference('long-form')}
            >
              <div className="flex items-start">
                <div className={`mt-1 w-5 h-5 rounded-full flex-shrink-0 ${
                  contentLengthPreference === 'long-form' ? 'bg-emerald-500' : 'bg-gray-200'
                }`}></div>
                <div className="ml-3">
                  <h4 className="font-medium">Long-Form Content</h4>
                  <p className="text-sm text-gray-600 mt-1">
                    More in-depth content that takes about 5-10 minutes to read. Ideal for deeper exploration and reflection.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-3">Content Categories</h3>
          <p className="text-gray-600 mb-4">
            Select the types of content you're most interested in receiving. You can choose multiple categories.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((category) => (
              <div
                key={category.id}
                className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                  selectedCategories.includes(category.id)
                    ? 'border-emerald-500 bg-emerald-50'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
                onClick={() => handleCategoryToggle(category.id)}
              >
                <div className="flex items-start">
                  <div className={`mt-1 w-5 h-5 rounded flex-shrink-0 ${
                    selectedCategories.includes(category.id) ? 'bg-emerald-500' : 'bg-gray-200'
                  }`}></div>
                  <div className="ml-3">
                    <h4 className="font-medium">{category.name}</h4>
                    <p className="text-sm text-gray-600 mt-1">
                      {category.description || `Content focused on ${category.name.toLowerCase()}`}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="px-6 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
          >
            {loading ? 'Saving...' : 'Save Preferences'}
          </button>
        </div>
      </div>
    </div>
  );
}
