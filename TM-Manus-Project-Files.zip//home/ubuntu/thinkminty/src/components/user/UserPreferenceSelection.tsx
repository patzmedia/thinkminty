'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';

interface Category {
  id: string;
  name: string;
  description: string;
  parent_id: string | null;
  parent_name?: string;
}

export default function UserPreferenceSelection({ userId, isSignup = false, redirectUrl = '/dashboard' }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [mainCategories, setMainCategories] = useState<Category[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const router = useRouter();

  useEffect(() => {
    fetchCategories();
    fetchUserPreferences();
  }, [userId]);

  const fetchCategories = async () => {
    try {
      // Get all categories
      const { data, error } = await supabase
        .from('content_categories')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });

      if (error) {
        throw error;
      }

      // Separate main categories and subcategories
      const mainCats = data.filter(cat => cat.parent_id === null);
      
      // Add parent name to subcategories
      const allCategoriesWithParentNames = data.map(category => {
        if (category.parent_id) {
          const parentCategory = data.find(c => c.id === category.parent_id);
          return {
            ...category,
            parent_name: parentCategory ? parentCategory.name : undefined
          };
        }
        return category;
      });

      setCategories(allCategoriesWithParentNames);
      setMainCategories(mainCats);
    } catch (error: any) {
      console.error('Error fetching categories:', error);
      setError('Failed to load categories. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const fetchUserPreferences = async () => {
    if (!userId) return;
    
    try {
      const { data, error } = await supabase
        .from('user_preferences')
        .select('category_id')
        .eq('user_id', userId);

      if (error) {
        throw error;
      }

      if (data && data.length > 0) {
        setSelectedCategories(data.map(pref => pref.category_id));
      }
    } catch (error: any) {
      console.error('Error fetching user preferences:', error);
    }
  };

  const handleCategoryToggle = (categoryId: string) => {
    setSelectedCategories(prev => {
      if (prev.includes(categoryId)) {
        return prev.filter(id => id !== categoryId);
      } else {
        return [...prev, categoryId];
      }
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (selectedCategories.length === 0) {
      setError('Please select at least one category');
      return;
    }
    
    setSubmitting(true);
    setError(null);
    
    try {
      // First delete existing preferences
      if (!isSignup) {
        const { error: deleteError } = await supabase
          .from('user_preferences')
          .delete()
          .eq('user_id', userId);

        if (deleteError) {
          throw deleteError;
        }
      }

      // Insert new preferences
      const preferences = selectedCategories.map(categoryId => ({
        user_id: userId,
        category_id: categoryId
      }));

      const { error: insertError } = await supabase
        .from('user_preferences')
        .insert(preferences);

      if (insertError) {
        throw insertError;
      }

      setSuccess(true);
      
      // Redirect if on signup flow
      if (isSignup) {
        router.push(redirectUrl);
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred while saving your preferences');
      console.error('Error saving preferences:', error);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-2">
        {isSignup ? 'Choose Your Content Preferences' : 'Update Your Content Preferences'}
      </h2>
      
      <p className="text-gray-600 mb-6">
        Select the types of positive content you'd like to receive. You can choose multiple categories.
        {isSignup && ' We recommend starting with one or two to see what resonates with you.'}
      </p>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {success && !isSignup && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          Your preferences have been updated successfully!
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {mainCategories.map((category) => {
            const isSelected = selectedCategories.includes(category.id);
            
            return (
              <div 
                key={category.id}
                className={`border rounded-lg p-4 cursor-pointer transition-all ${
                  isSelected 
                    ? 'border-emerald-500 bg-emerald-50' 
                    : 'border-gray-200 hover:border-emerald-300'
                }`}
                onClick={() => handleCategoryToggle(category.id)}
              >
                <div className="flex items-start mb-2">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={() => {}} // Handled by div click
                    className="h-5 w-5 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 mt-0.5"
                  />
                  <div className="ml-3">
                    <h3 className="font-medium text-gray-900">{category.name}</h3>
                  </div>
                </div>
                <p className="text-sm text-gray-500 ml-8">
                  {category.description}
                </p>
              </div>
            );
          })}
        </div>
        
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={submitting}
            className="px-6 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
          >
            {submitting 
              ? 'Saving...' 
              : isSignup 
                ? 'Continue' 
                : 'Save Preferences'
            }
          </button>
        </div>
      </form>
    </div>
  );
}
