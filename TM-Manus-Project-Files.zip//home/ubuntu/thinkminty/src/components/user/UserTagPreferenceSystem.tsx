'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface UserTagPreferenceProps {
  userId: string;
  onComplete?: () => void;
}

interface Tag {
  id: string;
  name: string;
  tag_type: string;
  description: string;
}

interface UserPreference {
  tag_id: string;
  preference_type: 'prefer' | 'neutral' | 'avoid';
}

export default function UserTagPreferenceSystem({ userId, onComplete }: UserTagPreferenceProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [availableTags, setAvailableTags] = useState<Tag[]>([]);
  const [userPreferences, setUserPreferences] = useState<UserPreference[]>([]);
  const [filterTagType, setFilterTagType] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (userId) {
      fetchAvailableTags();
      fetchUserPreferences();
    }
  }, [userId]);

  const fetchAvailableTags = async () => {
    try {
      const { data, error } = await supabase
        .from('tags')
        .select('*')
        .order('name');

      if (error) throw error;
      setAvailableTags(data || []);
    } catch (error: any) {
      console.error('Error fetching tags:', error);
      setError('Failed to load tags. Please try again later.');
    }
  };

  const fetchUserPreferences = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('user_tag_preferences')
        .select('tag_id, preference_type')
        .eq('user_id', userId);

      if (error) throw error;
      
      setUserPreferences(data || []);
    } catch (error: any) {
      console.error('Error fetching user preferences:', error);
      setError('Failed to load your preferences. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const getTagPreference = (tagId: string): 'prefer' | 'neutral' | 'avoid' => {
    const preference = userPreferences.find(p => p.tag_id === tagId);
    return preference ? preference.preference_type : 'neutral';
  };

  const handlePreferenceChange = (tagId: string, preferenceType: 'prefer' | 'neutral' | 'avoid') => {
    setUserPreferences(prev => {
      // Remove existing preference if any
      const filtered = prev.filter(p => p.tag_id !== tagId);
      
      // If setting to neutral, just remove the preference
      if (preferenceType === 'neutral') {
        return filtered;
      }
      
      // Otherwise add the new preference
      return [...filtered, { tag_id: tagId, preference_type: preferenceType }];
    });
  };

  const handleSavePreferences = async () => {
    setSubmitting(true);
    setError(null);
    setSuccess(null);
    
    try {
      // Get current preferences from database
      const { data: currentPrefs, error: fetchError } = await supabase
        .from('user_tag_preferences')
        .select('id, tag_id, preference_type')
        .eq('user_id', userId);
      
      if (fetchError) throw fetchError;
      
      // Create maps for easier comparison
      const currentPrefsMap = new Map();
      currentPrefs.forEach((pref: any) => {
        currentPrefsMap.set(pref.tag_id, { id: pref.id, type: pref.preference_type });
      });
      
      const newPrefsMap = new Map();
      userPreferences.forEach(pref => {
        newPrefsMap.set(pref.tag_id, pref.preference_type);
      });
      
      // Determine which preferences to add, update, or delete
      const toAdd: any[] = [];
      const toUpdate: any[] = [];
      const toDelete: string[] = [];
      
      // Find preferences to add or update
      newPrefsMap.forEach((prefType, tagId) => {
        const currentPref = currentPrefsMap.get(tagId);
        
        if (!currentPref) {
          // New preference to add
          toAdd.push({
            user_id: userId,
            tag_id: tagId,
            preference_type: prefType
          });
        } else if (currentPref.type !== prefType) {
          // Existing preference to update
          toUpdate.push({
            id: currentPref.id,
            preference_type: prefType
          });
        }
      });
      
      // Find preferences to delete (in current but not in new)
      currentPrefsMap.forEach((pref, tagId) => {
        if (!newPrefsMap.has(tagId)) {
          toDelete.push(pref.id);
        }
      });
      
      // Execute database operations
      
      // Add new preferences
      if (toAdd.length > 0) {
        const { error: insertError } = await supabase
          .from('user_tag_preferences')
          .insert(toAdd);
        
        if (insertError) throw insertError;
      }
      
      // Update existing preferences
      for (const pref of toUpdate) {
        const { error: updateError } = await supabase
          .from('user_tag_preferences')
          .update({ preference_type: pref.preference_type })
          .eq('id', pref.id);
        
        if (updateError) throw updateError;
      }
      
      // Delete removed preferences
      if (toDelete.length > 0) {
        const { error: deleteError } = await supabase
          .from('user_tag_preferences')
          .delete()
          .in('id', toDelete);
        
        if (deleteError) throw deleteError;
      }
      
      setSuccess('Your content preferences have been saved successfully');
      
      if (onComplete) {
        onComplete();
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred while saving your preferences');
      console.error('Preference saving error:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const filteredTags = availableTags.filter(tag => {
    // Filter by tag type if selected
    if (filterTagType !== 'all' && tag.tag_type !== filterTagType) {
      return false;
    }
    
    // Filter by search term if provided
    if (searchTerm && !tag.name.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    return true;
  });

  // Group tags by type for better organization
  const groupedTags: { [key: string]: Tag[] } = {};
  
  filteredTags.forEach(tag => {
    if (!groupedTags[tag.tag_type]) {
      groupedTags[tag.tag_type] = [];
    }
    groupedTags[tag.tag_type].push(tag);
  });

  // Order of tag types for display
  const tagTypeOrder = [
    'emotional',
    'action',
    'theme',
    'source'
  ];

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-4 bg-gray-200 rounded w-full"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Content Preferences</h2>
      
      <p className="text-gray-600 mb-6">
        Customize your content experience by setting preferences for different topics and themes. 
        Choose topics you'd like to see more of, or topics you'd prefer to avoid.
      </p>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 text-green-800 p-3 rounded-md mb-4">
          {success}
        </div>
      )}
      
      <div className="mb-6">
        <div className="flex flex-col sm:flex-row gap-2 mb-4">
          <div className="flex-grow">
            <input
              type="text"
              placeholder="Search topics..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          
          <div>
            <select
              value={filterTagType}
              onChange={(e) => setFilterTagType(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Tag Types</option>
              <option value="emotional">Emotions</option>
              <option value="action">Actions</option>
              <option value="theme">Themes</option>
              <option value="source">Sources</option>
            </select>
          </div>
        </div>
        
        <div className="bg-gray-50 p-4 rounded-md mb-4">
          <h3 className="font-medium mb-2">How to Set Your Preferences</h3>
          <ul className="text-sm text-gray-700 space-y-1">
            <li className="flex items-center">
              <span className="inline-block w-4 h-4 bg-emerald-500 rounded-full mr-2"></span>
              <span>Select <strong>Prefer</strong> for topics you want to see more often</span>
            </li>
            <li className="flex items-center">
              <span className="inline-block w-4 h-4 bg-gray-300 rounded-full mr-2"></span>
              <span>Leave as <strong>Neutral</strong> for balanced content</span>
            </li>
            <li className="flex items-center">
              <span className="inline-block w-4 h-4 bg-red-500 rounded-full mr-2"></span>
              <span>Select <strong>Avoid</strong> for topics you want to see less often</span>
            </li>
          </ul>
        </div>
      </div>
      
      <div className="space-y-8 mb-8">
        {tagTypeOrder.map(tagType => {
          const tags = groupedTags[tagType];
          if (!tags || tags.length === 0) return null;
          
          return (
            <div key={tagType} className="border border-gray-200 rounded-md p-4">
              <h3 className="font-medium mb-4 capitalize">
                {tagType === 'emotional' ? 'Emotions' : 
                 tagType === 'action' ? 'Actions' : 
                 tagType === 'theme' ? 'Themes' : 
                 tagType === 'source' ? 'Sources' : tagType}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {tags.map(tag => {
                  const preference = getTagPreference(tag.id);
                  
                  return (
                    <div key={tag.id} className="border border-gray-200 rounded-md p-3">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">{tag.name}</span>
                      </div>
                      
                      {tag.description && (
                        <p className="text-xs text-gray-500 mb-3">{tag.description}</p>
                      )}
                      
                      <div className="flex justify-between">
                        <button
                          onClick={() => handlePreferenceChange(tag.id, 'prefer')}
                          className={`px-2 py-1 text-xs rounded-md ${
                            preference === 'prefer'
                              ? 'bg-emerald-500 text-white'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                          }`}
                        >
                          Prefer
                        </button>
                        
                        <button
                          onClick={() => handlePreferenceChange(tag.id, 'neutral')}
                          className={`px-2 py-1 text-xs rounded-md ${
                            preference === 'neutral'
                              ? 'bg-gray-300 text-gray-700'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                          }`}
                        >
                          Neutral
                        </button>
                        
                        <button
                          onClick={() => handlePreferenceChange(tag.id, 'avoid')}
                          className={`px-2 py-1 text-xs rounded-md ${
                            preference === 'avoid'
                              ? 'bg-red-500 text-white'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                          }`}
                        >
                          Avoid
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="flex justify-end">
        <button
          onClick={handleSavePreferences}
          disabled={submitting}
          className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
        >
          {submitting ? 'Saving...' : 'Save Preferences'}
        </button>
      </div>
    </div>
  );
}
