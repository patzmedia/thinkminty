'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface UserPreference {
  user_id: string;
  category_id: string;
  category_name: string;
}

interface ContentDelivery {
  id: string;
  user_id: string;
  content_set_id: string;
  delivered_at: string;
  content_set: {
    title: string;
    paragraph_content: string;
    quote_content: string;
    quote_author: string;
  };
}

export default function UserPreferenceDashboard() {
  const [userPreferences, setUserPreferences] = useState<UserPreference[]>([]);
  const [contentHistory, setContentHistory] = useState<ContentDelivery[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        setUserId(session.user.id);
        fetchUserPreferences(session.user.id);
        fetchContentHistory(session.user.id);
      }
    };

    checkAuth();
  }, []);

  const fetchUserPreferences = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('user_preferences')
        .select(`
          user_id,
          category_id,
          category:category_id(name)
        `)
        .eq('user_id', userId);

      if (error) {
        throw error;
      }

      // Transform data to include category name
      const transformedData = data.map(item => ({
        user_id: item.user_id,
        category_id: item.category_id,
        category_name: item.category.name
      }));

      setUserPreferences(transformedData);
    } catch (error: any) {
      console.error('Error fetching user preferences:', error);
      setError('Failed to load your preferences. Please try again later.');
    }
  };

  const fetchContentHistory = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('content_delivery_history')
        .select(`
          id,
          user_id,
          content_set_id,
          delivered_at,
          content_set:content_set_id(
            title,
            paragraph_content,
            quote_content,
            quote_author
          )
        `)
        .eq('user_id', userId)
        .order('delivered_at', { ascending: false })
        .limit(10);

      if (error) {
        throw error;
      }

      setContentHistory(data);
    } catch (error: any) {
      console.error('Error fetching content history:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-8"></div>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!userId) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-yellow-50 text-yellow-800 p-4 rounded-md">
          <p>Please sign in to view your preferences and content history.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6">Your Content Dashboard</h2>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Your Content Preferences</h3>
          <a 
            href="/preferences/edit" 
            className="text-emerald-600 hover:text-emerald-800 text-sm font-medium"
          >
            Edit Preferences
          </a>
        </div>
        
        {userPreferences.length === 0 ? (
          <div className="bg-gray-50 p-4 rounded-md text-center">
            <p className="text-gray-500 mb-2">You haven't set any content preferences yet.</p>
            <a 
              href="/preferences/edit" 
              className="text-emerald-600 hover:text-emerald-800 font-medium"
            >
              Set Your Preferences
            </a>
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {userPreferences.map((pref) => (
              <span 
                key={pref.category_id}
                className="px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-sm"
              >
                {pref.category_name}
              </span>
            ))}
          </div>
        )}
      </div>
      
      <div>
        <h3 className="text-xl font-semibold mb-4">Recent Content</h3>
        
        {contentHistory.length === 0 ? (
          <div className="bg-gray-50 p-4 rounded-md text-center">
            <p className="text-gray-500">
              You haven't received any personalized content yet.
              {userPreferences.length === 0 
                ? ' Set your preferences to start receiving content.'
                : ' Check back soon for your first personalized content.'}
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {contentHistory.map((item) => (
              <div key={item.id} className="bg-white rounded-lg shadow-md p-6">
                <div className="mb-4">
                  <h4 className="text-lg font-medium mb-2">{item.content_set.title}</h4>
                  <p className="text-sm text-gray-500">
                    Delivered on {new Date(item.delivered_at).toLocaleDateString()} at {new Date(item.delivered_at).toLocaleTimeString()}
                  </p>
                </div>
                
                <div className="prose max-w-none mb-4">
                  <p>{item.content_set.paragraph_content}</p>
                </div>
                
                <div className="border-l-4 border-emerald-200 pl-4 italic">
                  <p className="text-gray-700">{item.content_set.quote_content}</p>
                  {item.content_set.quote_author && (
                    <p className="text-gray-500 text-sm mt-1">— {item.content_set.quote_author}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
