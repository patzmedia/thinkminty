// Script to integrate additional content examples with the personalization system

const { supabase } = require('@/lib/supabase');
const { additionalContentExamples } = require('@/data/additional-content-examples');

/**
 * This script inserts the additional content examples into the database
 * and associates them with their respective categories.
 */
async function integrateAdditionalContent() {
  console.log('Starting content integration...');
  console.log(`Found ${additionalContentExamples.length} additional content examples to integrate`);
  
  // Get category mapping (name to ID)
  const { data: categories, error: categoryError } = await supabase
    .from('content_categories')
    .select('id, name, slug')
    .is('parent_id', null);
    
  if (categoryError) {
    console.error('Error fetching categories:', categoryError);
    return;
  }
  
  const categoryMap = {};
  categories.forEach(category => {
    categoryMap[category.name] = category.id;
  });
  
  console.log('Category mapping:', categoryMap);
  
  // Process each content example
  let successCount = 0;
  let errorCount = 0;
  
  for (const example of additionalContentExamples) {
    try {
      // Insert content set
      const { data: contentSet, error: contentError } = await supabase
        .from('content_sets')
        .insert({
          title: example.title,
          paragraph_content: example.paragraph_content,
          quote_content: example.quote_content,
          quote_author: example.quote_author,
          is_active: true
        })
        .select();
        
      if (contentError) {
        console.error(`Error inserting content set "${example.title}":`, contentError);
        errorCount++;
        continue;
      }
      
      // Get category ID
      const categoryId = categoryMap[example.category];
      if (!categoryId) {
        console.error(`Category not found for "${example.category}"`);
        errorCount++;
        continue;
      }
      
      // Associate with category
      const { error: associationError } = await supabase
        .from('content_set_categories')
        .insert({
          content_set_id: contentSet[0].id,
          category_id: categoryId
        });
        
      if (associationError) {
        console.error(`Error associating content set "${example.title}" with category:`, associationError);
        errorCount++;
        continue;
      }
      
      console.log(`Successfully integrated content set: "${example.title}"`);
      successCount++;
    } catch (error) {
      console.error(`Unexpected error processing content set "${example.title}":`, error);
      errorCount++;
    }
  }
  
  console.log('Content integration complete!');
  console.log(`Successfully integrated ${successCount} content sets`);
  if (errorCount > 0) {
    console.log(`Failed to integrate ${errorCount} content sets`);
  }
}

// Export the function for use in admin tools
module.exports = {
  integrateAdditionalContent
};

// If running directly (not imported), execute the integration
if (require.main === module) {
  integrateAdditionalContent()
    .then(() => console.log('Integration script completed'))
    .catch(err => console.error('Integration script failed:', err));
}
