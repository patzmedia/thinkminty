"""
Mindful Moments content sets for ThinkMinty
Category: Mindful Moments (Peace, Gratitude)
"""

# Story/Parable
mindful_moments_story = {
    "title": "The Mountain Stream",
    "short_form": """
Hiking through a forest, Maya paused beside a mountain stream. The water flowed effortlessly around rocks, under fallen logs, and through narrow passages. She noticed how the stream never fought against obstacles but simply found another path forward. "The water doesn't struggle or complain," she thought. "It simply accepts what is and continues its journey." In that moment, Maya realized she had been resisting life's challenges rather than flowing with them. She took a deep breath, letting go of her resistance, and continued her hike with a lighter heart.
""",
    "long_form": """
The morning mist still clung to the trees as Maya made her way along the forest trail. She had started her hike before dawn, hoping to clear her mind of the worries that had been plaguing her for weeks—the upcoming job interview, her mother's health concerns, the unresolved tension with her sister.

After an hour of steady climbing, Maya paused beside a mountain stream that ran parallel to the trail. She sat on a moss-covered rock, watching as the crystal-clear water flowed down the mountainside. The stream moved with such grace and ease, flowing effortlessly around rocks, under fallen logs, and through narrow passages between boulders.

What struck Maya most was how the water never seemed to fight against the obstacles in its path. When faced with a rock, it didn't crash against it in frustration or stop flowing altogether. Instead, it simply found another path forward—around the sides, occasionally over the top, sometimes creating new channels underneath.

"The water doesn't struggle or complain," she thought. "It simply accepts what is and continues its journey."

As she sat in quiet observation, Maya began to see a reflection of her own life in the stream's journey. How often had she resisted the natural flow of life? How much energy had she wasted fighting against circumstances she couldn't change, rather than adapting and finding a new path forward?

Her upcoming job interview wasn't an obstacle to overcome but an opportunity to explore. Her mother's health concerns weren't a problem to solve but a reminder to cherish their time together. The tension with her sister wasn't a battle to win but a chance to practice compassion.

Maya dipped her fingers into the cool water, feeling its gentle but persistent movement. She took a deep breath, consciously releasing the tension she'd been carrying in her shoulders and chest. With each exhale, she let go of her resistance to life as it was unfolding.

When she finally stood to continue her hike, Maya felt lighter, more fluid in her movements. Like the stream, she would flow with life rather than against it, finding her way forward with grace and acceptance.
""",
    "quote": "Life is a series of natural and spontaneous changes. Don't resist them; that only creates sorrow. Let reality be reality. Let things flow naturally forward in whatever way they like.",
    "quote_author": "Lao Tzu",
    "tags": ["Peace", "Acceptance", "Nature", "Mindfulness", "Flow"]
}

# Practical Tip
mindful_moments_tip = {
    "title": "The Five Senses Mindfulness Practice",
    "short_form": """
When feeling overwhelmed, try this simple mindfulness exercise: Pause and notice five things you can see, four things you can touch, three things you can hear, two things you can smell, and one thing you can taste. This "5-4-3-2-1" technique grounds you in the present moment by engaging all your senses. It shifts your attention away from racing thoughts and into your immediate experience. Practice this for just one minute whenever you need to center yourself, whether during a busy workday, in a moment of stress, or as part of your daily routine.
""",
    "long_form": """
In our fast-paced world, the mind often races ahead, planning, worrying, or dwelling on the past. Mindfulness—the practice of bringing awareness to the present moment—offers a powerful antidote to this mental chatter. One particularly effective technique is the "5-4-3-2-1" sensory grounding exercise, which engages all five senses to anchor you firmly in the here and now.

Here's how to practice this simple yet powerful mindfulness technique:

First, find a comfortable position, either seated or standing. Take a few deep breaths to begin settling your mind. Then, move through each of your senses deliberately and with full attention:

5 - SEE: Look around and notice five things you can see. Choose objects you might not normally pay attention to—perhaps the pattern on a ceiling tile, the way light reflects off a surface, or the exact shade of green in a nearby plant. Name each item silently or aloud, noting its colors, shapes, and textures.

4 - TOUCH: Become aware of four things you can physically feel. This might be the texture of your clothing against your skin, the temperature of the air on your face, the pressure of your feet against the floor, or the weight of a watch on your wrist. Spend a moment truly experiencing each sensation.

3 - HEAR: Listen for three distinct sounds. Perhaps the hum of electronics, distant conversations, the rustle of leaves outside, or even the sound of your own breathing. Try to distinguish between sounds in the foreground and background, noting their qualities and rhythms.

2 - SMELL: Identify two things you can smell. If smells aren't immediately obvious, you might move to another location or bring something to your nose—perhaps a cup of coffee, a plant, or even your own skin. If you can't smell anything, recall two of your favorite scents and imagine them vividly.

1 - TASTE: Finally, notice one thing you can taste. This might be the lingering flavor of your last meal, the taste of your mouth itself, or even just the sensation of your tongue against your teeth. If there's no distinct taste, you could take a small sip of water or tea to create this sensory experience.

The beauty of this practice lies in its versatility and accessibility. You can perform it anywhere—at your desk, while waiting in line, during a stressful meeting, or before bed. It requires no special equipment or preparation, just your willingness to pay attention.

For enhanced benefits, consider these variations:

- Speed: You can move through the exercise quickly (in under a minute) when you need immediate grounding, or slowly (over 5-10 minutes) for deeper relaxation.
- Focus: If one particular sense feels especially grounding for you, spend more time with that portion of the exercise.
- Journaling: After completing the practice, jot down what you noticed, particularly any surprising observations.
- Gratitude: Add a layer of appreciation by expressing gratitude for each sensory experience.

Regular practice of the 5-4-3-2-1 technique strengthens your ability to return to the present moment, reducing anxiety and enhancing your capacity to engage fully with life as it unfolds. Over time, you may find yourself spontaneously noticing sensory details throughout your day, living with greater awareness and appreciation for the richness of each moment.
""",
    "quote": "The present moment is the only time over which we have dominion.",
    "quote_author": "Thich Nhat Hanh",
    "tags": ["Mindfulness", "Practical Tip", "Breathing", "Stress Reduction", "Present Moment"]
}

# Reflection
mindful_moments_reflection = {
    "title": "The Space Between Thoughts",
    "short_form": """
Have you ever noticed the brief pause between your thoughts? That momentary stillness contains immense power. It's in this space that we can choose our response rather than react automatically. Throughout your day, try to become aware of these small gaps—after taking a breath, before responding to a question, or during a moment of transition. These tiny spaces of awareness are doorways to presence. When you notice them, you step out of the stream of constant thinking and into the fullness of the present moment, where peace naturally resides.
""",
    "long_form": """
In the constant flow of our mental activity, there exists a phenomenon that often goes unnoticed yet holds transformative potential: the space between our thoughts. These momentary gaps in our thinking—these intervals of pure awareness—are like small windows opening onto a vast sky of consciousness that exists beyond our habitual thought patterns.

Most of us live our lives completely identified with the content of our thoughts, carried along by their current like leaves on a stream. We think about what happened yesterday, what might happen tomorrow, what we should have said, what we need to do. This endless narrative creates the impression of a solid, continuous "self" moving through time. But when we pay close attention, we discover that this apparent continuity is actually composed of discrete thoughts with small spaces between them.

These spaces—these moments of non-thinking—are not empty or void. Rather, they are filled with alert presence, with the simple awareness of being. In these gaps, we are not defined by our stories, our worries, or our plans. We are simply here, now, aware.

The significance of these spaces extends beyond mere philosophical interest. Neuroscience suggests that the brief pauses between thoughts may represent moments when different neural networks in our brain are transitioning, allowing for new connections and patterns to form. These gaps might be the very birthplace of creativity, insight, and fresh perspective.

More practically, becoming aware of the space between thoughts offers us a crucial point of choice. When we notice the gap before a habitual reaction arises, we gain the freedom to respond differently. For instance, when someone says something hurtful, there's a tiny space before our automatic defensive reaction kicks in. If we can catch that space, we can choose a more thoughtful response rather than being driven by conditioning.

How might we become more aware of these precious intervals of stillness? Here are some approaches to explore:

During meditation, rather than focusing exclusively on your breath or a mantra, occasionally shift your attention to the space between thoughts. Don't try to create this space—simply notice when it naturally occurs.

Throughout your day, look for transition moments: the pause after you complete one task before beginning another, the moment between an inhale and exhale, the brief silence after someone asks you a question. In these transitions, you might catch a glimpse of the spaciousness that underlies all mental activity.

When you find yourself caught in repetitive thinking or strong emotion, ask yourself: "What is here in the space between my thoughts?" This question itself often creates a momentary gap in which you can experience pure awareness.

Practice listening not just to the words someone is saying but to the silence between their words. This same quality of attention can then be turned toward your own inner experience.

As you develop sensitivity to these gaps in the stream of thinking, you may discover something remarkable: these spaces can expand. What begins as a momentary glimpse can develop into a more sustained awareness that coexists with thinking without being limited by it.

The space between thoughts is not something we need to create or achieve—it's already here, a fundamental aspect of our consciousness. By simply noticing these gaps, we begin to disidentify from the constant narrative of our minds and recognize the deeper dimension of awareness that is our true nature. In this recognition lies the possibility of living with greater presence, peace, and freedom.
""",
    "quote": "Between stimulus and response there is a space. In that space is our power to choose our response. In our response lies our growth and our freedom.",
    "quote_author": "Viktor Frankl",
    "tags": ["Awareness", "Meditation", "Consciousness", "Peace", "Reflection"]
}

# Affirmation
mindful_moments_affirmation = {
    "title": "Present in This Moment",
    "short_form": """
I am fully present in this moment. My breath anchors me to the here and now. I release thoughts of the past and future, embracing the peace that exists in this present moment. My awareness rests in the now, where life actually happens. In this moment, I am exactly where I need to be. I notice the sensations in my body, the sounds around me, and the rhythm of my breath—all reminding me that this moment is all there truly is. I am here, I am now, I am present.
""",
    "long_form": """
I am fully present in this moment.

As I take a deep breath in, I feel the air filling my lungs, noticing the slight rise of my chest and the subtle expansion of my abdomen. As I exhale, I feel a gentle release, a letting go. My breath serves as an anchor, tethering me to the here and now, this precise moment in time that will never exist again.

I consciously release thoughts of the past—the conversations I've replayed, the regrets I've carried, the memories both sweet and painful. The past has already unfolded; it has shaped me but does not define me. I acknowledge its lessons with gratitude and then gently let it go.

Similarly, I release my preoccupation with the future—the plans, the worries, the expectations. The future is yet to be written, and while I may set intentions for it, I recognize that this moment right now is where my power truly lies. The future will arrive in its own time, and I will meet it when it becomes the present.

I embrace the profound peace that exists only in this present moment. This peace is always available to me when I step out of the stream of constant thinking and into pure awareness. It is not something I need to create or achieve—it is already here, waiting to be recognized beneath the surface of my busy mind.

My awareness rests in the now, where life actually happens. Not in my thoughts about life, but in the direct, unfiltered experience of being alive. The subtle sensations in my fingertips, the play of light and shadow in the room, the symphony of sounds both near and distant—these are the texture of reality, available only when I am present.

In this moment, I am exactly where I need to be. There is nowhere else to go, nothing else to do, no one else to be. This recognition brings a deep acceptance of what is, a surrender to the perfection of the present, however it appears.

I notice the sensations in my body—areas of tension and ease, warmth and coolness, heaviness and lightness. Each sensation arises in my awareness, exists for a time, and then dissolves. I don't need to judge these sensations or try to change them; I simply witness them with curious attention.

I hear the sounds around me—some pleasant, some neutral, some perhaps jarring. Rather than labeling these sounds as good or bad, I receive them as pure auditory experience, noticing their pitch, volume, and duration. Each sound emerges from silence and returns to silence, like waves on the ocean of awareness.

The rhythm of my breath continues its steady cadence, reminding me that this moment is all there truly is. The past exists only as memory, the future only as imagination. This breath, this heartbeat, this awareness—this is reality.

I am here. I am now. I am present.

In this presence, I find my true nature—not as a collection of thoughts, emotions, and stories, but as the aware space in which all experience arises. This awareness is boundless, peaceful, and complete. It needs nothing, lacks nothing, seeks nothing.

From this ground of present-moment awareness, I move through my day with greater clarity, purpose, and joy. Each moment becomes an opportunity to be fully alive, fully conscious, fully here.

I am present, and in this presence, I am whole.
""",
    "quote": "The present moment is filled with joy and happiness. If you are attentive, you will see it.",
    "quote<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>