import pandas as pd
import sys
import os

# Add the content_sets directory to the Python path
sys.path.append('/home/ubuntu/thinkminty/content_sets')

# Import all content modules
from mindful_moments_content import *
from resilience_recharge_content import *
from joyful_living_content import *
from purposeful_path_content import *
from connection_kindness_content import *
from calm_comfort_content import *

# Create a list to hold all content sets
content_sets = []

# Mindful Moments content
content_sets.append({
    'Category': 'Mindful Moments',
    'Content Type': 'Story/Parable',
    'Title': mindful_moments_story['title'],
    'Short Form': mindful_moments_story['short_form'].strip(),
    'Long Form': mindful_moments_story['long_form'].strip(),
    'Quote': mindful_moments_story['quote'],
    'Quote Author': mindful_moments_story['quote_author'],
    'Tags': ', '.join(mindful_moments_story['tags'])
})

content_sets.append({
    'Category': 'Mindful Moments',
    'Content Type': 'Practical Tip',
    'Title': mindful_moments_tip['title'],
    'Short Form': mindful_moments_tip['short_form'].strip(),
    'Long Form': mindful_moments_tip['long_form'].strip(),
    'Quote': mindful_moments_tip['quote'],
    'Quote Author': mindful_moments_tip['quote_author'],
    'Tags': ', '.join(mindful_moments_tip['tags'])
})

content_sets.append({
    'Category': 'Mindful Moments',
    'Content Type': 'Reflection',
    'Title': mindful_moments_reflection['title'],
    'Short Form': mindful_moments_reflection['short_form'].strip(),
    'Long Form': mindful_moments_reflection['long_form'].strip(),
    'Quote': mindful_moments_reflection['quote'],
    'Quote Author': mindful_moments_reflection['quote_author'],
    'Tags': ', '.join(mindful_moments_reflection['tags'])
})

content_sets.append({
    'Category': 'Mindful Moments',
    'Content Type': 'Affirmation',
    'Title': mindful_moments_affirmation['title'],
    'Short Form': mindful_moments_affirmation['short_form'].strip(),
    'Long Form': mindful_moments_affirmation['long_form'].strip(),
    'Quote': mindful_moments_affirmation['quote'],
    'Quote Author': mindful_moments_affirmation['quote_author'],
    'Tags': ', '.join(mindful_moments_affirmation['tags'])
})

# Resilience Recharge content
content_sets.append({
    'Category': 'Resilience Recharge',
    'Content Type': 'Story/Parable',
    'Title': resilience_recharge_story['title'],
    'Short Form': resilience_recharge_story['short_form'].strip(),
    'Long Form': resilience_recharge_story['long_form'].strip(),
    'Quote': resilience_recharge_story['quote'],
    'Quote Author': resilience_recharge_story['quote_author'],
    'Tags': ', '.join(resilience_recharge_story['tags'])
})

content_sets.append({
    'Category': 'Resilience Recharge',
    'Content Type': 'Practical Tip',
    'Title': resilience_recharge_tip['title'],
    'Short Form': resilience_recharge_tip['short_form'].strip(),
    'Long Form': resilience_recharge_tip['long_form'].strip(),
    'Quote': resilience_recharge_tip['quote'],
    'Quote Author': resilience_recharge_tip['quote_author'],
    'Tags': ', '.join(resilience_recharge_tip['tags'])
})

content_sets.append({
    'Category': 'Resilience Recharge',
    'Content Type': 'Reflection',
    'Title': resilience_recharge_reflection['title'],
    'Short Form': resilience_recharge_reflection['short_form'].strip(),
    'Long Form': resilience_recharge_reflection['long_form'].strip(),
    'Quote': resilience_recharge_reflection['quote'],
    'Quote Author': resilience_recharge_reflection['quote_author'],
    'Tags': ', '.join(resilience_recharge_reflection['tags'])
})

content_sets.append({
    'Category': 'Resilience Recharge',
    'Content Type': 'Affirmation',
    'Title': resilience_recharge_affirmation['title'],
    'Short Form': resilience_recharge_affirmation['short_form'].strip(),
    'Long Form': resilience_recharge_affirmation['long_form'].strip(),
    'Quote': resilience_recharge_affirmation['quote'],
    'Quote Author': resilience_recharge_affirmation['quote_author'],
    'Tags': ', '.join(resilience_recharge_affirmation['tags'])
})

# Joyful Living content
content_sets.append({
    'Category': 'Joyful Living',
    'Content Type': 'Story/Parable',
    'Title': joyful_living_story['title'],
    'Short Form': joyful_living_story['short_form'].strip(),
    'Long Form': joyful_living_story['long_form'].strip(),
    'Quote': joyful_living_story['quote'],
    'Quote Author': joyful_living_story['quote_author'],
    'Tags': ', '.join(joyful_living_story['tags'])
})

content_sets.append({
    'Category': 'Joyful Living',
    'Content Type': 'Practical Tip',
    'Title': joyful_living_tip['title'],
    'Short Form': joyful_living_tip['short_form'].strip(),
    'Long Form': joyful_living_tip['long_form'].strip(),
    'Quote': joyful_living_tip['quote'],
    'Quote Author': joyful_living_tip['quote_author'],
    'Tags': ', '.join(joyful_living_tip['tags'])
})

content_sets.append({
    'Category': 'Joyful Living',
    'Content Type': 'Reflection',
    'Title': joyful_living_reflection['title'],
    'Short Form': joyful_living_reflection['short_form'].strip(),
    'Long Form': joyful_living_reflection['long_form'].strip(),
    'Quote': joyful_living_reflection['quote'],
    'Quote Author': joyful_living_reflection['quote_author'],
    'Tags': ', '.join(joyful_living_reflection['tags'])
})

content_sets.append({
    'Category': 'Joyful Living',
    'Content Type': 'Affirmation',
    'Title': joyful_living_affirmation['title'],
    'Short Form': joyful_living_affirmation['short_form'].strip(),
    'Long Form': joyful_living_affirmation['long_form'].strip(),
    'Quote': joyful_living_affirmation['quote'],
    'Quote Author': joyful_living_affirmation['quote_author'],
    'Tags': ', '.join(joyful_living_affirmation['tags'])
})

# Purposeful Path content
content_sets.append({
    'Category': 'Purposeful Path',
    'Content Type': 'Story/Parable',
    'Title': purposeful_path_story['title'],
    'Short Form': purposeful_path_story['short_form'].strip(),
    'Long Form': purposeful_path_story['long_form'].strip(),
    'Quote': purposeful_path_story['quote'],
    'Quote Author': purposeful_path_story['quote_author'],
    'Tags': ', '.join(purposeful_path_story['tags'])
})

content_sets.append({
    'Category': 'Purposeful Path',
    'Content Type': 'Practical Tip',
    'Title': purposeful_path_tip['title'],
    'Short Form': purposeful_path_tip['short_form'].strip(),
    'Long Form': purposeful_path_tip['long_form'].strip(),
    'Quote': purposeful_path_tip['quote'],
    'Quote Author': purposeful_path_tip['quote_author'],
    'Tags': ', '.join(purposeful_path_tip['tags'])
})

content_sets.append({
    'Category': 'Purposeful Path',
    'Content Type': 'Reflection',
    'Title': purposeful_path_reflection['title'],
    'Short Form': purposeful_path_reflection['short_form'].strip(),
    'Long Form': purposeful_path_reflection['long_form'].strip(),
    'Quote': purposeful_path_reflection['quote'],
    'Quote Author': purposeful_path_reflection['quote_author'],
    'Tags': ', '.join(purposeful_path_reflection['tags'])
})

content_sets.append({
    'Category': 'Purposeful Path',
    'Content Type': 'Affirmation',
    'Title': purposeful_path_affirmation['title'],
    'Short Form': purposeful_path_affirmation['short_form'].strip(),
    'Long Form': purposeful_path_affirmation['long_form'].strip(),
    'Quote': purposeful_path_affirmation['quote'],
    'Quote Author': purposeful_path_affirmation['quote_author'],
    'Tags': ', '.join(purposeful_path_affirmation['tags'])
})

# Connection & Kindness content
content_sets.append({
    'Category': 'Connection & Kindness',
    'Content Type': 'Story/Parable',
    'Title': connection_kindness_story['title'],
    'Short Form': connection_kindness_story['short_form'].strip(),
    'Long Form': connection_kindness_story['long_form'].strip(),
    'Quote': connection_kindness_story['quote'],
    'Quote Author': connection_kindness_story['quote_author'],
    'Tags': ', '.join(connection_kindness_story['tags'])
})

content_sets.append({
    'Category': 'Connection & Kindness',
    'Content Type': 'Practical Tip',
    'Title': connection_kindness_tip['title'],
    'Short Form': connection_kindness_tip['short_form'].strip(),
    'Long Form': connection_kindness_tip['long_form'].strip(),
    'Quote': connection_kindness_tip['quote'],
    'Quote Author': connection_kindness_tip['quote_author'],
    'Tags': ', '.join(connection_kindness_tip['tags'])
})

content_sets.append({
    'Category': 'Connection & Kindness',
    'Content Type': 'Reflection',
    'Title': connection_kindness_reflection['title'],
    'Short Form': connection_kindness_reflection['short_form'].strip(),
    'Long Form': connection_kindness_reflection['long_form'].strip(),
    'Quote': connection_kindness_reflection['quote'],
    'Quote Author': connection_kindness_reflection['quote_author'],
    'Tags': ', '.join(connection_kindness_reflection['tags'])
})

content_sets.append({
    'Category': 'Connection & Kindness',
    'Content Type': 'Affirmation',
    'Title': connection_kindness_affirmation['title'],
    'Short Form': connection_kindness_affirmation['short_form'].strip(),
    'Long Form': connection_kindness_affirmation['long_form'].strip(),
    'Quote': connection_kindness_affirmation['quote'],
    'Quote Author': connection_kindness_affirmation['quote_author'],
    'Tags': ', '.join(connection_kindness_affirmation['tags'])
})

# Calm & Comfort content
content_sets.append({
    'Category': 'Calm & Comfort',
    'Content Type': 'Story/Parable',
    'Title': calm_comfort_story['title'],
    'Short Form': calm_comfort_story['short_form'].strip(),
    'Long Form': calm_comfort_story['long_form'].strip(),
    'Quote': calm_comfort_story['quote'],
    'Quote Author': calm_comfort_story['quote_author'],
    'Tags': ', '.join(calm_comfort_story['tags'])
})

content_sets.append({
    'Category': 'Calm & Comfort',
    'Content Type': 'Practical Tip',
    'Title': calm_comfort_tip['title'],
    'Short Form': calm_comfort_tip['short_form'].strip(),
    'Long Form': calm_comfort_tip['long_form'].strip(),
    'Quote': calm_comfort_tip['quote'],
    'Quote Author': calm_comfort_tip['quote_author'],
    'Tags': ', '.join(calm_comfort_tip['tags'])
})

content_sets.append({
    'Category': 'Calm & Comfort',
    'Content Type': 'Reflection',
    'Title': calm_comfort_reflection['title'],
    'Short Form': calm_comfort_reflection['short_form'].strip(),
    'Long Form': calm_comfort_reflection['long_form'].strip(),
    'Quote': calm_comfort_reflection['quote'],
    'Quote Author': calm_comfort_reflection['quote_author'],
    'Tags': ', '.join(calm_comfort_reflection['tags'])
})

content_sets.append({
    'Category': 'Calm & Comfort',
    'Content Type': 'Affirmation',
    'Title': calm_comfort_affirmation['title'],
    'Short Form': calm_comfort_affirmation['short_form'].strip(),
    'Long Form': calm_comfort_affirmation['long_form'].strip(),
    'Quote': calm_comfort_affirmation['quote'],
    'Quote Author': calm_comfort_affirmation['quote_author'],
    'Tags': ', '.join(calm_comfort_affirmation['tags'])
})

# Create a DataFrame from the content sets
df = pd.DataFrame(content_sets)

# Create a directory for the output if it doesn't exist
os.makedirs('/home/ubuntu/thinkminty/output', exist_ok=True)

# Save to Excel
excel_path = '/home/ubuntu/thinkminty/output/ThinkMinty_Content_Sets.xlsx'
df.to_excel(excel_path, index=False, engine='openpyxl')

print(f"Excel file created successfully at: {excel_path}")

# Function to sanitize sheet names for Excel
def sanitize_sheet_name(name):
    # Replace invalid characters with underscores
    invalid_chars = ['/', '\\', '?', '*', ':', '[', ']']
    for char in invalid_chars:
        name = name.replace(char, '_')
    return name[:31]  # Excel sheet names limited to 31 chars

# Create a more readable version with separate sheets for each category
with pd.ExcelWriter('/home/ubuntu/thinkminty/output/ThinkMinty_Content_Sets_By_Category.xlsx', engine='openpyxl') as writer:
    # First sheet with all content
    df.to_excel(writer, sheet_name='All Content', index=False)
    
    # Separate sheets for each category
    for category in df['Category'].unique():
        category_df = df[df['Category'] == category]
        sheet_name = sanitize_sheet_name(category)
        category_df.to_excel(writer, sheet_name=sheet_name, index=False)
    
    # Sheet organized by content type
    for content_type in df['Content Type'].unique():
        content_type_df = df[df['Content Type'] == content_type]
        sheet_name = sanitize_sheet_name(content_type)
        content_type_df.to_excel(writer, sheet_name=sheet_name, index=False)

print(f"Categorized Excel file created successfully at: /home/ubuntu/thinkminty/output/ThinkMinty_Content_Sets_By_Category.xlsx")
