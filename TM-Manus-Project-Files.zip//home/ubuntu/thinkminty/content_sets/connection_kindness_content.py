"""
Connection & Kindness content sets for ThinkMinty
Category: Connection & Kindness (Love, Gratitude)
"""

# Story/Parable
connection_kindness_story = {
    "title": "The Invisible Threads",
    "short_form": """
In a busy city neighborhood, Ms. Chen owned a small bakery where she gave day-old bread to anyone in need. She never mentioned these gifts, and most recipients never knew their benefactor. When Ms. Chen fell ill, her daughter was shocked to find their small apartment filled with visitors—the mail carrier bringing homemade soup, a former homeless man offering to clean, a teenager playing violin by her bedside. "I don't understand," the daughter whispered to a visitor. "How do you all know my mother?" The woman smiled. "Your mother tied invisible threads of kindness throughout this community. We're simply following them back to their source." Our acts of kindness create connections we cannot see until they return to us when we need them most.
""",
    "long_form": """
In the heart of a bustling city neighborhood, where most people moved too quickly to make eye contact, stood a modest bakery owned by Ms. Chen. The shop itself was unremarkable—a small storefront with a faded awning and windows that steamed up in the early morning as fresh bread baked inside. What made the bakery extraordinary wasn't visible from the outside.

Ms. Chen, a widow in her sixties who had immigrated from Taiwan decades earlier, operated her business with a quiet ritual unknown to most of her regular customers. Each evening, after closing, she carefully wrapped the day's unsold bread and pastries. Some packages she placed in a clean box by the back door, where several people experiencing homelessness knew they could find a dignified meal without having to ask. Other packages she delivered herself on her walk home—to an elderly neighbor whose arthritis made cooking difficult, to a young single mother working two jobs, to a family she knew was struggling after a layoff.

Ms. Chen never mentioned these gifts. She left them without fanfare, sometimes with a simple note saying, "Enjoy with tea," written in her careful, slightly imperfect English. She never sought acknowledgment or thanks, and many recipients never knew the source of these unexpected offerings. When asked why she gave away food she could have sold the next day at a discount, she would simply shrug and say, "Good bread should feed someone, not a trash can."

This pattern continued for years, becoming so much a part of Ms. Chen's routine that she gave it little thought. The neighborhood changed around her—new businesses opened, old ones closed, families moved in and out—but the bakery remained, as did Ms. Chen's quiet generosity.

Then, one winter, Ms. Chen fell ill. What began as a seemingly minor cold developed into pneumonia, and her daughter Lin, who lived in another state, received a call from the hospital. Lin took emergency leave from her job and arrived to find her mother weak but stable. The doctors recommended a week of hospital care followed by several weeks of home recovery.

Lin stayed in her mother's small apartment above the bakery, planning to care for her when she was discharged. She placed a sign on the bakery door explaining the temporary closure due to family illness, adding her mother's hospital room number in case anyone wanted to send well wishes.

What happened next astonished her.

The first visitor arrived that very afternoon—the mail carrier, a tall woman with silver-streaked hair, bringing homemade soup in a carefully packed container. "Your mother always has a cup of tea ready when I deliver on cold days," she explained. "Please tell her Maria is thinking of her."

The next morning, a middle-aged man Lin didn't recognize appeared with a handmade card. He introduced himself as Michael, explaining that he had been homeless three years ago when Ms. Chen's bread packages helped him survive the winter. Now employed and housed, he offered to clean the apartment or run errands while Lin cared for her mother.

Throughout the day, more visitors came—a teenager with a violin who asked if he could play for Ms. Chen because "she let me practice in the bakery when my roommates complained about the noise"; an elderly couple bringing a hand-knitted blanket; a young mother with twin toddlers who insisted on leaving a casserole "because your mother saved me from hunger when my benefits were delayed."

By evening, the hospital room was filled with flowers, cards, small gifts, and a steady stream of visitors from all walks of life. Ms. Chen, though weak, smiled at each person, often exchanging just a few words or a gentle squeeze of hands.

Lin was overwhelmed. During a quiet moment when her mother was sleeping and the room temporarily empty of visitors, she turned to a woman who had just arrived with a thermos of hot tea.

"I don't understand," Lin whispered. "I've visited my mother twice a year for the past decade, and she never mentioned having so many friends. How do you all know her?"

The woman, arranging teacups on the small hospital tray, smiled. "Most of us wouldn't say we know your mother well in the usual sense. She's quite private, speaks little about herself." She paused, considering how to explain. "It's more that your mother tied invisible threads of kindness throughout this community. We're simply following them back to their source."

Over the following weeks, as Ms. Chen recovered first in the hospital and then at home, the flow of visitors and help continued. People Lin had never met volunteered to mind the bakery for a few hours so she could rest. Others brought meals, ran errands, or simply sat with Ms. Chen, reading to her or sharing neighborhood news.

Lin, who had always seen her mother as somewhat isolated in this big city—a hardworking immigrant who kept to herself—began to understand that her mother was actually at the center of an invisible web of connection. Not connection based on social interaction or shared interests or even regular conversation, but connection forged through simple acts of care that required no recognition or return.

The night before the bakery was set to reopen, with Ms. Chen still recovering but Lin now trained to handle the morning baking, mother and daughter sat together drinking tea.

"I had no idea you had touched so many lives," Lin said. "All these people coming to help—it's like you've been making deposits in some kind of kindness bank all these years without ever expecting to make a withdrawal."

Ms. Chen smiled, her face still thin from her illness but her eyes bright. "Not a bank," she corrected gently. "Nothing so calculated. I never gave to receive."

"Then why?" Lin asked.

Ms. Chen considered this, looking out the window at the city lights. "When I came to this country, I was very alone. My English was poor. I knew no one. One day, I was lost, trying to find the immigration office to complete some paperwork. A stranger not only gave directions but walked me there, missing his own bus to make sure I arrived. I never saw him again, never knew his name. But I never forgot how that small kindness made me feel less alone in this big place."

She turned back to her daughter. "We are all connected, even when we cannot see the threads between us. Each kindness strengthens these threads. I didn't need to know where they led. It was enough to know they existed."

Lin thought about the invisible web her mother had created—threads connecting the mail carrier to the former homeless man to the young musician to dozens of others whose lives had been touched by small, consistent acts of care. Acts that required no recognition, no direct relationship, no expectation of return, yet somehow created a community strong enough to hold her mother when she needed support.

When the bakery reopened the next day, Lin worked alongside her mother, learning not just how to knead dough and time the baking, but also watching as Ms. Chen set aside certain loaves and pastries as the day progressed. That evening, Lin joined her mother in wrapping these items, adding her own notes alongside her mother's.

As they walked together to deliver some of the packages, Lin realized that the true legacy her mother had created wasn't the bakery itself, but this invisible network of care—a testament to how one person's consistent kindness, offered without expectation, could weave together an entire community of strangers into something resembling family.

Our acts of kindness, like Ms. Chen's bread, create connections we cannot see until they return to us when we need them most—not as debts to be repaid, but as threads in a tapestry of human care that holds us all.
""",
    "quote": "I've learned that people will forget what you said, people will forget what you did, but people will never forget how you made them feel.",
    "quote_author": "Maya Angelou",
    "tags": ["Connection", "Kindness", "Community", "Generosity", "Story"]
}

# Practical Tip
connection_kindness_tip = {
    "title": "The Two-Minute Connection Practice",
    "short_form": """
Try this simple practice to deepen connection in your daily interactions: For two minutes, give someone your complete, undivided attention. Put away your phone, turn away from screens, and focus fully on the person speaking. Listen not just to respond, but to understand—noticing their words, tone, and body language without planning what you'll say next. Ask at least one question that shows you're truly hearing them. This brief but powerful practice transforms ordinary exchanges into meaningful connections, helping others feel truly seen while also enriching your own experience of relationship.
""",
    "long_form": """
In our increasingly distracted world, genuine human connection has become both more rare and more valuable. Many of us move through our days engaged in numerous interactions that remain surface-level—conversations where we're physically present but mentally elsewhere, thinking about our to-do lists, formulating our next response, or subtly checking our devices.

The Two-Minute Connection Practice offers a simple yet powerful antidote to this disconnection. By dedicating just two minutes of complete, undivided attention to another person, we can transform ordinary exchanges into meaningful moments of connection that benefit both parties. This practice doesn't require special skills, additional time in your schedule, or particular circumstances—it simply asks you to fully show up for the interactions you're already having.

**The Science Behind the Practice**

Research in interpersonal neurobiology shows that feeling truly seen and heard by another person triggers the release of oxytocin (sometimes called the "bonding hormone") and activates the brain's reward centers. These neurochemical responses create feelings of trust, safety, and well-being. Conversely, when we sense that someone isn't fully present with us—even if they're physically there—our brains register a subtle form of social threat or rejection.

Studies of doctor-patient interactions provide compelling evidence for the power of focused attention. Researchers found that when doctors sat down, made eye contact, and gave their full attention to patients—even for just a few minutes—patients rated these doctors as more caring, more competent, and reported spending more time with them than doctors who remained standing and appeared distracted, even when the actual time spent was identical.

Similar findings appear in research on workplace relationships, romantic partnerships, and parent-child interactions. The quality of attention we bring to our connections matters far more than the quantity of time we spend.

**How to Practice the Two-Minute Connection**

The Two-Minute Connection Practice involves giving your complete, undivided attention to another person for at least two minutes. Here's how to implement it:

**1. Create a Distraction-Free Zone**

Begin by eliminating physical distractions:
- Put away your phone or turn it face-down
- Turn away from screens
- Position yourself to face the person directly
- If possible, sit or stand at the same level (rather than one person standing while the other sits)

Next, minimize internal distractions:
- Take a deep breath to center yourself
- Mentally set aside your to-do list and concerns
- Commit to being fully present for just these two minutes

**2. Practice Active Listening**

Listen not just to respond, but to understand:
- Focus on the speaker's words, tone, and body language
- Resist the urge to plan what you'll say next while they're speaking
- Notice when your mind wanders and gently bring it back to the conversation
- Allow comfortable silences rather than rushing to fill them

**3. Demonstrate Your Attention**

Show that you're fully present through:
- Appropriate eye contact (cultural norms for eye contact vary, so follow what feels comfortable while still conveying attention)
- Nodding or other small acknowledgments that you're listening
- Responsive facial expressions that naturally reflect your engagement
- An open posture (uncrossed arms, facing the person)

**4. Ask at Least One Question That Shows You're Truly Hearing**

Deepen the connection by asking a question that:
- Relates directly to what the person has just shared
- Invites elaboration rather than a yes/no response
- Shows genuine curiosity about their experience
- Doesn't immediately shift the focus to yourself or another topic

For example, instead of responding to someone's story about a challenging work situation with "I had something similar happen last year," you might ask, "How did that impact the way you approach your work now?"

**5. Express Appreciation**

As the interaction concludes, express appreciation for the exchange in a way that feels authentic:
- Thank them for sharing their thoughts, story, or perspective
- Acknowledge something specific you valued about the conversation
- Express genuine good wishes if appropriate

**Implementing the Practice in Different Contexts**

The beauty of the Two-Minute Connection Practice is its versatility. It can be adapted to virtually any interpersonal context:

**With Family Members**: Practice during dinner conversations, when greeting each other after work/school, or before bedtime routines. Even with people we see daily, the quality of our attention can transform routine interactions into moments of genuine connection.

**With Colleagues**: Implement during one-on-one meetings, when a coworker stops by your desk, or at the beginning of team gatherings. Research shows that feeling truly heard at work significantly increases engagement, creativity, and collaboration.

**With Service Providers**: Practice with cashiers, servers, delivery people, and others you encounter briefly but regularly. These small moments of genuine connection can brighten someone's day and create a sense of community in everyday interactions.

**With Friends**: Dedicate the first two minutes of get-togethers to fully present connection before phones come out or group dynamics take over. This sets a tone of quality attention for the entire interaction.

**With Strangers**: When appropriate, practice with people you meet in public spaces, waiting rooms, or community events. These brief connections with strangers have been shown to significantly boost mood and sense of belonging.

**Overcoming Common Challenges**

As simple as this practice sounds, it can be surprisingly challenging in our distraction-filled world. Here are strategies for addressing common obstacles:

**Time Pressure**: If you feel too busy for this practice, remember that it requires no additional time—just a different quality of attention during interactions you're already having. In fact, fully present conversations are often more efficient because they reduce misunderstandings and need for repetition.

**Discomfort with Attention**: If giving or receiving focused attention feels uncomforta<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>