"""
Purposeful Path content sets for ThinkMinty
Category: Purposeful Path (Inspiration, Hope)
"""

# Story/Parable
purposeful_path_story = {
    "title": "The Lighthouse Keeper",
    "short_form": """
For fifty years, old Samuel maintained a lighthouse on a remote island. Every night, without fail, he polished the lens and lit the lamp. One evening, a visitor asked if he ever felt his work was pointless, as ships now had modern navigation systems. "I've kept this light for half a century," Samuel replied, "and in that time, I've received only three thank-you letters from ships that avoided the rocks." He smiled. "But I don't keep the light burning for the thanks. I keep it burning for the ships I'll never know I saved." True purpose often lies not in recognition or reward, but in the quiet knowledge that our actions matter, even when their impact remains unseen.
""",
    "long_form": """
The island of Thornwick Point jutted from the sea like a defiant fist, its jagged rocks having claimed countless vessels over the centuries. Perched atop its highest cliff stood a lighthouse that had guided ships safely through these treacherous waters for generations.

For the past fifty years, this lighthouse had been maintained by a man named Samuel Thorne. Now in his seventies, with a beard as white as sea foam and skin weathered by decades of salt air, Samuel was as much a fixture of Thornwick Point as the lighthouse itself.

Every evening, without fail, Samuel climbed the one hundred and eight spiral steps to the lantern room. There, he would meticulously clean the Fresnel lens until it gleamed, check the mechanisms, and light the lamp that would shine its warning beacon across twenty miles of dark water. He kept detailed logs of weather conditions, passing ships, and maintenance tasks in a neat, measured hand.

The island received few visitors, but occasionally supply boats would bring provisions along with the rare tourist curious about this remote outpost. On one such evening in late autumn, as Samuel was preparing for his nightly ritual, a young woman from the mainland arrived on the supply boat.

She introduced herself as Dr. Eleanor Wells, a maritime historian documenting the remaining manned lighthouses along the coast. Samuel, though not usually one for company, invited her to join him on his rounds, quietly pleased to share his life's work with someone who might appreciate it.

As they climbed the tower stairs, Eleanor asked questions about the lighthouse's history and Samuel's experiences. He answered with the precision and economy of words that comes from years of solitude, but there was pride in his voice when he spoke of the light's reach and reliability.

In the lantern room, Eleanor watched as Samuel went through his evening routine—the careful cleaning, the methodical checks, the moment of quiet satisfaction as the light blazed to life and began its rhythmic sweeping across the darkening sea.

"It's beautiful," she said, gazing out at the panoramic view of ocean meeting sky in a watercolor blend of indigo and fading amber. "But I have to ask—don't you ever feel your work has become... well, somewhat obsolete?"

Samuel paused in his work, looking at her with eyes the pale blue of shallow water over sand.

"What do you mean?" he asked, though his tone suggested he understood perfectly well.

"It's just that ships today have GPS, radar, digital charts, automated navigation systems," Eleanor explained. "They don't rely on lighthouses the way they once did. The government has been automating or decommissioning most of them. Yet you're still here, doing this every night."

Samuel nodded slowly, wiping his hands on a clean cloth. He gestured for Eleanor to follow him back down to his small quarters attached to the base of the tower. There, he pulled an old wooden box from beneath his bed and placed it on the kitchen table between them.

"I've kept this light for half a century," he said, opening the box to reveal a small collection of letters, their paper yellowed with age. "And in that time, I've received exactly three thank-you letters from ships that avoided the rocks because of my light."

He selected one letter and handed it to Eleanor. It was dated nearly thirty years earlier, from the captain of a fishing vessel caught in an unexpected storm, whose navigation equipment had failed. The captain wrote of how the Thornwick light had been their only guide through "the darkest night I've ever sailed," and how all twelve crew members had made it home to their families because of it.

"Three letters in fifty years," Samuel repeated, carefully returning the precious document to its box. "But I don't keep the light burning for the thanks."

He rose and walked to the window, looking out toward the sea that had been both his home and his purpose for most of his life.

"I keep it burning for the ships I'll never know I saved," he said quietly. "For the sailors who might have perished but instead made it home, never realizing how close they came to disaster. For the vessels that adjusted their course by just a few degrees when they spotted my light, avoiding danger without ever knowing it was there."

Eleanor was silent, understanding dawning in her eyes.

"Modern navigation is a wonderful thing," Samuel continued. "But technology fails. Batteries die. Storms interfere with signals. And when everything else fails, this light will still be here, doing exactly what it has done for over a century—showing sailors the way home."

He turned back to face her, his expression serene. "My purpose isn't measured by how many people know what I do or thank me for doing it. My purpose is measured by the constancy of that light, by the reliability of its presence in both calm seas and storms."

As night deepened around them, they sat in companionable silence, the rhythmic flash of the lighthouse beam creating a gentle pulse through the windows—three seconds of brightness, twelve seconds of darkness, repeating without fail.

Before leaving the next morning, Eleanor asked Samuel if he ever regretted spending his life in such isolation, dedicated to a purpose that many would consider outdated.

Samuel smiled, the corners of his eyes crinkling like the map of his beloved coastline. "The modern world is very concerned with being seen—with recognition, with measurable impact, with leaving a visible mark," he said. "But true purpose often lies in the unseen, in the lives quietly touched, in the disasters silently averted."

He looked toward his lighthouse, standing tall against the morning sky. "I may never know the full impact of keeping this light. And that's precisely the point—I don't need to know to find meaning in the work. The meaning is in the doing itself, in the faith that even our unseen actions matter."

Years later, when Eleanor published her book on lighthouse keepers, she dedicated it to Samuel, who by then had passed away. The dedication read: "For Samuel Thorne, who taught me that our most meaningful contributions may be the ones whose impact we never witness—like a light shining across dark waters, guiding ships we will never see safely home."
""",
    "quote": "The purpose of life is not to be happy. It is to be useful, to be honorable, to be compassionate, to have it make some difference that you have lived and lived well.",
    "quote_author": "Ralph Waldo Emerson",
    "tags": ["Purpose", "Meaning", "Service", "Legacy", "Story"]
}

# Practical Tip
purposeful_path_tip = {
    "title": "Values Compass Exercise",
    "short_form": """
To clarify your sense of purpose, try this Values Compass Exercise: Take 15 minutes to list 5-7 core values that truly matter to you (such as creativity, connection, or service). For each value, write one sentence about why it's meaningful to you. Then, review your daily activities from the past week and note which ones aligned with these values and which didn't. Finally, identify one small action you can take tomorrow to better align your time with your values. This simple practice helps bridge the gap between what you say matters and how you actually live, gradually guiding you toward a more purposeful path.
""",
    "long_form": """
In our search for purpose and meaning, we often look outward—seeking the perfect career, relationship, or achievement that will make our lives feel significant. Yet true purpose typically emerges not from external circumstances but from within, from a clear understanding of our core values and a commitment to living in alignment with them. The Values Compass Exercise offers a practical approach to clarifying these values and using them as a guide for more purposeful living.

This exercise is called a "compass" because values, like a compass, don't tell you exactly where to go or what to do. Rather, they provide orientation and direction, helping you navigate life's complex terrain with greater clarity and purpose. Just as a compass points toward true north regardless of the specific path you take, your values can guide your choices and actions even as your circumstances change.

**The Values Compass Exercise: A Step-by-Step Guide**

Set aside approximately 30-45 minutes for this exercise when you can reflect without interruption. You'll need a journal or notebook, a pen, and an open mind.

**Step 1: Identify Your Core Values (15 minutes)**

Begin by brainstorming a list of values that resonate deeply with you. Values are qualities or principles that you consider fundamentally important—they represent what matters most to you beneath the surface of daily concerns.

Some examples of values include:
- Authenticity
- Connection
- Creativity
- Curiosity
- Compassion
- Courage
- Excellence
- Freedom
- Growth
- Harmony
- Honesty
- Justice
- Kindness
- Learning
- Loyalty
- Peace
- Playfulness
- Respect
- Security
- Service
- Spirituality
- Tradition
- Wisdom

From your brainstormed list, select 5-7 values that feel most essential to you. These should be the values that, when honored in your life, give you a sense of fulfillment and alignment. When violated or ignored, these same values likely create feelings of discomfort or emptiness.

For each selected value, write a brief personal definition—what this value means specifically to you. For example, if "connection" is a core value, you might write: "Connection means maintaining deep, authentic relationships where I can be fully myself and help others feel seen and understood."

**Step 2: Explore the "Why" Behind Each Value (10 minutes)**

For each core value, write one or two sentences about why this value matters to you. What makes it significant in your life? How does living this value contribute to your sense of meaning or purpose?

For example:
"Creativity matters to me because when I'm creating something new, I feel fully alive and connected to something larger than myself. It allows me to contribute something unique to the world that only I can offer."

This step helps deepen your understanding of your values and strengthens your commitment to them by connecting them to your personal sense of meaning.

**Step 3: Conduct a Values Alignment Audit (10 minutes)**

Review your activities from the past week and assess how well they aligned with your identified values. Create three columns in your journal:

- Column 1: List activities that strongly aligned with your values
- Column 2: List activities that were neutral in terms of values alignment
- Column 3: List activities that conflicted with or pulled you away from your values

For each activity, note which specific value(s) it aligned with or contradicted. Be honest but not judgmental in this assessment—the goal is awareness, not self-criticism.

You might notice patterns emerging. Perhaps certain relationships, work projects, or habits consistently align with your values, while others create tension or disconnection from what matters most to you.

**Step 4: Identify Value-Aligned Actions (10 minutes)**

Based on your audit, identify one small, concrete action you can take tomorrow to better align your life with each of your core values. These should be specific, achievable actions, not vague intentions.

For example:
- Value: Connection → Action: Call my friend Sarah for a genuine check-in conversation instead of just texting
- Value: Creativity → Action: Spend 20 minutes working on my art project before checking email
- Value: Growth → Action: Read one chapter of the book on personal development I've been meaning to start

The key is to choose actions that are small enough to be doable but meaningful enough to reinforce your connection to the value.

**Step 5: Create a Values Compass Statement (Optional, 5 minutes)**

Synthesize your reflections into a brief "Values Compass Statement" that captures the essence of your core values and how they guide your life. This statement can serve as a touchstone when you face difficult decisions or feel disconnected from your sense of purpose.

For example: "I navigate my life guided by creativity, connection, and growth. When I make choices that honor these values—creating meaningful work, nurturing authentic relationships, and continuously learning—I experience a sense of purpose and fulfillment. These values are my compass, pointing me toward my true north regardless of external circumstances."

**Integrating the Values Compass into Daily Life**

The real power of this exercise emerges when you use it as an ongoing practice rather than a one-time reflection. Consider these strategies for integrating your values compass into daily life:

**Morning Intention Setting**: Each morning, take 30 seconds to review your core values and set an intention to make choices aligned with them throughout the day.

**Decision Filter**: When facing choices, ask yourself, "Which option best aligns with my core values?" This can simplify complex decisions by clarifying what truly matters to you.

**Weekly Review**: Set aside 10 minutes each week to reflect on how your actions aligned with your values and identify opportunities for greater alignment in the coming week.

**Environmental Cues**: Create visual reminders of your values in your physical environment—perhaps a list in your planner, symbols on your desk, or a background image on your phone.

**Values-Based Goal Setting**: When establishing goals, explicitly connect them to your core values. Goals that serve your values are more meaningful and motivating than those based solely on external metrics of success.

**The Path to Purpose**

As you practice living in alignment with your core values, you may find that a sense of purpose emerges naturally. Purpose often reveals itself not through dramatic epiphanies but through the accumulated experience of living authentically according to what matters most to you.

The Values Compass Exercise helps bridge the gap between abstract notions of purpose and the concrete reality of daily choices. By clarifying what truly matters to you and making incremental shifts toward greater values alignment, you gradually create a life that feels more meaningful, coherent, and purposeful—not because you've found the perfect external circumstances, but because you're living in integrity with your deepest values.

Remember that this is an iterative process. Your understanding of your values may evolve over time, and your ability to live in alignment with them will deepen with practice. The compass metaphor reminds us that finding our purpose is not about reaching a fixed destination but about orienting ourselves toward what matters most and taking purposeful steps in that direction, one day at a time.
""",
    "quote": "Your purpose in life is to find your purpose and give your whole heart and soul to it.",
    "quote_author": "Buddha",
    "tags": ["Purpose", "Values", "Practical Tip", "Self-Discovery", "Meaning"]
}

# Reflection
purposeful_path_reflection = {
    "title": "Small Acts, Great Purpose",
    "short_form": """
We often associate <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>