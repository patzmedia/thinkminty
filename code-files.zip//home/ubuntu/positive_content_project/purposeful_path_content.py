import pandas as pd
import os

# Function to count words in text
def count_words(text):
    return len(text.split())

# Load the existing spreadsheet
output_file = 'positive_content_sets.xlsx'
try:
    df = pd.read_excel(output_file)
except FileNotFoundError:
    # If file doesn't exist, create a new DataFrame with the required columns
    columns = [
        'Category',
        'Content Type',
        'Title',
        'Short Form Content',
        'Short Form Word Count',
        'Long Form Content',
        'Long Form Word Count',
        'Quote',
        'Quote Author',
        'Tags'
    ]
    df = pd.DataFrame(columns=columns)

# Content for Purposeful Path category
purposeful_path_content = [
    # Stories/Parables
    {
        'Category': 'Purposeful Path',
        'Content Type': 'Stories/Parables',
        'Title': 'The Stonecutter\'s Vision',
        'Short Form Content': """Finding purpose begins with connecting your daily work to a larger vision. A traveler once came upon three stonecutters working in a quarry. "What are you doing?" he asked the first. "Cutting stones," the man replied tersely. The traveler asked the second, who answered, "Earning a living to support my family." When he asked the third stonecutter the same question, the man's face lit up: "I am building a cathedral that will inspire generations to look heavenward." All three were doing identical work, but only the third connected his daily labor to a meaningful purpose. The stones he cut were no different from the others, but his vision transformed mundane work into sacred contribution. Purpose isn't found in what we do, but in how we understand the significance of our actions within a larger story.""",
        'Long Form Content': """Finding purpose begins with connecting your daily work to a larger vision. This truth is beautifully illustrated in the story of three stonecutters working in a medieval quarry.

A traveler journeying through the countryside came upon a quarry where three men were working under the hot sun, each cutting stones from the rock face. Curious about their work, the traveler approached the first stonecutter, who appeared tired and disgruntled.

"What are you doing?" the traveler asked.

Without looking up and with obvious frustration in his voice, the first stonecutter replied, "Cutting stones. What does it look like I'm doing?" He wiped sweat from his brow and continued his labor, clearly counting the minutes until his workday would end.

The traveler nodded and moved on to the second stonecutter, who seemed less agitated but still focused intently on his task.

"And you, what are you doing?" the traveler inquired.

The second man paused briefly and responded with a pragmatic tone, "I'm earning a living to support my family. This job puts food on our table and keeps a roof over our heads." He then returned to his work with diligence, if not enthusiasm.

Finally, the traveler approached the third stonecutter, who, surprisingly, was smiling as he worked. Despite doing the exact same physical labor as the others, there was an unmistakable energy and joy in his movements.

"And you?" asked the traveler. "What are you doing?"

The third stonecutter set down his tools, stood up straight, and with eyes shining, gestured toward the distance. "I am building a cathedral," he said with reverence. "A magnificent structure that will lift people's eyes and hearts toward heaven for generations to come. Each stone I cut will help create a sacred space where people find comfort, inspiration, and connection to something greater than themselves."

The traveler looked where the man pointed but could see only the foundation of a building far in the distance. Yet in the stonecutter's eyes, he could see the soaring arches, the rose windows filtering colored light, and the spires reaching toward the sky.

All three men performed exactly the same physical task. They all experienced the same discomforts—the heat, the dust, the physical strain. They all received the same wages. But their experience of their work was profoundly different.

The first stonecutter saw only the task itself—repetitive, demanding, and isolated from any greater meaning. The second recognized his work as a means to an end—not meaningful in itself, but valuable for what it provided. The third, however, connected his immediate actions to a vision that transcended the present moment. He understood how his specific contribution, however humble, was essential to creating something beautiful and meaningful that would outlast his own lifetime.

This simple parable illuminates a profound truth about purpose: it isn't determined primarily by what we do, but by how we understand the significance of our actions within a larger story. Purpose transforms our perception of even the most ordinary tasks.

Consider how this applies to our own lives. The parent changing diapers can see it as an endless, thankless chore, or as nurturing a human being who will one day contribute to the world in ways yet unimagined. The office worker processing documents can see it as meaningless paperwork, or as creating order that helps an organization serve its clients more effectively. The student studying for exams can see it as jumping through arbitrary hoops, or as developing knowledge and skills that will eventually allow them to make their unique contribution.

Purpose doesn't always announce itself with dramatic clarity. More often, it emerges gradually as we connect our daily actions to values and visions that matter deeply to us. Like the third stonecutter, we discover purpose when we can see beyond the immediate task to the cathedral we're helping to build.

This doesn't mean we should deny the challenges or difficulties of our work. The third stonecutter still felt the heat and strain of his labor. But his vision gave him a context that transformed his experience of those same conditions. His purpose didn't eliminate difficulty—it gave the difficulty meaning.

The story also reminds us that purpose is often connected to serving something beyond ourselves. The third stonecutter found meaning in how his work would benefit others, even those not yet born. This aligns with research showing that lasting fulfillment comes not from self-focused pursuits but from contributing to something larger than ourselves.

Today, consider what "cathedral" you might be building through your daily activities. How do your efforts, however humble they might seem in isolation, contribute to something meaningful? What vision connects your present actions to a future you value? In answering these questions, you may discover that you've been cutting stones for a cathedral all along—you just needed to lift your eyes to see it.""",
        'Quote': 'The meaning of life is to find your gift. The purpose of life is to give it away.',
        'Quote Author': 'Pablo Picasso',
        'Tags': 'purpose, meaning, vision, work, contribution, perspective'
    },
    
    # Practical Tips
    {
        'Category': 'Purposeful Path',
        'Content Type': 'Practical Tips',
        'Title': 'Finding Your Purpose Compass',
        'Short Form Content': """Discover your purposeful path with these practical exercises: 1) Create a personal mission statement by completing the sentence: "I exist to..." Focus on how you serve others rather than achievements. Refine it until it resonates deeply. 2) Conduct a "joy-skill-need" audit - list activities that bring you joy, skills you excel at, and needs you see in the world. Look for intersections among these three areas. 3) Identify your core values through the "five whys" technique - name something important to you, then ask "why?" five times to uncover the underlying value. 4) Practice purpose-spotting in daily life by asking each evening: "When did I feel most alive, engaged, or useful today?" 5) Experiment with micro-purposes by committing to small, meaningful actions for two weeks before evaluating their impact on your sense of fulfillment.""",
        'Long Form Content': """Discovering your purposeful path doesn't require a dramatic epiphany or complete life overhaul. Instead, purpose often emerges gradually through intentional reflection and small experiments. These five practical exercises can help you clarify your unique contribution and find greater meaning in your daily life.

1) Create a Personal Mission Statement
A personal mission statement distills your purpose into a clear, compelling declaration that can guide your decisions and priorities. Unlike corporate mission statements, which focus on outcomes and achievements, the most meaningful personal missions center on contribution and service.

How to implement this practice: Set aside 30 minutes of uninterrupted time. Begin by completing the sentence: "I exist to..." Focus on how you serve others or contribute to something you value, rather than on personal achievements or acquisitions. For example, "I exist to create spaces where people feel truly seen and heard" or "I exist to translate complex information into understanding that empowers others to make better decisions."

Write several versions, experimenting with different wording until you find a statement that resonates deeply. The right mission statement will feel both inspiring and authentic—something that stretches you while still reflecting your true values and strengths.

Once you've crafted your statement, keep it visible in your daily environment. Review it regularly, especially when making significant decisions. Ask yourself, "Does this choice align with my mission?" Over time, you may refine your statement as your understanding of your purpose evolves.

2) Conduct a "Joy-Skill-Need" Audit
Purpose often emerges at the intersection of what brings you joy, what you're good at, and what the world needs. This three-circle Venn diagram approach helps identify potential purpose pathways that are both personally fulfilling and externally valuable.

How to implement this practice: Create three lists:
- Joy: Activities that energize you and create a sense of flow
- Skills: Abilities you've developed that others recognize in you
- Needs: Problems or needs you see in your community, workplace, or the broader world

Be specific and comprehensive with each list. For "joy," don't just write "helping people"—specify exactly how you enjoy helping (e.g., "teaching someone a skill one-on-one" or "organizing systems that make people's lives easier"). For "skills," include both technical abilities and character strengths. For "needs," consider issues that genuinely matter to you, not just what others might consider important.

Once you've completed all three lists, look for intersections. Where do your joys and skills align with addressing a need? These intersection points often indicate promising directions for purposeful action. You might discover that your joy in storytelling, skill in digital media, and concern about environmental issues could combine into educational content creation for environmental awareness.

3) Identify Your Core Values Through the "Five Whys" Technique
Purpose is intimately connected to your core values—the principles that matter most to you. The "Five Whys" technique, borrowed from systems analysis, helps you dig beneath surface preferences to uncover the deeper values that drive your sense of meaning.

How to implement this practice: Begin by identifying something important to you—a goal, activity, or priority. Then ask yourself "Why is this important to me?" After answering, ask "Why?" again about your answer. Continue this process five times to reach the underlying value.

For example:
- "I want to start a community garden." Why?
- "Because I want people to have access to fresh food." Why?
- "Because good nutrition affects everything from physical health to mental wellbeing." Why?
- "Because I believe everyone deserves the foundation for a healthy, productive life." Why?
- "Because I value human dignity and equal opportunity." Why?
- "Because at my core, I believe in the inherent worth of every person."

This process reveals that what began as a practical project (a community garden) is actually driven by core values of human dignity and equality. Understanding these underlying values helps you recognize other potential expressions of your purpose beyond your initial idea.

4) Practice Purpose-Spotting in Daily Life
Purpose doesn't always announce itself through dramatic revelations. Often, it leaves subtle clues in your everyday experiences—moments when you feel particularly alive, engaged, or useful. By intentionally noticing these moments, you can identify patterns that point toward your larger purpose.

How to implement this practice: Each evening for two weeks, ask yourself: "When did I feel most alive, engaged, or useful today?" Record your answers in a journal, being as specific as possible about the situation, what you were doing, who you were with, and why the experience felt meaningful.

After two weeks, review your entries looking for patterns. Do certain types of activities consistently appear? Are there particular elements—like solving problems, creating beauty, or connecting with others—that show up repeatedly? These patterns often reveal aspects of your purpose that you may not have consciously recognized.

This practice helps you discover purpose that's already present in your life rather than searching for it in some distant future. You may realize that seemingly small moments—like mentoring a colleague or organizing information for greater clarity—actually connect to your larger purpose.

5) Experiment with Micro-Purposes
Finding your purpose isn't a one-time discovery but an evolving journey of experimentation and refinement. Rather than waiting for complete clarity before taking action, try "micro-purposes"—small, low-risk ways to explore potential purposeful paths.

How to implement this practice: Based on insights from the previous exercises, identify three small, specific actions you could take in the next two weeks to explore a potential purpose direction. These might include volunteering for a specific cause, creating a small project that uses your skills in a new way, or having conversations with people working in a field that interests you.

Commit to these micro-experiments for two weeks, then evaluate your experience. Pay attention not just to whether you enjoyed the activities, but to whether they gave you a sense of meaning and contribution. Did time seem to fly by? Did you find yourself thinking about the work even when you weren't doing it? Did you feel a sense of being useful or making a difference, however small?

Use these insights to design your next set of experiments, gradually refining your understanding of your purpose through direct experience rather than abstract contemplation.

Remember that purpose isn't a destination you reach once and for all, but a dynamic process that evolves throughout your life. These practices aren't about finding the "perfect" purpose, but about connecting more deeply with the meaning that already exists in your life and taking intentional steps toward greater alignment between your daily actions and your deepest values. By approaching purpose as an ongoing exploration rather than a one-time discovery, you open yourself to a lifetime of meaningful growth and contribution.""",
        'Quote': 'The purpose of life is not to be happy. It is to be useful, to be honorable, to be compassionate, to have it make some difference that you have lived and lived well.',
        'Quote Author': 'Ralph Waldo Emerson',
        'Tags': 'purpose, meaning, practical tips, values, contribution, self-discovery'
    },
    
    # Reflections
    {
        'Category': 'Purposeful Path',
        'Content Type': 'Reflections',
        'Title': 'The Compass of Meaning',
        'Short Form Content': """Purpose isn't something we find like a hidden treasure—it's something we bui<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>