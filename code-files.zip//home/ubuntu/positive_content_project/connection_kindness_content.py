import pandas as pd
import os

# Function to count words in text
def count_words(text):
    return len(text.split())

# Load the existing spreadsheet
output_file = 'positive_content_sets.xlsx'
try:
    df = pd.read_excel(output_file)
except FileNotFoundError:
    # If file doesn't exist, create a new DataFrame with the required columns
    columns = [
        'Category',
        'Content Type',
        'Title',
        'Short Form Content',
        'Short Form Word Count',
        'Long Form Content',
        'Long Form Word Count',
        'Quote',
        'Quote Author',
        'Tags'
    ]
    df = pd.DataFrame(columns=columns)

# Content for Connection & Kindness category
connection_kindness_content = [
    # Stories/Parables
    {
        'Category': 'Connection & Kindness',
        'Content Type': 'Stories/Parables',
        'Title': 'The Ripple Effect',
        'Short Form Content': """Small acts of kindness create ripples that extend far beyond our sight. A young woman was walking along a beach where thousands of starfish had washed ashore. She began picking them up one by one and tossing them back into the ocean. An older man approached and said, "Why bother? There are thousands here. You can't possibly make a difference." The woman bent down, picked up another starfish, and gently returned it to the water. "I made a difference to that one," she replied. The man stood silently for a moment, then joined her. Soon, others noticed and began helping too. By sunset, most of the starfish had been saved—not because one person did everything, but because one person started a ripple that inspired others to join in. Our acts of kindness, however small, create similar ripples of positive impact that extend far beyond what we can see.""",
        'Long Form Content': """Small acts of kindness create ripples that extend far beyond our sight. This truth is beautifully illustrated in a story that has been shared in various forms across cultures and generations.

Early one morning, a young woman was walking along a beach where thousands of starfish had washed ashore during the night's high tide. The morning sun was rising, and as the tide receded, the stranded starfish were beginning to dry out and die in the increasing heat.

The young woman began picking up the starfish one by one and gently tossing them back into the ocean. She worked methodically, bending down, selecting a starfish, carrying it to the water's edge, and releasing it into the waves before returning for another.

After she had been doing this for about twenty minutes, an older man approached along the beach. He watched her for a while with a mixture of curiosity and skepticism. Finally, he spoke up.

"Excuse me," he said, "but what exactly are you doing?"

"The tide has washed these starfish onto the shore," she explained without pausing her work. "If they don't get back into the water, they'll die in the sun."

The man looked up and down the beach. Starfish covered the sand as far as he could see in both directions—thousands upon thousands of them.

"But there must be thousands of starfish on this beach," he said. "You can't possibly get to all of them. Most will die before you reach them. Does it really matter?"

The young woman paused and looked down at the starfish in her hand. It was a brilliant orange, with five perfectly formed arms radiating from its center. She considered the man's question seriously.

Then she gently tossed the starfish into the incoming waves and watched as it disappeared beneath the surface, safely returned to its home. She turned to the man with a gentle smile.

"It mattered to that one," she replied.

The man stood silently for a moment, taking in her words. Then, without saying anything more, he bent down, picked up a starfish, and tossed it into the ocean. He reached for another, and another.

As they worked side by side, a family walking along the beach noticed their activity and asked what they were doing. After hearing the explanation, the parents and children joined in, each taking a section of beach and carefully returning starfish to the sea.

A group of joggers came by, saw what was happening, and spread the word to others. By midday, dozens of people had gathered, all working together to save the stranded starfish. By sunset, most of the starfish had been returned to the ocean—not because one person had done everything, but because one person had started a ripple that inspired others to join in.

This simple parable illustrates a profound truth about kindness and connection. Often, when faced with overwhelming problems—whether it's environmental challenges, social injustice, or personal suffering—we can feel paralyzed by the enormity of the need. "What difference can one person make?" we ask ourselves. "Why bother trying when the problem is so vast?"

But this story reminds us that making a difference doesn't require solving the entire problem. It simply requires helping the one in front of us. And when we do that—when we take that first step of compassionate action—we create ripples that extend far beyond our initial impact.

These ripples work in multiple ways. First, our actions directly help the immediate recipient of our kindness, whether that's a stranded starfish, a hungry neighbor, or a lonely colleague. That impact alone justifies the effort.

But the ripples continue. Others observe our actions and are often inspired to join in, multiplying the direct impact. The man who initially questioned the young woman's efforts ended up participating himself. The family and joggers who passed by were moved to contribute as well. One person's commitment catalyzed a community response.

Beyond that, acts of kindness change the actors themselves. Each time we choose compassion over indifference, we strengthen that neural pathway in our brains, making future acts of kindness more likely. We begin to see ourselves as the kind of person who helps others, and this identity shapes our subsequent choices.

Finally, those who receive or witness kindness are more likely to extend kindness to others. Research in positive psychology confirms this "pay it forward" effect—experiencing kindness increases the likelihood that a person will act kindly toward someone else, creating an expanding network of positive interactions.

Like the young woman on the beach, we don't need to solve every problem or help every person to make a meaningful difference. We simply need to help the one in front of us, trusting in the ripple effect of that single act. As anthropologist Margaret Mead famously said, "Never doubt that a small group of thoughtful, committed citizens can change the world; indeed, it's the only thing that ever has."

Today, consider the "starfish" in your own life—the individuals within your reach who might benefit from a small act of kindness or connection. It might be a colleague who needs encouragement, a neighbor who could use practical help, or even a stranger who would be uplifted by a genuine smile or word of appreciation.

Remember that you may never see the full extent of the ripples your kindness creates. The young woman on the beach couldn't have predicted how many people would eventually join her effort. Similarly, we rarely witness how our acts of compassion might inspire others or how they might transform situations beyond our immediate view.

But we can trust that these ripples exist and that they matter—not just to the direct recipients of our kindness, but to the broader fabric of human connection that sustains us all.""",
        'Quote': 'I alone cannot change the world, but I can cast a stone across the waters to create many ripples.',
        'Quote Author': 'Mother Teresa',
        'Tags': 'kindness, connection, compassion, impact, community, service'
    },
    
    # Practical Tips
    {
        'Category': 'Connection & Kindness',
        'Content Type': 'Practical Tips',
        'Title': 'Building Deeper Connections',
        'Short Form Content': """Strengthen your relationships with these connection-building practices: 1) Practice "question upgrading" - replace surface questions like "How are you?" with more specific ones like "What's been on your mind lately?" or "What's been giving you energy recently?" 2) Try the 4-minute eye contact exercise - set a timer and maintain gentle eye contact with a willing partner; this simple practice often creates surprising intimacy. 3) Implement the "phone-free zone" - designate specific times or spaces where devices are set aside to allow for undistracted connection. 4) Use the "active listening ratio" - aim for 80% listening, 20% speaking in important conversations, focusing on understanding rather than formulating your response. 5) Create a "connection ritual" - establish a regular activity that fosters meaningful interaction, like a weekly walk, cooking together, or sharing three gratitudes before dinner.""",
        'Long Form Content': """Meaningful connection doesn't happen automatically in our busy, distraction-filled lives. It requires intentional practices that create space for genuine interaction and understanding. These five evidence-based strategies can help you deepen your relationships and experience the profound benefits of authentic human connection.

1) Practice "Question Upgrading"
The questions we ask shape the conversations we have. Many of our standard social inquiries—"How are you?" "How was your day?" "What's new?"—tend to elicit surface-level responses rather than meaningful exchange. Question upgrading involves replacing these default questions with more specific, thought-provoking alternatives that invite deeper sharing.

How to implement this practice: Create a personal list of upgraded questions that feel natural to you. Instead of "How are you?" try "What's been on your mind lately?" or "What's been giving you energy recently?" Replace "How was your day?" with "What was the most interesting part of your day?" or "What challenged you today?" Instead of "What's new?" ask "What are you looking forward to right now?" or "What have you been learning about lately that excites you?"

The key is to ask questions that can't be answered with a simple "fine" or "nothing much." Good upgraded questions are specific enough to spark reflection but open enough to allow the other person to take the conversation where they feel comfortable. Use these questions not just with close friends but also with acquaintances and colleagues—you'll be surprised how often people welcome the opportunity for more meaningful exchange.

2) Try the 4-Minute Eye Contact Exercise
Developed by psychologist Arthur Aron and featured in his research on interpersonal closeness, this simple exercise has been shown to significantly increase feelings of connection between people, even strangers. The practice involves maintaining gentle eye contact with a willing partner for four uninterrupted minutes.

How to implement this practice: Invite someone you'd like to feel more connected with to try this exercise. Sit facing each other at a comfortable distance. Set a timer for four minutes, and maintain eye contact for the duration. The key instruction is to simply be present with each other—no need to speak, although gentle smiling is fine. If maintaining eye contact for four minutes feels too intense initially, start with one or two minutes and work up to the full duration.

This practice works because eye contact activates the parasympathetic nervous system, releasing oxytocin (sometimes called the "bonding hormone") and creating a physiological state conducive to connection. It also requires a level of vulnerability that signals trust and openness. Many people report feeling surprisingly moved by this simple exercise, even with people they've known for years.

3) Implement the "Phone-Free Zone"
Digital devices, while connecting us in some ways, often create barriers to deep in-person connection. The mere presence of a phone—even if it's not being actively used—has been shown in research to reduce conversational quality and empathy between people.

How to implement this practice: Designate specific times or spaces in your life as completely phone-free. This might be the dinner table, the bedroom, the first hour after coming home from work, or a weekly date night. Create a physical place where phones are deposited during these times—a basket by the front door or a drawer in another room. The key is to make the phones completely inaccessible, not just face-down or on silent.

For this practice to be effective, it needs to be consistent and mutual. Work with family members or housemates to agree on phone-free times that work for everyone, and consider what exceptions might be necessary (such as expecting an important call). You might be surprised by how quickly the quality of your interactions improves when screens aren't competing for attention.

4) Use the "Active Listening Ratio"
Most of us think we're better listeners than we actually are. Research shows that in typical conversations, people spend more time thinking about what they'll say next than truly absorbing what the other person is communicating. Active listening—fully focusing on understanding rather than responding—is one of the most powerful ways to create connection.

How to implement this practice: In important conversations, aim for an 80/20 ratio—80% listening, 20% speaking. This doesn't mean being completely silent, but rather that your contributions primarily serve to deepen your understanding of the other person. Practice these active listening techniques:
- Ask follow-up questions that build on what the person has shared
- Periodically summarize what you've heard to confirm understanding
- Notice and name emotions you're picking up ("It sounds like that was really frustrating")
- Resist the urge to relate the conversation back to your own experience
- Pay attention to non-verbal cues like tone, facial expressions, and body language

This practice requires patience and self-awareness, as most of us have deeply ingrained habits of steering conversations toward our own perspectives. Start by practicing with one conversation per day, gradually building your active listening muscle.

5) Create a "Connection Ritual"
Rituals create structure and meaning that elevate ordinary interactions into significant moments of connection. A connection ritual is a regular activity specifically designed to foster meaningful interaction with important people in your life.

How to implement this practice: Choose an activity that can be consistently maintained and that naturally encourages quality interaction. This might be a weekly walk with no phones, cooking a meal together every Sunday, sharing three gratitudes before dinner each night, or having coffee on the porch every Saturday morning. The specific activity matters less than the intentionality behind it and the consistency with which it occurs.

What makes something a ritual rather than just a regular activity is the shared understanding of its purpose and importance. Explicitly frame the chosen activity as special time for connection, and protect it from other demands when possible. Over time, these rituals become anchors of relationship that both parties look forward to and prioritize.

These five practices aren't quick fixes but rather investments in the quality of your relationships over time. The benefits of implementing them extend far beyond the pleasure of better conversations. Research consistently shows that meaningful social connection is associated with better physical health, greater emotional resilience, and even longer lifespan.

By intentionally creating space for deeper connection in your daily life, you're not just enhancing your relationships—you're contributing to a fundamental human need that supports wellbeing in nearly every dimension. Start with the practice that resonates most strongly with you, implement it consistently for at l<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>