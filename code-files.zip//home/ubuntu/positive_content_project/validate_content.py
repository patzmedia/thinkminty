import pandas as pd
import os

# Load the spreadsheet
output_file = 'positive_content_sets.xlsx'
df = pd.read_excel(output_file)

# Define word count requirements
min_short_form_words = 100
min_long_form_words = 500
max_long_form_words = 800

# Validate word counts and content
print("Validating content quality and word counts...\n")
print("Word Count Requirements:")
print(f"- Short Form: minimum {min_short_form_words} words (1-2 minute read)")
print(f"- Long Form: {min_long_form_words}-{max_long_form_words} words (4-10 minute read)\n")

# Count total content sets
total_sets = len(df)
print(f"Total content sets: {total_sets}")

# Group by category and content type to verify distribution
category_counts = df.groupby('Category').size()
content_type_counts = df.groupby(['Category', 'Content Type']).size()

print("\nContent sets by category:")
for category, count in category_counts.items():
    print(f"- {category}: {count} sets")

print("\nContent sets by category and type:")
for (category, content_type), count in content_type_counts.items():
    print(f"- {category} - {content_type}: {count} sets")

# Check word counts
short_form_below_min = df[df['Short Form Word Count'] < min_short_form_words]
long_form_below_min = df[df['Long Form Word Count'] < min_long_form_words]
long_form_above_max = df[df['Long Form Word Count'] > max_long_form_words]

print("\nWord count validation:")
if len(short_form_below_min) == 0:
    print(f"✓ All short-form content meets the minimum requirement of {min_short_form_words} words")
else:
    print(f"✗ Found {len(short_form_below_min)} short-form content pieces below the minimum requirement of {min_short_form_words} words:")
    for _, row in short_form_below_min.iterrows():
        print(f"  - {row['Category']} - {row['Content Type']}: {row['Short Form Word Count']} words")

if len(long_form_below_min) == 0:
    print(f"✓ All long-form content meets the minimum requirement of {min_long_form_words} words")
else:
    print(f"✗ Found {len(long_form_below_min)} long-form content pieces below the minimum requirement of {min_long_form_words} words:")
    for _, row in long_form_below_min.iterrows():
        print(f"  - {row['Category']} - {row['Content Type']}: {row['Long Form Word Count']} words")

if len(long_form_above_max) == 0:
    print(f"✓ All long-form content is within the maximum limit of {max_long_form_words} words")
else:
    print(f"! Found {len(long_form_above_max)} long-form content pieces above the recommended maximum of {max_long_form_words} words:")
    for _, row in long_form_above_max.iterrows():
        print(f"  - {row['Category']} - {row['Content Type']}: {row['Long Form Word Count']} words")

# Calculate average word counts
avg_short_form = df['Short Form Word Count'].mean()
avg_long_form = df['Long Form Word Count'].mean()

print(f"\nAverage word counts:")
print(f"- Short Form: {avg_short_form:.1f} words")
print(f"- Long Form: {avg_long_form:.1f} words")

# Check for missing data
missing_data = df[df.isnull().any(axis=1)]
if len(missing_data) == 0:
    print("\n✓ No missing data found in any content sets")
else:
    print(f"\n✗ Found {len(missing_data)} content sets with missing data:")
    for _, row in missing_data.iterrows():
        missing_columns = [col for col in df.columns if pd.isnull(row[col])]
        print(f"  - {row['Category']} - {row['Content Type']}: Missing {', '.join(missing_columns)}")

# Overall validation result
if len(short_form_below_min) == 0 and len(long_form_below_min) == 0 and len(missing_data) == 0:
    print("\n✓ VALIDATION PASSED: All content meets the requirements")
else:
    print("\n✗ VALIDATION FAILED: Some content does not meet the requirements")

# Save validation results to a file
with open('content_validation_results.txt', 'w') as f:
    f.write("Content Validation Results\n")
    f.write("========================\n\n")
    f.write(f"Total content sets: {total_sets}\n\n")
    
    f.write("Content sets by category:\n")
    for category, count in category_counts.items():
        f.write(f"- {category}: {count} sets\n")
    
    f.write("\nContent sets by category and type:\n")
    for (category, content_type), count in content_type_counts.items():
        f.write(f"- {category} - {content_type}: {count} sets\n")
    
    f.write("\nWord count validation:\n")
    if len(short_form_below_min) == 0:
        f.write(f"✓ All short-form content meets the minimum requirement of {min_short_form_words} words\n")
    else:
        f.write(f"✗ Found {len(short_form_below_min)} short-form content pieces below the minimum requirement of {min_short_form_words} words:\n")
        for _, row in short_form_below_min.iterrows():
            f.write(f"  - {row['Category']} - {row['Content Type']}: {row['Short Form Word Count']} words\n")
    
    if len(long_form_below_min) == 0:
        f.write(f"✓ All long-form content meets the minimum requirement of {min_long_form_words} words\n")
    else:
        f.write(f"✗ Found {len(long_form_below_min)} long-form content pieces below the minimum requirement of {min_long_form_words} words:\n")
        for _, row in long_form_below_min.iterrows():
            f.write(f"  - {row['Category']} - {row['Content Type']}: {row['Long Form Word Count']} words\n")
    
    if len(long_form_above_max) == 0:
        f.write(f"✓ All long-form content is within the maximum limit of {max_long_form_words} words\n")
    else:
        f.write(f"! Found {len(long_form_above_max)} long-form content pieces above the recommended maximum of {max_long_form_words} words:\n")
        for _, row in long_form_above_max.iterrows():
            f.write(f"  - {row['Category']} - {row['Content Type']}: {row['Long Form Word Count']} words\n")
    
    f.write(f"\nAverage word counts:\n")
    f.write(f"- Short Form: {avg_short_form:.1f} words\n")
    f.write(f"- Long Form: {avg_long_form:.1f} words\n")
    
    if len(missing_data) == 0:
        f.write("\n✓ No missing data found in any content sets\n")
    else:
        f.write(f"\n✗ Found {len(missing_data)} content sets with missing data:\n")
        for _, row in missing_data.iterrows():
            missing_columns = [col for col in df.columns if pd.isnull(row[col])]
            f.write(f"  - {row['Category']} - {row['Content Type']}: Missing {', '.join(missing_columns)}\n")
    
    if len(short_form_below_min) == 0 and len(long_form_below_min) == 0 and len(missing_data) == 0:
        f.write("\n✓ VALIDATION PASSED: All content meets the requirements\n")
    else:
        f.write("\n✗ VALIDATION FAILED: Some content does not meet the requirements\n")

print(f"\nValidation results saved to content_validation_results.txt")
