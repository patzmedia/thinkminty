import pandas as pd
import os

# Function to count words in text
def count_words(text):
    return len(text.split())

# Load the existing spreadsheet
output_file = 'positive_content_sets.xlsx'
try:
    df = pd.read_excel(output_file)
except FileNotFoundError:
    # If file doesn't exist, create a new DataFrame with the required columns
    columns = [
        'Category',
        'Content Type',
        'Title',
        'Short Form Content',
        'Short Form Word Count',
        'Long Form Content',
        'Long Form Word Count',
        'Quote',
        'Quote Author',
        'Tags'
    ]
    df = pd.DataFrame(columns=columns)

# Content for Resilience Recharge category
resilience_recharge_content = [
    # Stories/Parables
    {
        'Category': 'Resilience Recharge',
        'Content Type': 'Stories/Parables',
        'Title': 'The Bamboo\'s Strength',
        'Short Form Content': """Resilience is found in bending without breaking. A farmer planted two trees: a mighty oak and a slender bamboo. For years, the oak grew tall and strong, while the bamboo remained thin and flexible. During a violent storm, the oak stood rigid against the winds, refusing to yield. The bamboo, however, bent completely, its tip touching the ground. When the storm passed, the oak had cracked and fallen, while the bamboo returned to its upright position, unharmed. The farmer realized that true strength isn't about rigidity, but about the ability to bend with life's challenges and then rise again. The bamboo's resilience came from its flexibility—its willingness to yield without surrendering its essential nature.""",
        'Long Form Content': """Resilience is found in bending without breaking. This wisdom is beautifully illustrated in the story of a farmer who planted two different trees on his land: a mighty oak and a slender bamboo.

The farmer tended both plants with equal care. Year after year, the oak grew impressively, developing a thick trunk, strong branches, and deep roots. It stood tall and imposing, a symbol of unwavering strength. The bamboo, meanwhile, grew much more slowly. Though it eventually reached a good height, it remained slender and flexible, swaying with even the gentlest breeze.

Visitors to the farm would often admire the majestic oak, commenting on its impressive stature and apparent strength. Few paid much attention to the humble bamboo, which seemed unremarkable by comparison. The farmer, too, took particular pride in the oak, seeing it as a testament to his skill and patience.

One summer, a powerful typhoon approached the region. As the storm clouds gathered, the farmer worried about his crops and trees. He looked at the oak and felt reassured by its solid presence. Surely, he thought, if any tree could withstand the coming storm, it would be the mighty oak with its thick trunk and strong branches.

When the typhoon hit, it brought winds of tremendous force. The farmer watched from his window as the storm raged across his land. The oak stood rigid against the gale, refusing to yield even an inch. Its branches strained and creaked but remained unbending. The bamboo, however, responded differently. It bent lower and lower as the winds intensified, until its slender tip nearly touched the ground.

"The bamboo will surely break," thought the farmer, "while the oak will endure."

But as the storm reached its peak, a loud crack echoed across the land. The farmer watched in dismay as the mighty oak, which had refused to bend, finally broke under the pressure. Its massive trunk split, and the once-majestic tree crashed to the ground.

The bamboo, meanwhile, had bent completely horizontal during the fiercest gusts. But as the storm began to subside and the winds decreased, something remarkable happened. Gradually, the bamboo began to straighten. Little by little, it returned to its upright position. By the time the storm had fully passed, the bamboo stood tall again, completely intact despite the tremendous forces it had endured.

The farmer walked out to survey the damage. Standing beside the fallen oak, he looked over at the bamboo with new appreciation. He realized that what he had mistaken for weakness—the bamboo's flexibility and willingness to bend—was actually its greatest strength.

The oak had relied on rigidity and resistance, refusing to yield to the storm's power. The bamboo, in contrast, had found safety in flexibility—bending with the wind rather than fighting against it, yet never surrendering its essential nature or its roots.

In that moment, the farmer understood a profound truth about resilience. True strength isn't about never bending; it's about the ability to bend without breaking, to face life's inevitable storms and return to one's center afterward.

Like the bamboo, resilient people don't resist challenges with rigid defiance. Instead, they adapt and flex when necessary, allowing difficult circumstances to move through them rather than shatter them. They understand that yielding isn't the same as surrendering, and that sometimes the wisest response to overwhelming pressure is to bend temporarily rather than break permanently.

The farmer took a piece of the fallen oak and a cutting from the bamboo. He placed them on his mantel as reminders of this wisdom. Whenever life brought challenges his way, he would look at these tokens and ask himself, "Am I being the oak or the bamboo today?"

This simple story reminds us that resilience isn't about being unaffected by life's storms. It's about developing the flexibility to bend with those storms while maintaining our core integrity. It's about having roots deep enough to keep us grounded while being flexible enough to move with, rather than against, the powerful forces we encounter throughout our lives.""",
        'Quote': 'The oak fought the wind and was broken, the willow bent when it must and survived.',
        'Quote Author': 'Robert Jordan',
        'Tags': 'resilience, flexibility, strength, adaptation, perseverance, nature'
    },
    
    # Practical Tips
    {
        'Category': 'Resilience Recharge',
        'Content Type': 'Practical Tips',
        'Title': 'Building Your Resilience Toolkit',
        'Short Form Content': """Strengthen your resilience with these practical strategies: 1) Practice the 90-second rule - when facing a setback, acknowledge your emotional response, but after 90 seconds, shift to problem-solving mode. 2) Create a resilience mantra - develop a short, powerful phrase to repeat during challenges, such as "This is temporary" or "I've overcome difficult things before." 3) Build your support network - identify 3-5 people you can genuinely open up to, and nurture these connections regularly. 4) Develop healthy stress outlets - find physical activities that help release tension, whether it's running, yoga, or simply taking a walk in nature. 5) Practice realistic optimism - acknowledge challenges while maintaining confidence in your ability to navigate them successfully.""",
        'Long Form Content': """Strengthening your resilience isn't about eliminating stress or avoiding challenges—it's about developing the inner resources to navigate life's inevitable difficulties with greater ease and confidence. Here are five practical strategies to build your personal resilience toolkit:

1) Practice the 90-Second Rule
When facing a setback or disappointment, give yourself permission to fully experience your initial emotional response—but only for about 90 seconds. Neurological research suggests that the chemical surge of an emotion naturally dissipates after about 90 seconds unless we actively keep it alive through our thoughts. After acknowledging your feelings for this brief period, consciously shift your focus from the emotional center to the problem-solving center of your brain.

How to implement this practice: When something upsetting occurs, set a timer for 90 seconds. During this time, fully feel whatever emotions arise without judgment. When the timer sounds, take a deep breath and ask yourself, "What's one small step I can take right now to move forward?" This simple practice interrupts the cycle of rumination and helps you transition from reactivity to constructive action.

2) Create a Resilience Mantra
Develop a short, powerful phrase that reminds you of your capacity to overcome challenges. This personal mantra serves as an anchor during difficult times, helping to calm your nervous system and activate your inner resources. Your mantra should be brief, positive, and personally meaningful.

How to implement this practice: Reflect on past challenges you've successfully navigated. What personal strengths helped you through? What truth would have comforted you in your darkest moment? Use these insights to craft a mantra such as "This too shall pass," "I bend but don't break," or "I am stronger than this challenge." Write your mantra on small cards and place them where you'll see them regularly—on your bathroom mirror, in your wallet, or as a phone background. When facing difficulties, repeat your mantra silently or aloud, allowing its truth to permeate your consciousness.

3) Build Your Support Network
Resilience isn't a solo endeavor. Research consistently shows that social support is one of the strongest predictors of psychological resilience. Identify 3-5 people you can genuinely open up to, and nurture these connections regularly.

How to implement this practice: Make a list of people in your life who make you feel understood, accepted, and supported. Next to each name, note what type of support they best provide—practical help, emotional understanding, wise perspective, or simply a good laugh when you need it. Reach out to someone on your list this week, not just to seek support but to strengthen the connection. Remember that resilient relationships involve both receiving and offering support, so look for opportunities to be there for others as well.

4) Develop Healthy Stress Outlets
Physical activity is one of the most effective ways to process stress hormones and restore your body to a state of balance. Find activities that help you release tension and reconnect with your physical self.

How to implement this practice: Experiment with different forms of movement to discover what feels most beneficial for you. This might be a vigorous run that helps process frustration, a yoga practice that promotes calm, or simply a walk in nature that provides perspective. The key is consistency—aim for at least 20 minutes of movement daily, especially during challenging periods. Pay attention to how different activities affect your mood and energy, and prioritize those that leave you feeling more centered and capable.

5) Practice Realistic Optimism
Resilience isn't about toxic positivity or denying difficulties. Instead, it involves what psychologists call "realistic optimism"—acknowledging challenges while maintaining confidence in your ability to navigate them successfully.

How to implement this practice: When facing a difficult situation, try this three-step process: First, acknowledge the reality of the challenge without minimizing it. Second, identify aspects of the situation that are within your control, however small. Third, recall a previous challenge you've overcome and the strengths you demonstrated in that situation. This balanced approach prevents both denial and despair, keeping you grounded in reality while activating your problem-solving capabilities.

Building resilience is similar to strengthening a muscle—it requires consistent practice and gradually increases your capacity over time. These five strategies provide a foundation, but the most effective resilience practice is one that you personalize and integrate into your daily life. Start with the strategy that resonates most strongly with you, practice it consistently for at least two weeks, and then add another to your toolkit.

Remember that resilience isn't about bouncing back to exactly who you were before a challenge—it's about bouncing forward, integrating what you've learned, and becoming more equipped for whatever lies ahead. With each difficulty you navigate, you're not just surviving; you're developing greater capacity for future challenges and a deeper appreciation for your own inner resources.""",
        'Quote': 'Do not judge me by my success, judge me by how many times I fell down and got back up again.',
        'Quote Author': 'Nelson Mandela',
        'Tags': 'resilience, practical tips, stress management, emotional regulation, support network, optimism'
    },
    
    # Reflections
    {
        'Category': 'Resilience Recharge',
        'Content Type': 'Reflections',
        'Title': 'The Gift in the Wound',
        'Short Form Content': """Our deepest wounds often become the source of our greatest strength. When we face adversity, we develop capacities that would otherwise remain dormant—compassion born from suffering, wisdom from mistakes, courage from confronting fears. Consider how your own challenges have shaped you. That illness may have taught you to value health and simple pleasures. That heartbreak may have deepened your capacity for empathy. That failure may have freed you from perfectionism. Our wounds, when acknowledged and integrated, don't just heal—they transform into gifts we can offer the world. The Japanese art of kintsugi repairs broken pottery with gold, highlighting rather than hiding the breaks. Similarly, our resilience isn't about erasing our scars but transforming them into something beautiful and uniquely valuable.""",
        'Long Form Content': """Our deepest wounds often become the source of our greatest strength. This paradox lies at the heart of resilience—not just the ability to recover from difficulty, but to be transformed by it in ways that leave us more whole, more human, and more alive than before.

When we face adversity, we develop capacities that would otherwise remain dormant. The person who has known suffering develops a deeper capacity for compassion. The one who has made serious mistakes often gains wisdom that the "perfect" person never acquires. The individual who has faced their fears develops courage that cannot be learned from books or lectures.

Consider for a moment how your own challenges have shaped you. That illness that confined you to bed may have taught you to value health and simple pleasures in a way you never did before. That heartbreak that felt unbearable may have deepened your capacity for empathy and connection. That failure that seemed devastating may have freed you from the prison of perfectionism.

This perspective doesn't minimize suffering or suggest that trauma is somehow "good for us." Rather, it acknowledges that our wounds, when acknowledged and integrated, don't just heal—they transform into gifts we can offer the world.

The Japanese art of kintsugi provides a beautiful metaphor for this process. When a piece of pottery breaks, kintsugi artists repair it using gold, silver, or platinum to highlight rather than hide the breaks. The resulting piece is considered more beautiful and valuable precisely because of its history of brokenness and repair. The cracks become part of the object's story and identity, honored rather than disguised.

Similarly, our resilience isn't about erasing our scars or pretending we were never broken. It's about integrating our wounds into a new wholeness that honors rather than denies our full experience.

Psychologist Carl Jung referred to this as the process of individuation—the integration of the wounded or shadow aspects of ourselves into a more complete identity. He wrote, "There is no coming to consciousness without pain. People will do anything, no matter how absurd, in order to avoid facing their own Soul. One does not become enlightened by imagining figures of light, but by making the darkness conscious."

This integration doesn't happen automatically. It requires us to turn toward our pain w<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>