import pandas as pd
import os

# Function to count words in text
def count_words(text):
    return len(text.split())

# Load the existing spreadsheet
output_file = 'positive_content_sets.xlsx'
try:
    df = pd.read_excel(output_file)
except FileNotFoundError:
    # If file doesn't exist, create a new DataFrame with the required columns
    columns = [
        'Category',
        'Content Type',
        'Title',
        'Short Form Content',
        'Short Form Word Count',
        'Long Form Content',
        'Long Form Word Count',
        'Quote',
        'Quote Author',
        'Tags'
    ]
    df = pd.DataFrame(columns=columns)

# Content for Joyful Living category
joyful_living_content = [
    # Stories/Parables
    {
        'Category': 'Joyful Living',
        'Content Type': 'Stories/Parables',
        'Title': 'The Laughter Garden',
        'Short Form Content': """Joy can be cultivated like a garden. In a village known for its seriousness, there lived an elderly woman whose garden overflowed with vibrant flowers and whose laughter rang out like music. Villagers wondered about her persistent happiness despite life's hardships. One day, a curious child asked her secret. "I plant joy daily," she explained, showing the child a small journal. Inside were simple entries: "Watched sunrise—glorious orange. Felt breeze on my face. Shared tea with a friend." The woman explained, "Joy isn't in grand events but in noticing everyday wonders. I plant these moments in my awareness like seeds, and they bloom into a garden of contentment." The child began his own joy journal, and gradually, the entire village discovered that happiness wasn't something to pursue but to notice and nurture in the ordinary moments of each day.""",
        'Long Form Content': """Joy can be cultivated like a garden. This simple truth was discovered by the residents of Sombertown, a village known throughout the region for its seriousness and practicality. The villagers took pride in their hard work and responsibility, but smiles were rare, and laughter was even rarer.

On the edge of this village lived an elderly woman named Clara whose small cottage stood out from all others. While most homes in Sombertown were neat and orderly but plain, Clara's cottage was surrounded by a riot of colorful flowers that seemed to bloom regardless of the season. More striking than her garden, however, was Clara herself. Unlike her neighbors, she laughed easily and often. Her eyes crinkled with delight at simple pleasures, and her joyful humming could be heard as she tended her garden or walked through the village square.

The villagers regarded Clara with a mixture of suspicion and fascination. Some thought she must be naive or simple-minded to find so much delight in a world full of difficulties. Others secretly envied her apparent happiness but assumed it must be due to an unusually fortunate life.

"She must never have known real hardship," they would say to each other. "That's why she can afford to be so cheerful."

But the truth was quite different. Clara had endured more than her share of sorrows—the early death of her husband, years of financial struggle, and chronic health problems that often left her in pain. Yet somehow, her capacity for joy remained undiminished.

Among the villagers was a ten-year-old boy named Thomas, who was particularly curious about Clara. One spring morning, as she was planting new seedlings in her front garden, Thomas gathered his courage and approached her.

"Excuse me," he said hesitantly. "May I ask you something?"

Clara looked up with a warm smile. "Of course, dear. What would you like to know?"

"Well," Thomas began, "everyone in the village wonders about you. How do you stay so happy all the time? My father says the world is a serious place with serious problems, and that's why grown-ups can't go around laughing like children. But you laugh all the time, even though you're older than anyone I know."

Clara chuckled at his honesty. "That's a very good question, Thomas. Would you like to know my secret?"

Thomas nodded eagerly.

"I plant joy daily," she said, setting down her trowel and wiping her hands on her apron. "Come inside, and I'll show you what I mean."

Thomas followed her into the cottage, which was as colorful inside as her garden was outside. Clara went to a small desk and retrieved a leather-bound journal. She opened it and showed Thomas the pages.

"This is my joy journal," she explained. "Every day, I write down at least three moments of beauty or pleasure that I noticed."

Thomas looked at the most recent entries:

*Watched the sunrise this morning—glorious orange streaks across the sky.
*Felt the breeze on my face while hanging laundry.
*Shared tea and stories with my neighbor Martha.
*Heard the first robin of spring singing outside my window.
*Tasted the season's first strawberries—so sweet!*

"But these are just ordinary things," Thomas said, looking confused.

"Exactly!" Clara exclaimed. "That's the secret most people miss. Joy isn't found primarily in grand events or achievements. It lives in our willingness to notice and appreciate the small wonders that surround us every single day. I plant these moments in my awareness like seeds, and they bloom into a garden of contentment."

She closed the journal gently. "The truth is, Thomas, I've had many sorrows in my life, just like everyone else. But I've discovered that joy and sorrow can coexist. By training my attention to notice moments of beauty and connection, I've cultivated a garden of joy that sustains me through difficult times."

Thomas thought about this for a moment. "Could I do this too?" he asked.

"Absolutely," Clara replied. "Anyone can cultivate joy. It just takes practice, like any other skill."

The next day, Clara presented Thomas with a small notebook of his own. "Your very own joy journal," she said. "Try writing in it every evening before bed."

Thomas took the challenge seriously. At first, he found it difficult to notice three joyful moments each day. But gradually, as he continued the practice, he discovered that he was becoming more attuned to small pleasures—the satisfaction of solving a difficult math problem, the comfort of his mother's cooking, the fun of playing with his dog. The more he looked for moments of joy, the more he found them.

Thomas's parents noticed the change in their son. He seemed lighter somehow, more appreciative, less prone to complaints. When they asked him about it, he explained Clara's practice and showed them his joy journal. Intrigued, they decided to try it themselves.

Slowly, the practice spread throughout Sombertown. Families began keeping joy journals together, sharing their entries at dinner. Neighbors started pointing out beautiful cloud formations or particularly delicious fruits to one another. The atmosphere of the village gradually shifted as people trained themselves to notice what was going right rather than just what was going wrong.

This didn't mean that the villagers became unrealistic or ignored life's genuine problems. Rather, they discovered what Clara had known all along—that cultivating awareness of joy provides the emotional resilience needed to face life's inevitable challenges.

Years later, when visitors came to the village, they often commented on its unusually joyful atmosphere. "What makes this place so special?" they would ask.

The villagers would smile and point to the edge of town, where Clara's cottage stood surrounded by its magnificent garden. "We learned that joy can be cultivated," they would explain. "And once you know how to tend it, it grows and spreads all on its own."

Like the villagers of Sombertown, we all have the capacity to cultivate joy through intentional awareness of the beauty and goodness that exists alongside life's difficulties. By "planting" our attention in moments of wonder, connection, and simple pleasure, we create an inner garden that can sustain us through all seasons of life.""",
        'Quote': 'Find a place inside where there\'s joy, and the joy will burn out the pain.',
        'Quote Author': 'Joseph Campbell',
        'Tags': 'joy, happiness, gratitude, mindfulness, appreciation, daily practice'
    },
    
    # Practical Tips
    {
        'Category': 'Joyful Living',
        'Content Type': 'Practical Tips',
        'Title': 'Joy Boosters for Everyday Life',
        'Short Form Content': """Infuse more joy into your daily life with these practical strategies: 1) Create a joy trigger - choose an everyday action (like washing hands or stopping at red lights) as a reminder to pause and notice something pleasant in that moment. 2) Practice "savoring" - when experiencing something enjoyable, consciously slow down and engage all your senses to fully absorb the experience. 3) Start a laughter practice - watch a funny video, read jokes, or try laughter yoga for 5 minutes daily; the physical act of laughing creates real emotional benefits. 4) Implement the "one photo" challenge - take one photo each day of something that brings you joy or beauty, creating a visual gratitude practice. 5) Schedule micro-adventures - plan small novel experiences weekly, like trying a new food, taking a different route home, or exploring a nearby area you've never visited.""",
        'Long Form Content': """Infuse more joy into your daily life with these practical strategies that don't require major life changes or perfect circumstances. Joy isn't just a lucky accident that happens to some people and not others—it's a capacity we can actively cultivate through simple, intentional practices.

1) Create a Joy Trigger
Choose an everyday action that you perform multiple times throughout your day—like washing your hands, stopping at red lights, or hearing your phone notification sound. Designate this action as your "joy trigger," a reminder to pause for just five seconds and notice something pleasant in that moment.

Perhaps it's the sensation of warm water on your hands, the quality of light coming through your window, or the brief moment of stillness while waiting for the light to change. The specific pleasure doesn't matter as much as the habit of briefly shifting your attention from automatic pilot to present-moment awareness.

How to implement this practice: Choose an action that occurs at least 3-5 times in your typical day. Write down your chosen trigger on a small note and place it somewhere you'll see it regularly as a reminder. For the first week, you might set a phone reminder to help you remember your new practice. After about 21 days, this joy-noticing habit will begin to form naturally.

The beauty of joy triggers is that they integrate seamlessly into your existing routine while gradually training your brain to spot opportunities for positive emotion that were always present but previously overlooked.

2) Practice "Savoring"
Savoring is the art of mindfully extending and amplifying positive experiences through conscious attention. When something pleasant occurs—whether it's tasting delicious food, feeling the sun on your skin, or connecting with a loved one—most of us rush through the experience without fully absorbing it. Savoring involves deliberately slowing down and engaging all your senses to extract the maximum enjoyment from positive moments.

How to implement this practice: Choose one enjoyable experience each day to savor fully. When the experience begins, take a mental "step back" and observe yourself having this experience. Engage each of your senses—what do you see, hear, smell, taste, and feel? Notice the positive emotions arising and allow yourself to fully feel them without rushing to the next activity. You might even verbalize or mentally note what you appreciate about this moment.

Research shows that the practice of savoring can significantly increase happiness levels and help positive experiences register more deeply in your emotional memory, creating a reservoir of good feelings you can access even during challenging times.

3) Start a Laughter Practice
Laughter offers immediate physiological benefits—reducing stress hormones, releasing endorphins, and activating your parasympathetic nervous system. Interestingly, your body doesn't distinguish between spontaneous laughter and intentional laughter. This means you can access the joy-inducing benefits of laughter even when you don't naturally feel like laughing.

How to implement this practice: Set aside 5 minutes daily for intentional laughter. You might watch a short funny video, read jokes, call a friend who makes you laugh, or try "laughter yoga"—a practice where you begin with forced laughter that typically transforms into genuine laughter. Even simulated laughter triggers positive physiological changes that can shift your emotional state.

For maximum benefit, create a "humor first aid kit"—a collection of videos, memes, or recordings that reliably make you laugh. Keep this collection easily accessible for moments when you need an emotional boost.

4) Implement the "One Photo" Challenge
This simple practice combines mindfulness, gratitude, and creativity to heighten your awareness of joy-inducing elements in your environment. Each day, challenge yourself to take one photograph of something that brings you a sense of joy, beauty, or appreciation.

How to implement this practice: Use your phone camera to capture one image daily that represents something you find beautiful, meaningful, or joy-inducing. This might be the pattern of light on your kitchen floor, a moment of connection with a pet or loved one, or a small detail in nature you might otherwise have missed. At the end of each week, spend a few minutes scrolling through your collection, reliving each moment of appreciation.

This practice trains your brain to actively scan your environment for positive elements rather than potential threats or problems—a shift that can significantly impact your baseline level of happiness. After a month, you'll have created a personal "joy portfolio" that serves as visible evidence of the good in your daily life.

5) Schedule Micro-Adventures
Novelty is a powerful trigger for positive emotion. When we experience something new, our brains release dopamine, creating feelings of pleasure and engagement. You don't need expensive vacations or dramatic life changes to access this benefit—small novel experiences, or "micro-adventures," can provide similar emotional boosts.

How to implement this practice: Schedule one micro-adventure each week. This might be trying a food you've never tasted, taking a different route home, exploring a nearby area you've never visited, listening to a genre of music that's new to you, or learning the basics of a simple skill in a 30-minute YouTube tutorial.

The key is to introduce manageable novelty that stretches you slightly beyond your routine without creating stress or requiring significant resources. Keep a running list of micro-adventure ideas for inspiration, and consider inviting others to join you, as shared novel experiences can strengthen social bonds while boosting joy.

These five practices are not just nice ideas—they're based on solid research in positive psychology and neuroscience. The key to their effectiveness is consistency rather than intensity. Small, regular actions that train your attention toward joy will ultimately have a greater impact than occasional grand gestures or peak experiences.

Remember that cultivating joy doesn't mean denying life's genuine difficulties or maintaining constant happiness. Rather, these practices help you develop emotional resilience by ensuring that positive experiences register as deeply as challenging ones. By intentionally infusing more moments of joy into your everyday life, you create an emotional reservoir that sustains you through inevitable difficult periods while enhancing your capacity to fully experience the good that already exists in your world.""",
        'Quote': 'Jo<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>