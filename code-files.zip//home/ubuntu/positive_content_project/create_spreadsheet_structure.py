import pandas as pd
import os

# Define the structure of the spreadsheet
columns = [
    'Category',
    'Content Type',
    'Title',
    'Short Form Content',
    'Short Form Word Count',
    'Long Form Content',
    'Long Form Word Count',
    'Quote',
    'Quote Author',
    'Tags'
]

# Create an empty DataFrame with the defined columns
df = pd.DataFrame(columns=columns)

# Define the categories and content types
categories = [
    'Mindful Moments',
    'Resilience Recharge',
    'Joyful Living',
    'Purposeful Path',
    'Connection & Kindness',
    'Calm & Comfort'
]

content_types = [
    'Stories/Parables',
    'Practical Tips',
    'Reflections',
    'Affirmations'
]

# Create a todo list for tracking content creation
with open('todo.md', 'w') as f:
    f.write("# Content Creation Todo List\n\n")
    for category in categories:
        f.write(f"## {category}\n\n")
        for content_type in content_types:
            f.write(f"- [ ] Create {content_type} content for {category}\n")
        f.write("\n")

# Save the empty spreadsheet
output_file = 'positive_content_sets.xlsx'
df.to_excel(output_file, index=False)

print(f"Created spreadsheet structure in {output_file}")
print(f"Created todo.md for tracking content creation")
