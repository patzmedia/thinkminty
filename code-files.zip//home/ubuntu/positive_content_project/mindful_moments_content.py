import pandas as pd
import os

# Function to count words in text
def count_words(text):
    return len(text.split())

# Load the existing spreadsheet
output_file = 'positive_content_sets.xlsx'
try:
    df = pd.read_excel(output_file)
except FileNotFoundError:
    # If file doesn't exist, create a new DataFrame with the required columns
    columns = [
        'Category',
        'Content Type',
        'Title',
        'Short Form Content',
        'Short Form Word Count',
        'Long Form Content',
        'Long Form Word Count',
        'Quote',
        'Quote Author',
        'Tags'
    ]
    df = pd.DataFrame(columns=columns)

# Content for Mindful Moments category
mindful_moments_content = [
    # Stories/Parables
    {
        'Category': 'Mindful Moments',
        'Content Type': 'Stories/Parables',
        'Title': 'The Gardener\'s Patience',
        'Short Form Content': """Finding peace in the present moment is like tending a garden. A wise gardener once planted a beautiful garden but became frustrated when the flowers didn't bloom immediately. Every day, he would check anxiously, disturbing the soil and exposing the roots. A neighbor noticed and said, "The flowers will bloom in their own time. Your constant checking only disrupts their growth." The gardener learned to trust the process, finding joy in the daily tending rather than fixating on the outcome. When he stopped obsessing and simply appreciated each moment of care, the garden flourished beyond his expectations.""",
        'Long Form Content': """Finding peace in the present moment is like tending a garden. It requires patience, attention, and a willingness to appreciate the process rather than fixating solely on the outcome.

There once was a gardener who decided to create the most beautiful garden in his village. He carefully selected the finest seeds, prepared the soil with meticulous attention, and planted each seed with great care and high expectations. Every morning, he would wake up excited to see the progress of his garden.

However, as days passed without visible results, the gardener grew increasingly impatient. He began checking the plants multiple times daily, often digging around the seeds to see if they were sprouting beneath the soil. He would pull at the tiny shoots that had barely emerged, hoping to encourage faster growth. He added extra water and fertilizer, believing more would speed up the process.

A neighbor, an elderly woman who had maintained a stunning garden for decades, observed the gardener's frustration. One evening, as the gardener was anxiously inspecting his garden again, she approached him.

"Young man," she said gently, "your garden will bloom in its own time. Nature cannot be rushed. Your constant checking and interference are actually disturbing the natural process."

"But how will I know if they're growing properly if I don't check?" the gardener asked, clearly distressed.

"The same way you know your own heart is beating without having to see it," she replied. "Trust. The seeds know what to do. Your role is to create the conditions for growth and then allow the process to unfold."

Reluctantly, the gardener decided to follow her advice. Instead of frantically checking for progress, he focused on being present with his garden each day. He began to notice things he had missed before—the rich scent of the soil, the subtle changes in color as tiny shoots emerged, the way morning dew gathered on the leaves, the butterflies and bees that visited even the smallest blooms.

He found joy in the simple act of watering, in pulling weeds mindfully, in sitting quietly beside his garden in the evening light. He stopped thinking constantly about what the garden would eventually become and started appreciating what it was in each moment.

Weeks later, the gardener's patience was rewarded. His garden bloomed into a spectacular display of colors and fragrances, even more beautiful than he had imagined. But the gardener realized that the true gift wasn't just the blooming flowers—it was the peace he had found in the process, the ability to be fully present with his garden through all its stages.

"The flowers are beautiful," his neighbor commented, "but I suspect you've grown something even more valuable."

The gardener nodded, understanding that he had cultivated not just a garden, but the ability to find peace in the present moment—to trust the unfolding of life without constantly interfering or anxiously awaiting the future.

Like the gardener, we often miss the beauty of the present moment because we're so focused on outcomes. Mindfulness invites us to trust the process of life, to find joy in simple daily activities, and to cultivate patience with ourselves and the natural unfolding of events. When we learn to be fully present, we discover that peace isn't waiting for us in some future achievement—it's available right now, in this very moment.""",
        'Quote': 'The present moment is filled with joy and happiness. If you are attentive, you will see it.',
        'Quote Author': 'Thich Nhat Hanh',
        'Tags': 'mindfulness, patience, present moment, peace, growth, nature'
    },
    
    # Practical Tips
    {
        'Category': 'Mindful Moments',
        'Content Type': 'Practical Tips',
        'Title': 'Five-Minute Mindfulness Practices',
        'Short Form Content': """Incorporate mindfulness into your busy day with these simple practices: 1) Morning intention setting - before checking your phone, take three deep breaths and set a positive intention for the day. 2) Mindful eating - for one meal, eat without distractions, noticing flavors, textures, and your body's signals. 3) Gratitude pauses - set a timer to pause three times daily to name three things you're grateful for in that moment. 4) Sensory awareness breaks - take 60 seconds to notice five things you can see, four you can touch, three you can hear, two you can smell, and one you can taste. 5) Bedtime body scan - before sleep, mentally scan your body from toes to head, relaxing each part with your breath.""",
        'Long Form Content': """Incorporate mindfulness into your busy day with these simple five-minute practices that can transform your relationship with the present moment and cultivate a greater sense of peace throughout your day.

1) Morning Intention Setting
Before reaching for your phone or jumping into your to-do list, take three deep, conscious breaths as soon as you wake up. Feel your body making contact with your bed, notice the quality of light in the room, and listen to the first sounds of your day. Then, set a simple intention that will guide your day, such as "Today, I will notice moments of beauty" or "Today, I will respond rather than react." This practice frames your entire day with mindful awareness and purpose.

How to enhance this practice: Keep a small notebook by your bed to jot down your daily intention. At the end of the day, reflect on moments when you remembered or forgot your intention, without judgment. Over time, you'll notice patterns that can deepen your self-awareness.

2) Mindful Eating
Choose one meal or snack each day to eat with complete attention. Turn off all screens, put away reading materials, and simply be with your food. Before eating, take a moment to appreciate where this food came from—the people who grew it, transported it, and prepared it. Notice the colors, smells, and arrangement on your plate. As you eat, chew slowly and deliberately, noticing flavors, textures, and how they might change throughout the eating experience. Pay attention to your body's signals of hunger and satisfaction.

How to enhance this practice: Try eating the first three bites of every meal mindfully, even when you can't dedicate the entire meal to the practice. This creates a mindful "sandwich" around your eating experience and helps develop the habit of present-moment awareness with food.

3) Gratitude Pauses
Set three alarms on your phone throughout the day (morning, afternoon, and evening). When each alarm sounds, pause whatever you're doing for just one minute. During this minute, identify three specific things you're grateful for in that exact moment. They don't need to be profound—perhaps you're grateful for the comfortable chair you're sitting in, the taste of coffee lingering on your tongue, or the sound of rain outside your window. The key is to find gratitude in your immediate experience, not in abstract concepts.

How to enhance this practice: Keep a small gratitude journal with you or use a note-taking app on your phone. Jot down your gratitude items each time. After a month, read through your entries and notice how this practice has trained your mind to spot the positive aspects of your daily experience.

4) Sensory Awareness Breaks
This practice is particularly helpful during stressful moments or when you find your mind racing with worries. Take a 60-second break to systematically move through your senses: First, identify five things you can see around you, noticing details you might normally overlook. Next, notice four things you can physically feel (the texture of your clothing, the temperature of the air, the pressure of your feet on the floor, etc.). Then, tune into three distinct sounds in your environment. Next, identify two things you can smell (or two smells you like if you can't smell anything in the moment). Finally, notice one thing you can taste, even if it's just the taste in your mouth right now.

How to enhance this practice: Try this exercise in different environments—at home, in nature, at work, in a busy public place. Notice how each environment offers a completely different sensory experience, training your brain to become more attuned to the richness of the present moment wherever you are.

5) Bedtime Body Scan
As you lie in bed before sleep, take five minutes to perform a simple body scan meditation. Begin by bringing awareness to your toes, noticing any sensations present without trying to change them. Gradually move your attention upward—to your feet, ankles, calves, knees, and so on—all the way to the top of your head. As you focus on each body part, breathe into any areas of tension and imagine them softening with each exhale. This practice not only cultivates mindfulness but also helps prepare your body for restful sleep by releasing the physical tension accumulated throughout the day.

How to enhance this practice: If you notice particular areas that consistently hold tension, spend extra time breathing into those spots. You might also experiment with adding a simple phrase as you scan each body part, such as "relaxing my shoulders" or "bringing peace to my forehead."

Remember that mindfulness is not about achieving a particular state or having a certain kind of experience—it's simply about being aware of your experience as it unfolds, moment by moment, with curiosity and kindness. These five-minute practices are doorways into the present moment that can be accessed anytime, anywhere. The more consistently you practice, the more natural mindfulness will become, gradually transforming how you experience your daily life.""",
        'Quote': 'The little things? The little moments? They aren\'t little.',
        'Quote Author': 'Jon Kabat-Zinn',
        'Tags': 'mindfulness, practical tips, daily practice, present moment, peace, gratitude'
    },
    
    # Reflections
    {
        'Category': 'Mindful Moments',
        'Content Type': 'Reflections',
        'Title': 'The Space Between Thoughts',
        'Short Form Content': """In our busy lives, we rarely notice the space between our thoughts—that momentary stillness where true peace resides. Like the brief pause between musical notes that gives a melody its beauty, these gaps in our thinking allow us to experience life directly, without the filter of judgment or analysis. When we learn to recognize and expand these spaces through mindfulness, we discover that peace isn't something we need to create or achieve—it's already here, in the quiet awareness that witnesses our thoughts without becoming entangled in them. Today, try noticing the brief moments of mental silence that naturally occur throughout your day, and allow yourself to rest in that spacious awareness, if only for a breath.""",
        'Long Form Content': """In our busy lives, we rarely notice the space between our thoughts—that momentary stillness where true peace resides. Like the brief pause between musical notes that gives a melody its beauty, these gaps in our thinking allow us to experience life directly, without the filter of judgment or analysis.

Our minds are constantly active, generating a seemingly endless stream of thoughts—plans, memories, judgments, worries, and commentaries about our experience. We've become so accustomed to this mental chatter that we often mistake it for who we are. "I think, therefore I am," as Descartes famously stated. But what if our true essence isn't the thinking itself, but the awareness that witnesses the thinking?

If you've ever practiced meditation, you may have noticed something interesting: between thoughts, there are tiny gaps—moments of pure awareness before the next thought arises. Most of us rush past these gaps, immediately filling them with more thinking. But when we learn to recognize and rest in these spaces, even momentarily, we discover something profound: peace isn't something we need to create or achieve—it's already here, in the quiet awareness that witnesses our thoughts without becoming entangled in them.

Think of your mind as the sky and your thoughts as clouds passing through it. The clouds—whether dark storm clouds of difficult emotions or light, wispy clouds of pleasant thoughts—are constantly changing. But the sky itself remains spacious, open, and unchanged by whatever passes through it. This sky-like quality of awareness is always present, even in our busiest moments.

The 14th-century mystic Meister Eckhart described this when he wrote, "There is a place in the soul that neither time, nor space, nor any created thing can touch." This place—this spacious awareness—is available to us in every moment, if only we learn to recognize it.

The practice of mindfulness helps us become familiar with this space between thoughts. As we develop the ability to observe our thinking process rather than being completely identified with it, we naturally begin to notice the gaps more frequently. We discover that we can actually rest in that open awareness, allowing thoughts to arise and pass without immediately jumping onto the train of the next thought.

Interestingly, neuroscience is beginning to confirm what contemplative traditions have taught for centuries. When we practice mindfulness, we activate the parasympathetic nervous system—our "rest and digest" mode—which counteracts the stress response and promotes healing in the body. Studies show that regular mindfulness practice can reduce anxiety, improve immune function, and even change the structure of the brain in ways that enhance our capacity for presence and compassion.

But perhaps the most beautiful aspect of this practice is that it's always available, requiring no special circumstances or conditions. In the middle of a busy workday, while stuck in traffic, or during a difficult conversation—we can always take a conscious breath and notice the space of awareness in which our experience is occurring.

Here's a simple practice to explore this space between thoughts in your daily life:

Several times throughout your day, pause and take a conscious breath. Don't try to control or change your thinking—simply notice the thoughts that are present, and then see if you can detect the space of awareness in which those thoughts are appearing. It might help to ask yourself, "What is aware of these thoughts right now?"

As you become more familiar with this practice, you may notice that the space between thoughts begins to expand naturally. You<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>