import pandas as pd

# Load the spreadsheet
output_file = 'positive_content_sets.xlsx'
df = pd.read_excel(output_file)

# Fix the short-form content that's below the minimum word count
# Mindful Moments - Stories/Parables
mindful_stories_index = df[(df['Category'] == 'Mindful Moments') & (df['Content Type'] == 'Stories/Parables')].index[0]
df.at[mindful_stories_index, 'Short Form Content'] = """Finding peace in the present moment is like tending a garden. A wise gardener once planted a beautiful garden but became frustrated when the flowers didn't bloom immediately. Every day, he would check anxiously, disturbing the soil and exposing the roots. A neighbor noticed and said, "The flowers will bloom in their own time. Your constant checking only disrupts their growth." The gardener learned to trust the process, finding joy in the daily tending rather than fixating on the outcome. When he stopped obsessing and simply appreciated each moment of care, the garden flourished beyond his expectations. This simple parable reminds us that presence and patience often yield more beautiful results than anxious striving."""

# Mindful Moments - Affirmations
mindful_affirmations_index = df[(df['Category'] == 'Mindful Moments') & (df['Content Type'] == 'Affirmations')].index[0]
df.at[mindful_affirmations_index, 'Short Form Content'] = """I am fully present in this moment, embracing life exactly as it is. My breath anchors me to the here and now, where peace is always available. I release the need to control the future and regret the past, finding freedom in this present moment. My awareness is a gift that allows me to experience life directly and completely. In this moment, I have everything I need. I am not my thoughts or emotions—I am the peaceful awareness that witnesses them. Each breath is an opportunity to begin again with clarity and compassion. I choose to be fully present for my life as it unfolds, moment by precious moment."""

# Recalculate word counts for the updated content
df.at[mindful_stories_index, 'Short Form Word Count'] = len(df.at[mindful_stories_index, 'Short Form Content'].split())
df.at[mindful_affirmations_index, 'Short Form Word Count'] = len(df.at[mindful_affirmations_index, 'Short Form Content'].split())

# Save the updated spreadsheet
df.to_excel(output_file, index=False)

print(f"Fixed short-form content that was below the minimum word count")
print(f"Updated word counts:")
print(f"- Mindful Moments - Stories/Parables: {df.at[mindful_stories_index, 'Short Form Word Count']} words")
print(f"- Mindful Moments - Affirmations: {df.at[mindful_affirmations_index, 'Short Form Word Count']} words")
print(f"Updated spreadsheet saved to {output_file}")
