import pandas as pd
import os

# Function to count words in text
def count_words(text):
    return len(text.split())

# Load the existing spreadsheet
output_file = 'positive_content_sets.xlsx'
try:
    df = pd.read_excel(output_file)
except FileNotFoundError:
    # If file doesn't exist, create a new DataFrame with the required columns
    columns = [
        'Category',
        'Content Type',
        'Title',
        'Short Form Content',
        'Short Form Word Count',
        'Long Form Content',
        'Long Form Word Count',
        'Quote',
        'Quote Author',
        'Tags'
    ]
    df = pd.DataFrame(columns=columns)

# Content for Calm & Comfort category
calm_comfort_content = [
    # Stories/Parables
    {
        'Category': 'Calm & Comfort',
        'Content Type': 'Stories/Parables',
        'Title': 'The Shelter in the Storm',
        'Short Form Content': """Finding peace amid life's storms begins with creating a shelter within. A traveler was caught in a violent mountain storm. Seeking refuge, she spotted a small cabin and rushed inside. To her dismay, the cabin's roof had holes, allowing rain to pour through. Searching frantically, she found a small intact corner where she could stay dry. As the storm raged, she noticed an old journal left by the cabin's builder. In it, he wrote: "The storms will always come. I built this cabin not to eliminate the storms, but to provide a space where I could remain peaceful within them." The traveler realized she'd been seeking a life without storms—an impossible goal. True peace wasn't about controlling external circumstances but creating a sheltered space within herself that remained calm even when life's storms raged around her.""",
        'Long Form Content': """Finding peace amid life's storms begins with creating a shelter within. This truth is beautifully illustrated in the story of a traveler's unexpected lesson during a mountain journey.

A woman was hiking through mountain terrain when dark clouds began gathering ominously on the horizon. Having grown up in the region, she recognized the signs of an approaching storm and knew she needed to find shelter quickly. The mountain storms in this area were legendary for their sudden ferocity—driving rain, powerful winds, and occasionally even hail.

As the first heavy raindrops began to fall, she spotted a small wooden cabin nestled among the trees ahead. With relief, she rushed toward it, reaching the door just as the storm broke in full force. She pushed open the unlocked door and hurried inside, grateful to have found protection from the elements.

But her relief quickly turned to dismay. The cabin, while standing, was in disrepair. Most significantly, the roof had several holes through which rain was already beginning to pour. The floor was becoming wet in multiple places, and the wind whistled through cracks in the walls. This was hardly the secure shelter she had hoped for.

The traveler moved frantically around the cabin, trying to avoid the growing puddles. Finally, she discovered a small corner where the roof remained intact and the walls were solid. She huddled there, watching with frustration as the storm pounded the insufficient structure. What kind of shelter was this that couldn't even keep out the rain?

As she waited for the storm to pass, she noticed a small wooden chest in her dry corner. Curious and looking for distraction, she opened it and found an old leather-bound journal inside. It appeared to be the diary of the person who had built the cabin many years ago.

She began to read, and one entry particularly caught her attention:

"Finished the cabin today, though not as I originally planned. I came to these mountains seeking perfect peace—a place where the troubles of the world couldn't reach me. I thought if I built these walls strong enough, if I made this roof solid enough, I could keep all disturbances at bay. But today's storm showed me the folly of that thinking.

No matter how well I build, the storms will always come. Some will find their way in. I realized that I've been approaching peace all wrong. I built this cabin not to eliminate the storms, but to provide a space where I could remain peaceful within them. I've left parts of the roof open to remind myself of this truth—that peace isn't the absence of storms but the ability to find shelter within them."

The traveler read these words several times, struck by their relevance to her own life. She had been seeking a life without storms—without challenges, difficulties, or pain. She had believed that peace would come when she could finally control her external circumstances perfectly.

But the cabin builder's wisdom revealed a different path. True peace wasn't about controlling external circumstances—an impossible task—but about creating a sheltered space within herself that remained calm even when life's storms raged around her.

As she sat in her dry corner, listening to the rain pound the cabin roof, she began to see the structure differently. It wasn't a failed shelter that couldn't keep out the storm. It was an intentional reminder that we don't need to keep all difficulties at bay to experience peace. We simply need to find and nurture that quiet corner within ourselves that remains untouched by the tempest.

When the storm finally passed, the traveler continued her journey with a new perspective. In the weeks and months that followed, when facing life's inevitable challenges, she would remember the cabin with the holes in its roof. Rather than exhausting herself trying to control every circumstance, she would turn inward to find that sheltered corner of calm within herself.

She began developing practices that strengthened this inner shelter—meditation that anchored her in the present moment, gratitude that helped her notice what remained good even in difficult times, and self-compassion that provided comfort when things went wrong. These practices didn't prevent storms from coming, but they gave her a reliable refuge that no external circumstance could destroy.

Like the traveler, we often seek peace by trying to perfect our external conditions. We think, "I'll be at peace when this problem is solved" or "I'll feel calm when my circumstances improve." But this approach leaves our tranquility at the mercy of an unpredictable world.

The wiser path is to build an inner shelter—a capacity for calm and comfort that remains accessible even in challenging times. This doesn't mean ignoring practical problems or accepting harmful situations that can be changed. Rather, it means developing an inner resource that supports us through life's inevitable difficulties and empowers us to respond to them with clarity rather than reactivity.

Today, consider what practices help you access your inner shelter when life's storms arise. What helps you find that corner of peace within yourself that remains dry and secure even when rain pours through the roof? By strengthening this inner refuge, you develop a relationship with calm and comfort that no external circumstance can take away.""",
        'Quote': 'Peace is not the absence of trouble, but the presence of God.',
        'Quote Author': 'J.C. Macaulay',
        'Tags': 'peace, calm, inner strength, resilience, comfort, mindfulness'
    },
    
    # Practical Tips
    {
        'Category': 'Calm & Comfort',
        'Content Type': 'Practical Tips',
        'Title': 'Creating Pockets of Peace',
        'Short Form Content': """Cultivate calm in your daily life with these practical strategies: 1) Establish "worry boundaries" - designate specific times to address concerns rather than letting them intrude throughout your day. When worries arise outside these times, gently postpone them. 2) Create a 30-second reset ritual - develop a brief practice (like three deep breaths with a calming phrase) to use between activities or during stressful moments. 3) Design a sensory comfort kit - gather items that soothe each sense: something soft to touch, calming to smell, pleasant to taste, beautiful to see, and peaceful to hear. 4) Practice "box breathing" during anxious moments - inhale for four counts, hold for four, exhale for four, hold for four, and repeat. 5) Implement digital sunsets - end screen time 30-60 minutes before bed, replacing it with calming activities like reading, gentle stretching, or listening to peaceful music.""",
        'Long Form Content': """Cultivate calm in your daily life with these practical strategies that create pockets of peace amid busyness and stress. These approaches don't require major life changes or hours of practice—they're designed to fit into your existing routine while significantly enhancing your experience of calm and comfort.

1) Establish "Worry Boundaries"
Our minds often recycle the same concerns throughout the day, creating a background hum of anxiety that depletes our energy and prevents us from fully engaging with the present moment. Worry boundaries involve designating specific times to address concerns rather than letting them intrude throughout your day.

How to implement this practice: Choose a 15-20 minute period each day as your designated "worry time." When concerns arise outside this time, acknowledge them briefly and then gently postpone them: "I notice I'm worrying about this now, but I'll give this my full attention during my worry time." During your scheduled worry session, write down all concerns, evaluate which ones require action, which are beyond your control, and which might benefit from a perspective shift.

This practice doesn't suppress legitimate concerns but rather contains them within boundaries, preventing them from colonizing your entire day. Research shows that this scheduled approach to worry actually reduces anxiety overall while improving problem-solving effectiveness. The key is consistency—when your mind learns that concerns will get proper attention at the designated time, it becomes more willing to set them aside temporarily.

2) Create a 30-Second Reset Ritual
Transitions between activities or environments often create stress as our nervous systems adjust to new demands. A brief reset ritual helps clear residual tension from the previous activity and prepare your mind and body for what's next.

How to implement this practice: Develop a 30-second practice that you can use between activities or during stressful moments. This might include three deep breaths while mentally repeating a calming phrase, a brief body scan to release tension, or simply pausing to notice five things you can see, four you can touch, three you can hear, two you can smell, and one you can taste.

Use this reset ritual intentionally during transitions—between work meetings, before entering your home after work, when switching between tasks, or whenever you notice tension building. The brevity of this practice makes it accessible even on your busiest days, while its ritualized nature helps trigger your parasympathetic nervous system (your "rest and digest" mode) more efficiently each time you use it.

3) Design a Sensory Comfort Kit
Our senses provide direct pathways to our nervous system, capable of signaling safety and comfort to our brains. A sensory comfort kit gathers items that soothe each sense, creating a portable resource for self-regulation during difficult moments.

How to implement this practice: Gather items that positively engage each of your senses:
- Touch: Something soft or textured that feels comforting (a smooth stone, a piece of soft fabric, a stress ball)
- Smell: Calming scents in portable form (a small essential oil roller, a sachet of lavender, a favorite tea bag)
- Taste: Small, soothing flavors (mints, a favorite tea, dark chocolate)
- Sight: Visual anchors for calm (photos of loved ones or peaceful places, a small artwork that brings joy)
- Sound: Accessible peaceful audio (a playlist of calming music, nature sounds, or guided meditations on your phone)

Keep these items in a small container at your desk, in your bag, or in your car. During stressful moments, engaging one or more senses can interrupt the stress response and provide immediate comfort. The effectiveness of this kit increases as you consistently pair these sensory inputs with a calmer state, creating stronger neural associations over time.

4) Practice "Box Breathing" During Anxious Moments
Our breath provides a direct link to our autonomic nervous system—the system that controls our stress response. Box breathing (also called square breathing) is a simple technique used by everyone from Navy SEALs to anxiety therapists to quickly induce a state of calm.

How to implement this practice: When you notice anxiety rising, pause and use this breathing pattern:
- Inhale slowly through your nose for a count of four
- Hold your breath for a count of four
- Exhale slowly through your mouth for a count of four
- Hold the empty lungs for a count of four
- Repeat for at least four cycles

The equal ratios of this breathing pattern help balance the sympathetic (activating) and parasympathetic (calming) branches of your nervous system. The brief holds after inhale and exhale add an additional regulatory element that helps interrupt racing thoughts. Practice this technique regularly when you're already calm so it becomes automatic and accessible during more challenging moments.

5) Implement Digital Sunsets
The stimulation from screens—particularly the blue light they emit and the often activating content they deliver—can significantly disrupt our natural transition to restfulness in the evening. Digital sunsets create a buffer zone between screen time and sleep, allowing your nervous system to naturally downregulate.

How to implement this practice: End all screen time (phones, computers, tablets, TV) 30-60 minutes before your intended bedtime. Replace these activities with calming alternatives that signal to your body and mind that it's time to rest: reading a physical book, gentle stretching, taking a warm bath, listening to peaceful music, or having a quiet conversation.

To make this practice sustainable, prepare for it by:
- Setting an alarm 30-60 minutes before bedtime as your digital sunset reminder
- Charging devices outside your bedroom
- Having non-screen alternatives easily accessible
- Using apps that automatically reduce blue light on devices in the evening hours for those times when screen use is truly necessary

This practice not only improves sleep quality but creates a nightly pocket of peace that can become a cherished part of your daily rhythm.

These five strategies work best when integrated consistently into your routine rather than used only during crisis moments. Start with the practice that resonates most strongly with you, implement it daily for at least two weeks, and notice how it affects your baseline level of calm. Then gradually add additional practices, creating multiple pockets of peace throughout your day.

Remember that cultivating calm isn't about eliminating stress entirely—that would be both impossible and undesirable, as some stress is necessary for growth and engagement with life. Rather, these practices help you develop greater resilience and self-regulation, allowing you to return to a state of calm more quickly after activation and to maintain access to comfort even during challenging circumstances.""",
        'Quote': 'Peace is the result of retraining your mind to process life as it is, rather than as you think it should be.',
        'Quote Author': 'Wayne W. Dyer',
        'Tags': 'calm, peace, practical tips, stress management, self-care, mindfulness'
    },
    
    # Reflections
    {
        'Category': 'Calm & Comfort',
        'Content Type': 'Reflections',
        'Title': 'The Quiet Strength of Gentleness',
        'Short Form Content': """In a world that often celebrates force, speed, and dominance, gentleness can seem like weakness. Yet true gentleness requires remarkable strength—th<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>